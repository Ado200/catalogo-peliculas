/* JavaScript de Mi catálogo de películas. Bloques en el orden original. */

/* --- bloque 1 --- */
const CLIENT_ID = "45846987194-cm8mnhijljms8k8u8j44n8aeq674vuis.apps.googleusercontent.com";
// Dominio de la cuenta institucional (por ejemplo "universidad.edu.mx"). Solo estas cuentas pueden entrar. Déjalo vacío para no restringir.
const DOMINIO_INSTITUCIONAL = "ucaribe.edu.mx";
// Modo prueba: si existe "hoja_id_prueba" en el navegador, la app usa esa hoja en lugar de la real.
const HOJA_ID = localStorage.getItem("hoja_id_prueba") || "1W5oSA5yy4TpbVYxjya6S9T6NkeE6irwSHABXFAijO2k";
const SCOPES = "https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive.appdata openid email";
const NOMBRE_PALETA = "paleta_poster";

let peliculas = [];
let visibles = [];
let encabezados = [];
let COL_PALETA = -1;
let tokenClient;
let accessToken = null;
let marcas = {};
let idMarcas = null;
let guardadoTimer = null;
let vistaLista = false;
let agrupado = false;
let desdeAleatorio = false;
let cenaElegida = null;
let mesCalendario = null;
let cenaMensaje = "";
let fotosActores = {};
let detalleActual = null;
let sugeridaActual = null;
let textoSugerida = "";
let ahorroActivo = null;
let chartsStats = [];
let pestana = "catalogo";
let zonaPeli = "inicio";     // dentro de Películas: inicio | lista | estrenos | sagas | actores | duelo
let zonaVistas = "lista";    // dentro de Vistas: lista | resumen | actividad | mapa
let decidiendo = null;
let deshacerDescarte = null;
let avisoCerrado = false;
let firmaAvisoCerrado = "";
let seleccionDesc = new Set();
let porQueAbiertos = new Set();
const paletaCache = new Map();

let ubicacion = { lat: 21.16, lon: -86.85 };

const $ = id => document.getElementById(id);
const lista = $("lista"), buscar = $("buscar"), contador = $("contador"), chips = $("chips");
const sel = { tipo:$("tipo"), genero:$("genero"), tema:$("tema"), anio:$("anio"), pais:$("pais"), duracion:$("duracion"), estado:$("estado") };
const etiquetas = { tipo:"Tipo", genero:"Género", tema:"Tema", anio:"Año", pais:"País", duracion:"Duración", estado:"Estado" };
const AVANZADOS = ["genero", "estado", "tipo", "tema", "anio", "pais", "duracion"];

function esc(x) {
  return String(x == null ? "" : x).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function setEstado(msg) { $("estadoGuardado").textContent = msg; }
function generosDe(p) { return String(p.genero || "").split(",").map(s => s.trim()).filter(Boolean); }
function temasDe(p) { return String(p.temas || "").split(";").map(s => s.trim()).filter(Boolean); }
function directoresDe(p) { return String(p.director || "").split(",").map(s => s.trim()).filter(Boolean); }
function personasDe(p) {
  return [...String(p.director || "").split(","), ...String(p.reparto || "").split(",")]
    .map(s => s.trim()).filter(Boolean);
}

function minutos(p) {
  const s = String(p.duracion || "");
  const h = s.match(/(\d+)\s*h/);
  const m = s.match(/(\d+)\s*min/);
  return (h ? Number(h[1]) * 60 : 0) + (m ? Number(m[1]) : 0);
}

function enRangoDuracion(p, valor) {
  if (!valor) return true;
  const m = minutos(p);
  if (valor === "corta") return m > 0 && m < 90;
  if (valor === "media") return m >= 90 && m <= 120;
  if (valor === "larga") return m > 120;
  return true;
}

const ordenes = {
  titulo: (a, b) => String(a.titulo).localeCompare(String(b.titulo), "es"),
  recientes: (a, b) => (Number(b["año"]) || 0) - (Number(a["año"]) || 0),
  antiguas: (a, b) => (Number(a["año"]) || 0) - (Number(b["año"]) || 0),
  duracion: (a, b) => minutos(b) - minutos(a)
};

/* ---------- Ahorro de datos ---------- */
function datosLimitados() {
  const modo = modoGuardado("ahorro_modo", "auto");
  if (modo === "ahorro") return true;
  if (modo === "normal") return false;
  const c = navigator.connection;
  if (c && (c.saveData || ["slow-2g", "2g", "3g"].includes(c.effectiveType))) return true;
  if (window.matchMedia && window.matchMedia("(prefers-reduced-data: reduce)").matches) return true;
  return false;
}

function actualizarAhorro() {
  const nuevo = datosLimitados();
  if (nuevo === ahorroActivo) return;
  ahorroActivo = nuevo;
  document.body.classList.toggle("ahorro", nuevo);
  if (!peliculas.length) return;
  renderDestacados();
  pintarSugerencia();
  pintar();
  if ($("modal").classList.contains("abierto") && detalleActual) abrirDetalle(detalleActual);
}

function contenidoTrailer(codigo, titulo) {
  if (!datosLimitados()) return iframeTrailer(codigo, titulo);
  return '<div class="trailer-espera"><button class="pildora destacado" data-cargar-trailer="' + esc(codigo) + '">▶ Cargar tráiler</button></div>';
}

/* ---------- Enlaces directos ---------- */
function slugDe(p) {
  return String(p.titulo || "")
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function urlDePelicula(p) {
  const u = new URL(location.href);
  u.search = "";
  u.hash = "";
  u.searchParams.set("id", slugDe(p));
  return u.toString();
}

function ponerIdEnUrl(valor) {
  try {
    const u = new URL(location.href);
    if (valor) u.searchParams.set("id", valor); else u.searchParams.delete("id");
    history.replaceState(null, "", u.toString());
  } catch (e) {}
}

function abrirDesdeUrl() {
  const id = new URLSearchParams(location.search).get("id");
  if (!id) return;
  const p = peliculas.find(x => slugDe(x) === id);
  if (p) {
    desdeAleatorio = false;
    abrirDetalle(p);
  } else {
    setEstado("No encontré la película del enlace.");
  }
}

function copiarEnlace() {
  if (!detalleActual) return;
  navigator.clipboard.writeText(urlDePelicula(detalleActual))
    .then(() => setEstado("Enlace copiado."))
    .catch(() => setEstado("Este navegador no permite copiar el enlace."));
}

/* ---------- Sugerencias por hora y día ---------- */
function norm(s) {
  return String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

function tieneGenero(p, terminos) {
  return generosDe(p).map(norm).some(g => terminos.some(t => g.includes(t)));
}

const REGLAS = [
  {
    texto: "Domingo por la mañana: una comedia o un clásico.",
    aplica: (dia, hora) => dia === 0 && hora >= 7 && hora < 13,
    filtro: p => tieneGenero(p, ["comedia"]) || (Number(p["año"]) > 0 && Number(p["año"]) < 2000)
  },
  {
    texto: "De noche: thriller, misterio o suspenso.",
    aplica: (dia, hora) => hora >= 22 || hora < 5,
    filtro: p => tieneGenero(p, ["thriller", "suspenso", "misterio", "crimen", "terror"])
  },
  {
    texto: "Por la mañana: documental, biografía o historia.",
    aplica: (dia, hora) => hora >= 5 && hora < 12,
    filtro: p => tieneGenero(p, ["documental", "biograf", "historia"])
  },
  {
    texto: "Por la tarde: comedia o aventura.",
    aplica: () => true,
    filtro: p => tieneGenero(p, ["comedia", "aventura"])
  }
];

function esFinDeSemanaTarde() {
  const ahora = new Date();
  const dia = ahora.getDay();
  const hora = ahora.getHours();
  return (dia === 0 || dia === 6) && hora >= 12 && hora < 22;
}

function elegirParaAhora(excluir) {
  let pend = peliculas.filter(p => estadoDe(p).pendiente);
  if (excluir && pend.length > 1) pend = pend.filter(p => p.titulo !== excluir.titulo);
  if (!pend.length) return null;

  const ahora = new Date();
  const regla = REGLAS.find(r => r.aplica(ahora.getDay(), ahora.getHours()));
  let candidatas = pend.filter(regla.filtro);
  let texto = regla.texto;

  if (esFinDeSemanaTarde()) {
    const conAlguien = pend.filter(p => estadoDe(p).conAlguien);
    if (conAlguien.length) {
      candidatas = conAlguien;
      texto = "Fin de semana: una que puedes ver acompañado.";
    }
  }

  if (!candidatas.length) {
    candidatas = pend;
    texto = "No tienes pendientes de este tipo; te sugiero uno de tus pendientes.";
  }
  return { texto, p: candidatas[Math.floor(Math.random() * candidatas.length)] };
}

function pintarSugerencia() {
  if (!sugeridaActual) return;
  const p = sugeridaActual;
  $("ahoraTexto").textContent = textoSugerida;
  $("ahoraCaja").innerHTML =
    '<div class="ahora-card">' +
      (p.portada && !datosLimitados() ? '<img src="' + esc(p.portada) + '" alt="">' : '<div class="sinportada">🎬</div>') +
      '<div>' +
        '<h4>' + esc(p.titulo) + '</h4>' +
        '<div class="meta">' + esc(p["año"]) + ' · ' + esc(p.duracion) + '</div>' +
        '<div class="acciones">' +
          '<button class="pildora destacado" id="ahoraVer">Ver ficha</button>' +
          '<button class="pildora" id="ahoraOtra">Otra</button>' +
        '</div>' +
      '</div>' +
    '</div>';
}

function nuevaSugerencia(excluir) {
  const s = elegirParaAhora(excluir);
  if (!s) {
    $("ahora").style.display = "none";
    sugeridaActual = null;
    return;
  }
  sugeridaActual = s.p;
  textoSugerida = s.texto;
  pintarSugerencia();
}

function actualizarAhora() {
  const sec = $("ahora");
  const hayPendientes = peliculas.some(p => estadoDe(p).pendiente);
  if (hayFiltros() || !hayPendientes || pestana !== "catalogo") {
    sec.style.display = "none";
    return;
  }
  sec.style.display = "block";
  if (!sugeridaActual || !estadoDe(sugeridaActual).pendiente) nuevaSugerencia(null);
}

/* ---------- Resumen semanal (lunes; prueba con ?resumen=1) ---------- */
function hoyLocalISO() {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
}

function diaISODesde(dias) {
  const d = new Date();
  d.setDate(d.getDate() - dias);
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
}

function leerJSON(clave, defecto) {
  try {
    const v = localStorage.getItem(clave);
    return v ? JSON.parse(v) : defecto;
  } catch (e) { return defecto; }
}

function guardarJSON(clave, valor) {
  try { localStorage.setItem(clave, JSON.stringify(valor)); } catch (e) {}
}

function resumenDePrueba() {
  return new URLSearchParams(location.search).get("resumen") === "1";
}

function sugerenciaSemanal() {
  const pend = peliculas.filter(p => estadoDe(p).pendiente);
  if (!pend.length) return null;

  const hoy = hoyLocalISO();
  const guardada = leerJSON("resumen_sugerida", null);
  if (guardada && guardada.fecha === hoy) {
    const previa = pend.find(x => x.titulo === guardada.titulo);
    if (previa) return previa;
  }

  const historial = leerJSON("resumen_historial", []);
  let candidatas = pend.filter(p => !historial.includes(p.titulo));
  if (!candidatas.length) candidatas = pend;
  const elegida = candidatas[Math.floor(Math.random() * candidatas.length)];

  guardarJSON("resumen_sugerida", { fecha: hoy, titulo: elegida.titulo });
  guardarJSON("resumen_historial", [elegida.titulo, ...historial].slice(0, 8));
  return elegida;
}

function cerrarResumenSemana() {
  try { localStorage.setItem("resumen_cerrado", hoyLocalISO()); } catch (e) {}
  actualizarResumenSemana();
}

function actualizarResumenSemana() {
  const sec = $("resumenSemana");
  const hoy = hoyLocalISO();
  const esLunes = new Date().getDay() === 1;
  const mostrarHoy = esLunes || resumenDePrueba();

  if (!peliculas.length || !mostrarHoy || modoGuardado("resumen_cerrado", "") === hoy || pestana !== "vistas") {
    sec.style.display = "none";
    return;
  }

  const desde = diaISODesde(6);
  const vistasSemana = peliculas.filter(p => {
    const m = marcas[p.titulo] || {};
    return m.vista && m.vistaDesde && m.vistaDesde >= desde && m.vistaDesde <= hoy;
  });
  const pendLargas = peliculas.filter(p => {
    const d = diasPendiente(p);
    return estadoDe(p).pendiente && d !== null && d > 30;
  }).length;
  const sug = sugerenciaSemanal();
  const rec0 = calcularRecomendaciones()[0];

  sec.innerHTML =
    '<div class="resumen-card">' +
      '<div class="resumen-top"><h3>Resumen semanal</h3>' +
        '<button id="cerrarResumen" title="Cerrar" aria-label="Cerrar resumen">×</button></div>' +
      '<div class="resumen-stats">' +
        '<div class="stat"><b>' + vistasSemana.length + '</b><span>vistas esta semana</span></div>' +
        '<div class="stat"><b>' + pendLargas + '</b><span>pendientes con más de 30 días</span></div>' +
      '</div>' +
      (vistasSemana.length === 0 ? '<p class="meta">Esta semana no marcaste películas como vistas.</p>' : '') +
      (rec0 ? '<button class="pildora" id="btnCompartirRec">Compartir recomendación</button>' : '') +
      (sug
        ? '<div class="resumen-sug">' +
            '<span class="meta">Hoy te sugiero</span>' +
            '<div class="resumen-titulo">' + esc(sug.titulo) + '</div>' +
            '<div class="meta">' + esc(sug["año"]) + ' · ' + esc(sug.duracion) + '</div>' +
            '<button class="pildora destacado" id="resumenVer" data-titulo="' + esc(sug.titulo) + '">Ver ficha</button>' +
          '</div>'
        : '<p class="meta">No tienes pendientes para sugerir hoy.</p>') +
    '</div>';
  sec.style.display = "block";
}

/* ---------- Modo cena: pendiente de menos de 2 h, con alguien si aplica ---------- */
function candidatasCena() {
  return peliculas.filter(p => {
    const s = estadoDe(p);
    const m = minutos(p);
    return s.pendiente && m > 0 && m < 120;
  });
}

function elegirCena(otra) {
  const c = candidatasCena();
  if (!c.length) {
    cenaElegida = null;
    cenaMensaje = "No tienes pendientes de menos de 2 horas. Revisa que la duración de tus pendientes esté escrita, por ejemplo 1 h 45 min.";
    renderCena();
    return;
  }
  cenaMensaje = "";
  const preferidas = c.filter(p => estadoDe(p).conAlguien);
  let pool = preferidas.length ? preferidas : c;
  if (otra && pool.length > 1) pool = pool.filter(p => p !== cenaElegida);
  cenaElegida = pool[Math.floor(Math.random() * pool.length)];
  renderCena();
}

function renderCena() {
  const sec = $("cena");
  if (!peliculas.length || hayFiltros() || pestana !== "catalogo") {
    sec.style.display = "none";
    return;
  }
  let cuerpo;
  if (!cenaElegida || !candidatasCena().includes(cenaElegida)) {
    cuerpo = '<p class="meta">' + esc(cenaMensaje || "Pulsa el botón y te doy una película pendiente de menos de 2 horas.") + '</p>' +
      '<button class="pildora destacado" id="btnCena">Elegir para esta noche</button>';
  } else {
    const m = (marcas[cenaElegida.titulo] || {});
    const conAlguien = estadoDe(cenaElegida).conAlguien;
    cuerpo = (cenaElegida.portada && !datosLimitados()
        ? '<img class="cena-portada" src="' + esc(cenaElegida.portada) + '" alt="">'
        : '<div class="cena-sinportada">🎬</div>') +
      '<div class="resumen-titulo">' + esc(cenaElegida.titulo) + '</div>' +
      '<div class="meta">' + esc(cenaElegida["año"]) + ' · ' + esc(cenaElegida.duracion) +
      (conAlguien ? ' · para ver con ' + esc(m.conQuien || "alguien") : '') + '</div>' +
      '<div class="insignias" style="margin-top:8px">' +
        '<button class="pildora destacado" id="cenaVer" data-titulo="' + esc(cenaElegida.titulo) + '">Ver ficha</button>' +
        '<button class="pildora" id="cenaOtra">Otra</button>' +
      '</div>';
  }
  sec.innerHTML = '<div class="actividad-card"><h3>Para esta noche</h3>' + cuerpo + '</div>';
  sec.style.display = "block";
}

/* ---------- Calendario de planeación (pestaña Pendientes) ---------- */
const MESES_ES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];

function desplazarMes(ym, delta) {
  const [y, m] = ym.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0");
}

/* ---------- Modo esta semana: planes con alguien en los próximos 7 días ---------- */
function planesProximos7Dias() {
  const hoy = hoyLocalISO();
  const limite = sumarDiasISO(hoy, 7);
  return peliculas
    .map(p => ({ p, m: marcas[p.titulo] || {} }))
    .filter(({ m }) => m.conAlguien && m.conFecha && m.conFecha >= hoy && m.conFecha <= limite)
    .sort((a, b) => a.m.conFecha.localeCompare(b.m.conFecha));
}

function etiquetaDia(iso) {
  const d = diasHasta(iso);
  if (d === 0) return "hoy";
  if (d === 1) return "mañana";
  const dias = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"];
  const [y, m, dd] = iso.split("-").map(Number);
  return dias[new Date(y, m - 1, dd).getDay()];
}

function renderEstaSemana() {
  const sec = $("estaSemana");
  if (!peliculas.length || hayFiltros() || pestana !== "catalogo") {
    sec.style.display = "none";
    return;
  }
  const planes = planesProximos7Dias();
  const cuerpo = planes.length
    ? planes.map(({ p, m }) =>
        '<div class="dest-fila">' +
          '<div><b>' + esc(p.titulo) + '</b>' +
          '<div class="meta">' + esc(etiquetaDia(m.conFecha)) + ' · ' + esc(m.conFecha) +
          (m.conQuien ? ' · con ' + esc(m.conQuien) : '') + '</div></div>' +
        '</div>'
      ).join("")
    : '<p class="meta">No hay planes con alguien para los próximos 7 días.</p>';
  sec.innerHTML = '<div class="actividad-card"><h3>Planes de la semana</h3>' + cuerpo + '</div>';
  sec.style.display = "block";
}

/* ---------- Duelo de películas: elige una de dos pendientes ---------- */
let parDuelo = null;

function elegirPar() {
  const pend = peliculas.filter(p => {
    const s = estadoDe(p);
    return s.pendiente && !s.conAlguien;
  });
  if (pend.length < 2) return null;
  const a = pend[Math.floor(Math.random() * pend.length)];
  let b = a;
  while (b === a) b = pend[Math.floor(Math.random() * pend.length)];
  return [a, b];
}

function renderDuelo() {
  const sec = $("duelo");
  if (!peliculas.length || hayFiltros() || pestana !== "catalogo") {
    sec.style.display = "none";
    return;
  }
  if (!parDuelo || !parDuelo.every(p => estadoDe(p).pendiente && !estadoDe(p).conAlguien)) {
    parDuelo = elegirPar();
  }
  if (!parDuelo) {
    sec.style.display = "none";
    return;
  }
  const [a, b] = parDuelo;
  const tarjeta = p =>
    '<button class="pildora destacado" data-duelo-elige="' + esc(p.titulo) + '" style="flex:1;padding:14px;">' +
      esc(p.titulo) + '<br><span style="font-size:12px;opacity:.8">' + esc(p["año"]) + ' · ' + esc(p.duracion) + '</span>' +
    '</button>';
  sec.innerHTML =
    '<div class="actividad-card"><h3>Duelo</h3>' +
      '<p class="meta">Elige cuál ver primero. La otra se queda en pendientes.</p>' +
      '<div style="display:flex;gap:10px;align-items:stretch;flex-wrap:wrap">' +
        tarjeta(a) + '<span style="align-self:center;color:var(--gris)">vs</span>' + tarjeta(b) +
      '</div>' +
      '<button class="pildora" data-duelo-otro="1" style="margin-top:10px">Otro duelo</button>' +
    '</div>';
  sec.style.display = "block";
}

function elegirEnDuelo(titulo) {
  const previo = marcas[titulo] || {};
  const nuevo = Object.assign({}, previo, { pendienteElegidaDesde: hoyLocalISO() });
  marcas[titulo] = nuevo;
  programarGuardado();
  parDuelo = null;
  setEstado("Elegida en el duelo: «" + titulo + "».");
  refrescarTodo();
}

/* ---------- Mapa de gustos: géneros y directores de tus favoritas (4 o 5★) ---------- */
let chartsMapa = [];

function destruirMapa() {
  chartsMapa.forEach(c => c.destroy());
  chartsMapa = [];
}

function topConteo(items, n) {
  const conteo = {};
  items.forEach(x => { conteo[x] = (conteo[x] || 0) + 1; });
  return Object.entries(conteo).sort((a, b) => b[1] - a[1]).slice(0, n);
}

function renderMapaGustos() {
  const sec = $("mapaGustos");
  destruirMapa();
  if (!peliculas.length || pestana !== "vistas") {
    sec.style.display = "none";
    return;
  }
  const favoritas = peliculas.filter(p => estadoDe(p).estrellas >= 4);
  if (favoritas.length < 2 || typeof Chart === "undefined") {
    sec.style.display = "none";
    return;
  }
  const generos = topConteo(favoritas.flatMap(generosDe), 6);
  const directores = topConteo(favoritas.flatMap(directoresDe), 5);
  const c = coloresGrafica();

  sec.innerHTML =
    '<div class="actividad-card"><h3>Mapa de gustos</h3>' +
      '<p class="meta">Según tus ' + favoritas.length + ' películas con 4 o 5★.</p>' +
      '<div class="graficas-dos">' +
        '<div class="grafica-caja"><h3>Géneros</h3><canvas id="gMapaGen"></canvas></div>' +
        '<div class="grafica-caja"><h3>Directores</h3><canvas id="gMapaDir"></canvas></div>' +
      '</div>' +
    '</div>';
  sec.style.display = "block";

  chartsMapa.push(new Chart($("gMapaGen"), {
    type: "bar",
    data: { labels: generos.map(x => x[0]), datasets: [{ label: "Películas", data: generos.map(x => x[1]), backgroundColor: c.paleta[0], borderRadius: 6 }] },
    options: { indexAxis: "y", plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } }
  }));
  chartsMapa.push(new Chart($("gMapaDir"), {
    type: "bar",
    data: { labels: directores.map(x => x[0]), datasets: [{ label: "Películas", data: directores.map(x => x[1]), backgroundColor: c.paleta[1], borderRadius: 6 }] },
    options: { indexAxis: "y", plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } }
  }));
}

/* ---------- Pregunta del día: una pregunta sobre una vista; la respuesta va en marcas[titulo].preguntas ---------- */
const PREGUNTAS = [
  "¿Qué escena de «{título}» recuerdas mejor?",
  "¿Qué personaje te quedó más en la cabeza de «{título}»?",
  "¿Te gustaría volver a ver «{título}» en otro momento?",
  "¿Qué habrías cambiado de «{título}»?",
  "¿Con qué frase o diálogo te quedaste de «{título}»?"
];

function preguntaDelDia() {
  const hoy = hoyLocalISO();
  const pd = marcas.__preguntaDia || null;
  if (pd && pd.fecha === hoy) {
    const m = marcas[pd.titulo] || {};
    if (m.vista && !m.descartada) return pd;
  }
  const recientes = ((pd && pd.recientes) || []).filter(r => r.f >= diaISODesde(6));
  const vistas = peliculas.filter(p => estadoDe(p).vista && !(marcas[p.titulo] || {}).descartada);
  if (!vistas.length) return null;
  let cand = vistas.filter(p => !recientes.some(r => r.t === p.titulo));
  if (!cand.length) cand = vistas;
  const elegida = cand[Math.floor(Math.random() * cand.length)];
  const nuevo = {
    fecha: hoy,
    titulo: elegida.titulo,
    idx: Math.floor(Math.random() * PREGUNTAS.length),
    recientes: recientes.concat([{ t: elegida.titulo, f: hoy }]).slice(-10),
    omitida: pd && pd.fecha === hoy ? pd.omitida : undefined
  };
  marcas.__preguntaDia = nuevo;
  programarGuardado();
  return nuevo;
}

function textoPregunta(pd) {
  return PREGUNTAS[pd.idx].replace("{título}", pd.titulo);
}

function renderPregunta() {
  const sec = $("pregunta");
  if (!peliculas.length || hayFiltros() || pestana !== "catalogo") {
    sec.style.display = "none";
    return;
  }
  const hoy = hoyLocalISO();
  const pd = preguntaDelDia();
  if (!pd || pd.omitida === hoy) {
    sec.style.display = "none";
    return;
  }
  const p = peliculas.find(x => x.titulo === pd.titulo);
  if (!p) {
    sec.style.display = "none";
    return;
  }
  const entrada = ((marcas[p.titulo] || {}).preguntas || []).find(e => e.f === hoy);
  const pregunta = textoPregunta(pd);
  const cuerpo = entrada
    ? '<p class="resumen-titulo">' + esc(pregunta) + '</p>' +
      '<p class="meta">Respondida hoy</p>' +
      '<p class="nota-corta">' + esc(entrada.r) + '</p>'
    : '<p class="resumen-titulo">' + esc(pregunta) + '</p>' +
      '<textarea id="preguntaTexto" maxlength="500" placeholder="Escribe tu respuesta" style="width:100%;min-height:70px;padding:10px;font:inherit;border:1px solid var(--borde);border-radius:12px;background:var(--tarjeta);color:var(--texto);margin-top:8px"></textarea>' +
      '<div class="meta" id="preguntaContador">0/500</div>' +
      '<div class="insignias" style="margin-top:8px">' +
        '<button class="pildora destacado" id="preguntaGuardar" data-titulo="' + esc(p.titulo) + '">Guardar</button>' +
        '<button class="pildora" id="preguntaOmitir">Hoy no</button>' +
      '</div>';
  sec.innerHTML = '<div class="actividad-card"><h3>Pregunta del día</h3>' + cuerpo + '</div>';
  sec.style.display = "block";
}

function guardarRespuestaDia(titulo) {
  const texto = ($("preguntaTexto") ? $("preguntaTexto").value : "").trim().slice(0, 500);
  if (!texto) { setEstado("Escribe una respuesta antes de guardar."); return; }
  const pd = preguntaDelDia();
  if (!pd) return;
  const hoy = hoyLocalISO();
  const m = marcas[titulo] || {};
  const lista = (m.preguntas || []).filter(e => e.f !== hoy)
    .concat([{ f: hoy, p: textoPregunta(pd), r: texto }]);
  marcas[titulo] = Object.assign({}, m, { preguntas: lista });
  programarGuardado();
  setEstado("Respuesta guardada.");
  refrescarTodo();
}

function omitirPreguntaHoy() {
  const pd = preguntaDelDia();
  if (!pd) return;
  marcas.__preguntaDia = Object.assign({}, pd, { omitida: hoyLocalISO() });
  programarGuardado();
  refrescarTodo();
}

function preguntasFichaHtml(p) {
  const lista = (marcas[p.titulo] || {}).preguntas || [];
  if (!lista.length) return "";
  return '<details class="historial"><summary>Mis respuestas (' + lista.length + ')</summary><ul>' +
    lista.slice().sort((a, b) => b.f.localeCompare(a.f)).map(e =>
      '<li>' + esc(e.f.split("-").reverse().join("/")) + ' · ' + esc(e.p) + '<br>' + esc(e.r) + '</li>'
    ).join("") +
    '</ul></details>';
}

// Guía para cuando todavía no hay marcas: explica lo básico y se oculta solo.
function renderBienvenida() {
  const sec = $("bienvenida");
  const hayMarcas = Object.keys(marcas).some(k => !k.startsWith("__") && marcas[k] && Object.keys(marcas[k]).length);
  if (!peliculas.length || hayMarcas || hayFiltros() || pestana !== "catalogo") {
    sec.style.display = "none";
    return;
  }
  sec.innerHTML = '<div class="actividad-card"><h3>Empieza aquí</h3>' +
    '<p class="meta">Toca una película para abrir su ficha y marcarla como vista, pendiente o calificarla.</p>' +
    '<p class="meta">En el celular, desliza una tarjeta a la izquierda para marcarla como vista, o a la derecha para ponerla en pendientes. Puedes deshacerlo en seis segundos.</p>' +
    '<p class="meta">En computadora, pasa el cursor sobre una tarjeta para ver los botones rápidos.</p>' +
    '</div>';
  sec.style.display = "block";
}

// «Qué ver ahora»: una pestaña a la vez (hora o noche); si una no tiene contenido, se usa la otra
let verActual = "ahora";

function ajustarQueVer() {
  const w = $("queVer");
  const vAh = $("ahora").style.display !== "none";
  const vCe = $("cena").style.display !== "none";
  if (!vAh && !vCe) { w.style.display = "none"; return; }
  if (verActual === "ahora" && !vAh) verActual = "noche";
  if (verActual === "noche" && !vCe) verActual = "ahora";
  w.style.display = "block";
  w.classList.toggle("solo-ahora", verActual === "ahora");
  w.classList.toggle("solo-noche", verActual === "noche");
  w.querySelectorAll("[data-ver]").forEach(b => {
    const visible = b.dataset.ver === "ahora" ? vAh : vCe;
    b.style.display = visible ? "" : "none";
    b.classList.toggle("activa-ver", b.dataset.ver === verActual);
  });
}

function htmlCalendario() {
  const hoyISO = hoyLocalISO();
  if (!mesCalendario) mesCalendario = hoyISO.slice(0, 7);
  const [y, m] = mesCalendario.split("-").map(Number);

  const eventos = {};
  const agregar = (f, tipo, titulo) => {
    if (typeof f === "string" && /^\d{4}-\d{2}-\d{2}$/.test(f)) {
      (eventos[f] = eventos[f] || []).push({ tipo, titulo });
    }
  };
  peliculas.forEach(p => {
    const o = marcas[p.titulo] || {};
    const s = estadoDe(p);
    if (s.pendiente) agregar(o.pendienteDesde, "📌", p.titulo);
    if (s.conAlguien) {
      agregar(o.conAlguienDesde, "👥", p.titulo);
      agregar(o.conFecha, "📅", p.titulo);
    }
  });

  const diasMes = new Date(y, m, 0).getDate();
  const offset = (new Date(y, m - 1, 1).getDay() + 6) % 7;
  let celdas = "";
  for (let i = 0; i < offset; i++) celdas += '<div class="cal-vacio"></div>';
  for (let d = 1; d <= diasMes; d++) {
    const key = y + "-" + String(m).padStart(2, "0") + "-" + String(d).padStart(2, "0");
    const ev = eventos[key] || [];
    const chips = ev.slice(0, 2).map(e => '<div class="cal-chip">' + e.tipo + ' ' + esc(e.titulo) + '</div>').join("") +
      (ev.length > 2 ? '<div class="cal-chip">+' + (ev.length - 2) + '</div>' : "");
    celdas += '<div class="cal-dia' + (key === hoyISO ? ' hoy' : '') + '"><span class="cal-num">' + d + '</span>' + chips + '</div>';
  }

  return '<section class="cal-card">' +
    '<div class="cal-head"><button class="pildora" id="calPrev">‹</button><b>' + MESES_ES[m - 1] + ' ' + y + '</b><button class="pildora" id="calNext">›</button></div>' +
    '<div class="cal-semana"><span>L</span><span>M</span><span>X</span><span>J</span><span>V</span><span>S</span><span>D</span></div>' +
    '<div class="cal-grid">' + celdas + '</div>' +
    '<p class="meta">📌 pendiente desde · 👥 con alguien desde · 📅 fecha planeada</p>' +
  '</section>';
}

/* ---------- Sagas (requiere columna "saga" en la hoja) ---------- */
function sagasAgrupadas() {
  const mapa = {};
  peliculas.forEach(p => {
    const nombre = String(p.saga || "").trim();
    if (!nombre || nombre === "-") return; // "-" = sin saga o serie
    (mapa[nombre] = mapa[nombre] || []).push(p);
  });
  return Object.entries(mapa)
    .filter(([, lista]) => lista.length >= 2)
    .map(([nombre, lista]) => {
      const vistas = lista.filter(p => estadoDe(p).vista).length;
      const pendientesPosibles = lista.filter(p => {
        const s = estadoDe(p);
        return !s.vista && !s.pendiente && !(marcas[p.titulo] || {}).descartada;
      }).length;
      return { nombre, total: lista.length, vistas, pendientesPosibles, lista };
    })
    .sort((a, b) => (b.vistas / b.total) - (a.vistas / a.total) || a.nombre.localeCompare(b.nombre, "es"));
}

// Número de orden dentro de la saga (columna opcional "saga_orden"); null si no está escrito
function numeroOrdenSaga(p) {
  const t = String(p.saga_orden ?? "").trim();
  if (!t) return null;
  const n = Number(t.replace(",", "."));
  return isFinite(n) ? n : null;
}

// Orden de visualización: saga_orden si existe; si no, año de estreno; luego título
function ordenEnSaga(a, b) {
  const oa = numeroOrdenSaga(a), ob = numeroOrdenSaga(b);
  if (oa !== null && ob !== null && oa !== ob) return oa - ob;
  if (oa !== null && ob === null) return -1;
  if (oa === null && ob !== null) return 1;
  const ya = Number(a["año"]) || 9999, yb = Number(b["año"]) || 9999;
  if (ya !== yb) return ya - yb;
  return String(a.titulo).localeCompare(String(b.titulo), "es");
}

function etiquetaEstadoSaga(p) {
  const s = estadoDe(p);
  if (s.vista) return "✓ Vista";
  if (s.pendiente) return "⏳ Pendiente";
  if ((marcas[p.titulo] || {}).descartada) return "Descartada";
  return "Sin ver";
}

function marcarSagaPendiente(nombre) {
  const grupo = sagasAgrupadas().find(g => g.nombre === nombre);
  if (!grupo) return;
  let n = 0;
  grupo.lista.forEach(p => {
    const s = estadoDe(p);
    if (!s.vista && !s.pendiente && !(marcas[p.titulo] || {}).descartada) {
      cambiarEstado(p.titulo, { pendiente: true, vista: false });
      n++;
    }
  });
  setEstado(n ? n + " de «" + nombre + "» marcadas como pendientes." : "No había películas de esa saga para marcar.");
  pintar();
}

function renderSagas() {
  const sec = $("sagas");
  if (!peliculas.length || hayFiltros() || pestana !== "catalogo") {
    sec.style.display = "none";
    return;
  }
  const grupos = sagasAgrupadas();
  if (!grupos.length) {
    sec.style.display = "none";
    return;
  }
  sec.innerHTML = '<div class="actividad-card sagas-wrap"><h3>Sagas</h3>' +
    grupos.map(g => {
      const pct = Math.round(g.vistas / g.total * 100);
      const peliculasEnOrden = [...g.lista].sort(ordenEnSaga);
      const siguiente = peliculasEnOrden.find(p => { const e = estadoDe(p); return !e.vista && !(marcas[p.titulo] || {}).descartada; });
      const tarjetas = peliculasEnOrden.map((p, i) => {
        const n = numeroOrdenSaga(p);
        const e = estadoDe(p);
        const visto = !!e.vista;
        const esSiguiente = siguiente === p;
        const portada = (p.portada && !datosLimitados())
          ? '<img src="' + esc(p.portada) + '" alt="" loading="lazy">'
          : '<div class="sg-sinportada">🎬</div>';
        const insignia = visto ? '<span class="sg-ins ok">✓</span>' : (e.pendiente ? '<span class="sg-ins pend">⏳</span>' : '');
        return '<div class="sg-card' + (visto ? ' visto' : '') + (esSiguiente ? ' siguiente' : '') + '" data-idx="' + peliculas.indexOf(p) + '">' +
          '<div class="sg-poster">' + portada +
            '<span class="sg-num">' + esc(n !== null ? n : i + 1) + '</span>' + insignia +
            (esSiguiente ? '<span class="sg-tag">Sigue aquí</span>' : '') +
          '</div>' +
          '<div class="sg-titulo">' + esc(p.titulo) + '</div>' +
          '<div class="sg-anio">' + esc(p["año"] || "") + '</div>' +
        '</div>';
      }).join("");
      return '<div class="saga-fila sg-bloque">' +
        '<div class="sg-cabecera"><div><b class="sg-nombre">' + esc(g.nombre) + '</b>' +
          '<div class="sg-sub">' + (siguiente ? 'Siguiente: ' + esc(siguiente.titulo) : '¡Saga completa!') + '</div></div>' +
          '<div class="sg-pct">' + pct + '%</div></div>' +
        '<div class="saga-barra sg-barra"><div style="width:' + pct + '%"></div></div>' +
        '<div class="sg-tira">' + tarjetas + '</div>' +
        '<div class="sg-pie"><span class="meta">' + g.vistas + ' de ' + g.total + ' vistas</span>' +
        (g.pendientesPosibles ? '<button class="pildora" data-saga-pend="' + esc(g.nombre) + '">Marcar las que faltan como pendientes</button>' : '') +
        '</div></div>';
    }).join("") +
    '</div>';
  sec.style.display = "block";
}

/* ---------- Actores (desde la columna reparto; sin llamadas nuevas) ---------- */
function nombresReparto(p) {
  const de_reparto = String(p.reparto || "").split(",").map(x => x.trim()).filter(Boolean);
  let de_info = [];
  try { de_info = Object.keys(JSON.parse(p.actores_info || "{}") || {}); } catch (e) { de_info = []; }
  return [...new Set([...de_reparto, ...de_info])];
}

// Caché: el agrupado depende solo del catálogo; se recalcula cuando cambia la lista de películas
let actoresCache = { ref: null, n: -1, datos: null };
function actoresAgrupados() {
  if (actoresCache.ref === peliculas && actoresCache.n === peliculas.length) return actoresCache.datos;
  const mapa = {};
  peliculas.forEach(p => {
    nombresReparto(p).forEach(n => { (mapa[n] = mapa[n] || []).push(p); });
  });
  const datos = Object.entries(mapa)
    .sort((a, b) => b[1].length - a[1].length || a[0].localeCompare(b[0], "es"));
  actoresCache = { ref: peliculas, n: peliculas.length, datos };
  return datos;
}

function infoActores() {
  const mapa = {};
  peliculas.forEach(p => {
    let m = {};
    try { m = JSON.parse(p.actores_info || "{}") || {}; } catch (e) { m = {}; }
    Object.keys(m).forEach(n => {
      if (!mapa[n] || (!mapa[n].bio && m[n].bio)) mapa[n] = m[n];
    });
  });
  return mapa;
}

function fotoDeActor(nombre, info) {
  if (datosLimitados()) return "";
  return (info && info.foto) || fotosActores[nombre] || "";
}

function inicialesDe(nombre) {
  return nombre.split(/\s+/).slice(0, 2).map(x => x[0] || "").join("").toUpperCase();
}

function bioHtml(info) {
  const es = info.bio || "";
  const en = info.bio_original || "";
  if (!es && !en) return '<p class="meta">Todavía no tenemos la biografía de esta persona.</p>';
  const texto = es || en;
  const aviso = (!info.bio && en) ? ' <span class="meta">(traducción automática)</span>' : '';
  return '<p class="actor-bio" id="actorBio" data-es="' + esc(es || en) + '" data-en="' + esc(en) + '" data-vista="es">' +
    esc(texto.slice(0, 280)) + (texto.length > 280 ? '…' : '') + aviso + '</p>' +
    (texto.length > 280 ? '<button type="button" class="pildora" id="actorBioMas">Leer más</button> ' : '') +
    (en && es ? '<button type="button" class="pildora" id="actorBioIdioma">🌐 Ver original en inglés</button>' : '');
}

function fechaLarga(iso) {
  const d = new Date(String(iso) + "T12:00:00");
  return isNaN(d) ? "" : d.toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" });
}

function renderActores() {
  const sec = $("actores");
  if (!peliculas.length || hayFiltros() || pestana !== "catalogo") {
    sec.style.display = "none";
    return;
  }
  const lista = actoresAgrupados();
  if (!lista.length) { sec.style.display = "none"; return; }
  const info = infoActores();
  sec.innerHTML = '<div class="actividad-card"><h3>Actores</h3><div class="actores-grid">' +
    lista.map(([n, films]) => {
      const foto = fotoDeActor(n, info[n]);
      return '<button class="actor-card" data-actor="' + esc(n) + '">' +
        (foto ? '<img class="actor-avatar" src="' + esc(foto) + '" alt="" loading="lazy">'
              : '<span class="actor-avatar sin-foto">' + esc(inicialesDe(n)) + '</span>') +
        '<b>' + esc(n) + '</b><span class="meta">' + films.length + (films.length === 1 ? ' título' : ' títulos') + '</span>' +
        '</button>';
    }).join("") + '</div></div>';
  sec.style.display = "block";
}

function abrirActor(nombre) {
  const films = peliculas.filter(p => nombresReparto(p).includes(nombre));
  const info = infoActores()[nombre] || {};
  const foto = fotoDeActor(nombre, info);
  const vistas = films.filter(p => estadoDe(p).vista).length;
  const pendientes = films.filter(p => estadoDe(p).pendiente).length;
  const calificadas = films.filter(p => estadoDe(p).estrellas);
  const promedio = calificadas.length
    ? (calificadas.reduce((a, p) => a + estadoDe(p).estrellas, 0) / calificadas.length).toFixed(1)
    : "—";
  const nacio = info.nacimiento ? "Nació el " + fechaLarga(info.nacimiento) + (info.lugar ? " en " + info.lugar : "") : (info.lugar ? "Nació en " + info.lugar : "");
  const bio = bioHtml(info);
  $("actorTitulo").textContent = nombre;
  $("actorBody").innerHTML =
    '<div class="actor-cabecera">' +
      (foto ? '<img class="actor-foto-grande" src="' + esc(foto) + '" alt="">'
            : '<span class="actor-foto-grande sin-foto">' + esc(inicialesDe(nombre)) + '</span>') +
      '<div><p class="meta">' + esc(nacio) + '</p>' + bio + '</div>' +
    '</div>' +
    '<div class="stats-resumen">' +
      '<div class="stat"><b>' + films.length + '</b><span>títulos</span></div>' +
      '<div class="stat"><b>' + vistas + '</b><span>vistas</span></div>' +
      '<div class="stat"><b>' + pendientes + '</b><span>pendientes</span></div>' +
      '<div class="stat"><b>' + promedio + '</b><span>promedio ★</span></div>' +
    '</div>' +
    '<h4 class="actor-films-titulo">Películas en tu catálogo</h4>' +
    '<div class="actor-films">' + films.map(p => {
      const s2 = estadoDe(p);
      const estado = (marcas[p.titulo] || {}).descartada ? "descartada" : s2.vista ? "vista" : s2.pendiente ? "pendiente" : "sin ver";
      const portada = p.portada && !datosLimitados()
        ? '<img class="actor-film-poster" src="' + esc(p.portada) + '" alt="" loading="lazy">'
        : '<span class="actor-film-poster sinportada-mini">🎬</span>';
      return '<button type="button" class="actor-film" data-actor-titulo="' + esc(p.titulo) + '">' + portada +
        '<b>' + esc(p.titulo) + '</b><span class="meta">' + esc(p["año"] || "") + ' · ' + estado +
        (s2.estrellas ? ' · ' + s2.estrellas + '★' : '') + '</span></button>';
    }).join("") + '</div>';
  $("actorBody").onclick = e => {
    const bioEl = $("actorBio");
    if (!bioEl) return;
    const mas = e.target.closest("#actorBioMas");
    if (mas) {
      bioEl.textContent = bioEl.dataset.vista === "en" ? bioEl.dataset.en : bioEl.dataset.es;
      mas.remove();
      return;
    }
    const idioma = e.target.closest("#actorBioIdioma");
    if (idioma) {
      const verEn = bioEl.dataset.vista !== "en";
      bioEl.dataset.vista = verEn ? "en" : "es";
      bioEl.textContent = verEn ? bioEl.dataset.en : bioEl.dataset.es;
      idioma.textContent = verEn ? "🌐 Ver en español" : "🌐 Ver original en inglés";
      const mas2 = document.getElementById("actorBioMas");
      if (mas2) mas2.remove();
    }
  };
  $("actorModal").classList.add("abierto");
}

function cerrarActor() {
  $("actorModal").classList.remove("abierto");
}

/* ---------- Mis filtros guardados ---------- */
function leerPresets() { return Array.isArray(marcas.__filtros) ? marcas.__filtros : []; }

// Los filtros viven dentro de marcas.json (en tu Drive), bajo la clave reservada "__filtros"
function guardarListaPresets(lista) {
  marcas.__filtros = lista;
  programarGuardado();
}

function renderPresets() {
  const lista = leerPresets();
  $("presetsSel").innerHTML = '<option value="">Filtros guardados…</option>' +
    lista.map((x, i) => '<option value="' + i + '">' + esc(x.nombre) + '</option>').join("");
}

function guardarPreset() {
  const nombre = (prompt("Nombre para estos filtros:", "") || "").trim();
  if (!nombre) return;
  const valores = { buscar: buscar.value, orden: $("orden").value };
  Object.entries(sel).forEach(([k, el]) => { valores[k] = el.value; });
  const lista = leerPresets().filter(x => x.nombre !== nombre);
  lista.push({ nombre, valores });
  guardarListaPresets(lista);
  renderPresets();
  setEstado("Filtros guardados como «" + nombre + "».");
}

function aplicarPreset() {
  const i = $("presetsSel").value;
  if (i === "") return;
  const p = leerPresets()[Number(i)];
  if (!p) return;
  buscar.value = p.valores.buscar || "";
  $("orden").value = p.valores.orden || $("orden").value;
  Object.entries(sel).forEach(([k, el]) => { el.value = p.valores[k] || ""; });
  pintar();
}

function borrarPreset() {
  const i = $("presetsSel").value;
  if (i === "") return;
  const lista = leerPresets();
  const x = lista[Number(i)];
  if (!x) return;
  if (!confirm("¿Borrar «" + x.nombre + "»?")) return;
  lista.splice(Number(i), 1);
  guardarListaPresets(lista);
  renderPresets();
}

/* ---------- ¿Qué sigue? (desde una película vista) ---------- */
function siguienteHtml(p) {
  if (!estadoDe(p).vista) return "";
  const libre = x => x !== p && !estadoDe(x).vista && !(marcas[x.titulo] || {}).descartada;
  let cands = [], razon = "";
  if (p.saga && p.saga !== "-") {
    cands = peliculas.filter(x => libre(x) && x.saga === p.saga);
    if (cands.length) razon = "De la saga " + p.saga;
  }
  if (!cands.length) {
    const dirs = directoresDe(p);
    if (dirs.length) {
      cands = peliculas.filter(x => libre(x) && directoresDe(x).some(d => dirs.includes(d)));
      if (cands.length) razon = "Del mismo director";
    }
  }
  cands = cands.slice(0, 3);
  if (!cands.length) return "";
  return '<div class="siguiente"><b>¿Qué sigue?</b> <span class="meta">' + esc(razon) + '</span>' +
    '<div class="insignias" style="margin-top:6px">' +
      cands.map(x => '<button class="pildora" data-siguiente="' + esc(x.titulo) + '">' + esc(x.titulo) + '</button>').join("") +
    '</div></div>';
}

/* ---------- Historial de cambios de una película ---------- */
function historialHtml(p) {
  const h = (marcas[p.titulo] || {}).historial || [];
  if (!h.length) return "";
  return '<details class="historial"><summary>Historial (' + h.length + ')</summary><ul>' +
    h.slice().reverse().map(e => '<li>' + esc(e.f) + ' · ' + esc(e.a) + '</li>').join("") +
    '</ul></details>';
}

/* ---------- Orden de notas ---------- */
function ordenNotasFn() {
  const v = $("ordenNotas") ? $("ordenNotas").value : "fecha";
  const m = t => marcas[t] || {};
  const porFecha = (a, b) => String(m(b.titulo).notaFecha || "").localeCompare(String(m(a.titulo).notaFecha || ""));
  if (v === "titulo") return (a, b) => String(a.titulo).localeCompare(String(b.titulo), "es");
  if (v === "calif") return (a, b) => ((m(b.titulo).estrellas || 0) - (m(a.titulo).estrellas || 0)) || porFecha(a, b);
  return porFecha;
}

/* ---------- Actividad: racha, insignias y compartir recomendación ---------- */
function sumarDiasISO(iso, n) {
  const [y, m, d] = iso.split("-").map(Number);
  const x = new Date(y, m - 1, d + n);
  x.setMinutes(x.getMinutes() - x.getTimezoneOffset());
  return x.toISOString().slice(0, 10);
}

function inicioSemanaISO(iso) {
  const [y, m, d] = iso.split("-").map(Number);
  const x = new Date(y, m - 1, d);
  const dow = (x.getDay() + 6) % 7;
  return sumarDiasISO(iso, -dow);
}

function vistasConFecha() {
  return peliculas.filter(p => {
    const m = marcas[p.titulo] || {};
    return m.vista && typeof m.vistaDesde === "string" && /^\d{4}-\d{2}-\d{2}$/.test(m.vistaDesde);
  });
}

function rachaSemanas() {
  const semanas = new Set(vistasConFecha().map(p => inicioSemanaISO((marcas[p.titulo] || {}).vistaDesde)));
  let cursor = inicioSemanaISO(hoyLocalISO());
  if (!semanas.has(cursor)) cursor = sumarDiasISO(cursor, -7);
  let racha = 0;
  while (semanas.has(cursor)) {
    racha++;
    cursor = sumarDiasISO(cursor, -7);
  }
  return racha;
}

function maxVistasEnUnMes() {
  const porMes = {};
  vistasConFecha().forEach(p => {
    const k = (marcas[p.titulo] || {}).vistaDesde.slice(0, 7);
    porMes[k] = (porMes[k] || 0) + 1;
  });
  return Math.max(0, ...Object.values(porMes));
}

function insigniasDeActividad() {
  const vistas = vistasConFecha().length;
  const totalVistas = peliculas.filter(p => estadoDe(p).vista).length;
  const racha = rachaSemanas();
  const mesMax = maxVistasEnUnMes();
  return [
    { t: "Primera vista", ok: totalVistas >= 1 },
    { t: "10 vistas", ok: totalVistas >= 10 },
    { t: "25 vistas", ok: totalVistas >= 25 },
    { t: "50 vistas", ok: totalVistas >= 50 },
    { t: "Racha de 3 semanas", ok: racha >= 3 },
    { t: "5 vistas en un mes", ok: mesMax >= 5 }
  ];
}

/* ---------- Racha de calificaciones: películas calificadas esta semana (lunes a hoy) ---------- */
// Usa el historial. Cada película cuenta una vez, con su última acción de la semana.
// Si la última acción fue quitar la calificación, no cuenta.
function calificacionesDeSemana() {
  const hoy = hoyLocalISO();
  const inicio = inicioSemanaISO(hoy);
  const salida = [];
  peliculas.forEach(p => {
    const h = (marcas[p.titulo] || {}).historial || [];
    const evs = h.filter(e => e.f >= inicio && e.f <= hoy &&
      (String(e.a).indexOf("calificada") === 0 || e.a === "sin calificación"));
    if (!evs.length) return;
    const ultimo = evs[evs.length - 1];
    if (ultimo.a === "sin calificación") return;
    salida.push({ p, estrellas: Number(String(ultimo.a).replace("calificada ", "").replace("★", "")) });
  });
  return salida;
}

function textoCalificaciones() {
  const cal = calificacionesDeSemana();
  if (!cal.length) return "Aún no calificas películas esta semana.";
  const n = cal.length;
  let texto = "Calificaste " + n + (n === 1 ? " película" : " películas") + " esta semana";
  if (n >= 3) {
    const prom = cal.reduce((a, x) => a + x.estrellas, 0) / n;
    texto += " · promedio " + prom.toFixed(1) + "★";
  }
  return texto + ".";
}

function renderActividad() {
  const sec = $("actividad");
  const hayFiltrosAct = hayFiltros();
  if (!peliculas.length || pestana !== "vistas") {
    sec.style.display = "none";
    return;
  }
  const racha = rachaSemanas();
  const insignias = insigniasDeActividad();
  const lineaCal = textoCalificaciones();
  sec.innerHTML =
    '<div class="actividad-card">' +
      '<h3>Tu actividad</h3>' +
      '<p class="racha">Racha: <b>' + racha + '</b> ' + (racha === 1 ? 'semana' : 'semanas') + ' seguidas con alguna vista</p>' +
      '<p class="meta">' + esc(lineaCal) + '</p>' +
      '<div class="insignias">' +
        insigniasDeActividad().map(i =>
          '<span class="insignia' + (i.ok ? '' : ' bloq') + '">' + (i.ok ? '🏅 ' : '🔒 ') + esc(i.t) + '</span>'
        ).join("") +
      '</div>' +
    '</div>';
  sec.style.display = "block";
}

function textoRecomendacion(r) {
  const f = r.desglose.find(d => d.puntos > 0);
  const fuente = f && f.fuentes && f.fuentes[0];
  const razon = r.razon || (f ? f.etiqueta : "");
  return "Te recomiendo «" + r.p.titulo + "»" +
    (razon ? " — " + razon : "") +
    (fuente ? ", que te gustó en " + fuente.titulo : "") + ".";
}

async function compartirRecomendacion() {
  const r = calcularRecomendaciones()[0];
  if (!r) { setEstado("Aún no hay recomendación para compartir."); return; }
  const texto = textoRecomendacion(r);
  if (navigator.share) {
    try { await navigator.share({ text: texto }); } catch (e) {}
    return;
  }
  try {
    await navigator.clipboard.writeText(texto);
    setEstado("Recomendación copiada.");
  } catch (e) {
    setEstado(texto);
  }
}

/* ---------- Recomendaciones según calificaciones ---------- */
function calcularRecomendaciones() {
  const pesoGenero = {}, pesoDirector = {};
  const fuentesGenero = {}, fuentesDirector = {};
  const restaGenero = {}, restaDirector = {};
  const fuentesRestaGenero = {}, fuentesRestaDirector = {};

  peliculas.forEach(p => {
    const s = estadoDe(p);
    if (s.estrellas >= 4) {
      generosDe(p).forEach(g => {
        pesoGenero[g] = (pesoGenero[g] || 0) + 1;
        (fuentesGenero[g] = fuentesGenero[g] || []).push({ titulo: p.titulo, estrellas: s.estrellas });
      });
      directoresDe(p).forEach(d => {
        pesoDirector[d] = (pesoDirector[d] || 0) + 2;
        (fuentesDirector[d] = fuentesDirector[d] || []).push({ titulo: p.titulo, estrellas: s.estrellas });
      });
    }
    if ((marcas[p.titulo] || {}).descartada) {
      generosDe(p).forEach(g => {
        restaGenero[g] = (restaGenero[g] || 0) + 1;
        (fuentesRestaGenero[g] = fuentesRestaGenero[g] || []).push({ titulo: p.titulo });
      });
      directoresDe(p).forEach(d => {
        restaDirector[d] = (restaDirector[d] || 0) + 2;
        (fuentesRestaDirector[d] = fuentesRestaDirector[d] || []).push({ titulo: p.titulo });
      });
    }
  });

  if (!Object.keys(pesoGenero).length && !Object.keys(pesoDirector).length) return [];

  const candidatas = [];
  peliculas.forEach(p => {
    const o = marcas[p.titulo] || {};
    if (o.vista || o.pendiente || o.descartada || o.estrellas) return;

    let puntaje = 0;
    let mejorRazon = null, mejorPeso = 0;
    const desglose = [];

    directoresDe(p).forEach(d => {
      const w = pesoDirector[d] || 0;
      const r = restaDirector[d] || 0;
      if (w > 0) {
        puntaje += w;
        desglose.push({ etiqueta: "Director " + d, puntos: w, fuentes: fuentesDirector[d] });
        if (w > mejorPeso) { mejorPeso = w; mejorRazon = "Por el director " + d; }
      }
      if (r > 0) {
        puntaje -= r;
        desglose.push({ etiqueta: "Director " + d, puntos: -r, fuentes: fuentesRestaDirector[d] });
      }
    });
    generosDe(p).forEach(g => {
      const w = pesoGenero[g] || 0;
      const r = restaGenero[g] || 0;
      if (w > 0) {
        puntaje += w;
        desglose.push({ etiqueta: "Género " + g, puntos: w, fuentes: fuentesGenero[g] });
        if (w > mejorPeso) { mejorPeso = w; mejorRazon = "Género: " + g; }
      }
      if (r > 0) {
        puntaje -= r;
        desglose.push({ etiqueta: "Género " + g, puntos: -r, fuentes: fuentesRestaGenero[g] });
      }
    });

    if (puntaje > 0) candidatas.push({ p, puntaje, razon: mejorRazon, desglose });
  });

  candidatas.sort((a, b) => b.puntaje - a.puntaje || String(a.p.titulo).localeCompare(String(b.p.titulo), "es"));
  return candidatas.slice(0, 6);
}

// Convierte el desglose en una frase corta y legible
function fraseRecomendacion(r) {
  const positivos = r.desglose.filter(d => d.puntos > 0);
  const negativos = r.desglose.filter(d => d.puntos < 0);

  if (!positivos.length) {
    return "Tiene géneros o directores que descartaste antes.";
  }

  // Los directores pesan más, así que tienen prioridad
  const dir = positivos.find(d => d.etiqueta.startsWith("Director "));
  const base = dir || positivos[0];
  const nombre = base.etiqueta.replace(/^(Director|Género) /, "");

  const titulos = base.fuentes
    .slice()
    .sort((a, b) => b.estrellas - a.estrellas)
    .map(f => "«" + f.titulo + "»");

  let lista;
  if (titulos.length === 1) lista = titulos[0];
  else if (titulos.length === 2) lista = titulos[0] + " y " + titulos[1];
  else lista = titulos[0] + " y " + titulos[1] + " y " + (titulos.length - 2) + " más";

  let frase = dir
    ? "Porque te gustó " + lista + ", dirigida por " + nombre
    : "Porque te gustaron " + lista + ", que comparten el género " + nombre;

  if (negativos.length) frase += ". Ojo: hay algo parecido a lo que descartaste";
  return frase + ".";
}

// Desglose legible: los puntos negativos muestran la película descartada que los causó
function lineasPorQue(desglose) {
  return desglose.map(d => {
    if (d.puntos < 0) {
      const f = d.fuentes[0];
      const otras = d.fuentes.length - 1;
      return d.etiqueta + " (" + d.puntos + ", por descartada: " + f.titulo +
        (otras > 0 ? " y " + otras + " más" : "") + ")";
    }
    const fuentes = d.fuentes.slice().sort((a, b) => b.estrellas - a.estrellas);
    const mejor = fuentes[0];
    const otras = fuentes.length - 1;
    return d.etiqueta + " (+" + d.puntos + ", por tu " + mejor.estrellas + "★ en " + mejor.titulo +
      (otras > 0 ? " y " + otras + " más" : "") + ")";
  });
}

function renderRecomendaciones() {
  const sec = $("recomendaciones");
  if (hayFiltros() || pestana !== "catalogo") {
    sec.style.display = "none";
    return;
  }
  const recs = calcularRecomendaciones();
  if (!recs.length) {
    sec.style.display = "none";
    return;
  }
  sec.style.display = "block";
  $("recomCarrusel").innerHTML = recs.map(r => {
    const idx = peliculas.indexOf(r.p);
    const img = (r.p.portada && !datosLimitados())
      ? '<img src="' + esc(r.p.portada) + '" alt="">'
      : '<div class="sinportada-mini">🎬</div>';
    const abierto = porQueAbiertos.has(r.p.titulo);
    const detalle = abierto
      ? '<p class="porque-lista">' + esc(fraseRecomendacion(r)) + '</p>' +
        '<ul class="porque-lista porque-desglose">' +
        lineasPorQue(r.desglose).map(l => '<li>' + esc(l) + '</li>').join('') + '</ul>'
      : '';
    return '<div class="dest" data-idx="' + idx + '">' + img +
      '<div class="dest-titulo">' + esc(r.p.titulo) + '</div>' +
      '<div class="dest-anio">' + esc(r.p["año"]) + '</div>' +
      '<div class="dest-razon">' + esc(r.razon) + '</div>' +
      '<button class="pildora porque-btn" data-porque="' + idx + '">' + (abierto ? 'Ocultar' : '¿Por qué?') + '</button>' +
      detalle + '</div>';
  }).join("");
}

/* ---------- Paleta de 3 colores del póster ---------- */
function distancia(a, b) {
  return Math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2);
}

function paletaDePoster(url) {
  if (paletaCache.has(url)) return Promise.resolve(paletaCache.get(url));
  return new Promise(resolve => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        const w = 64;
        const h = Math.max(1, Math.round(w * img.height / img.width));
        const c = document.createElement("canvas");
        c.width = w; c.height = h;
        const ctx = c.getContext("2d");
        ctx.drawImage(img, 0, 0, w, h);
        const datos = ctx.getImageData(0, 0, w, h).data;

        const cubos = {};
        let total = 0;
        for (let i = 0; i < datos.length; i += 4) {
          const r = datos[i], g = datos[i + 1], b = datos[i + 2];
          const max = Math.max(r, g, b), min = Math.min(r, g, b);
          if (max < 15 || min > 240) continue;
          if (max - min < 10) continue;
          total++;
          const clave = (r >> 4) + "," + (g >> 4) + "," + (b >> 4);
          const cubo = cubos[clave] || (cubos[clave] = { n: 0, r: 0, g: 0, b: 0 });
          cubo.n++; cubo.r += r; cubo.g += g; cubo.b += b;
        }

        const grupos = Object.values(cubos)
          .filter(c => total && c.n / total >= 0.01)
          .map(c => ({ n: c.n, rgb: [Math.round(c.r / c.n), Math.round(c.g / c.n), Math.round(c.b / c.n)] }))
          .sort((a, b) => b.n - a.n);

        const elegidos = [];
        for (const g of grupos) {
          if (elegidos.length >= 3) break;
          if (elegidos.every(e => distancia(e, g.rgb) > 40)) elegidos.push(g.rgb);
        }

        if (elegidos.length === 0) elegidos.push([100, 100, 100], [60, 60, 60], [30, 30, 30]);

        paletaCache.set(url, elegidos);
        resolve(elegidos);
      } catch (e) {
        paletaCache.set(url, []);
        resolve([]);
      }
    };
    img.onerror = () => resolve([]);
    img.src = "https://tmdb-proxy.240300696.workers.dev/?url=" + encodeURIComponent(String(url));
  });
}

function rgbAHex(rgb) {
  return "#" + rgb.map(v => v.toString(16).padStart(2, "0")).join("");
}

function hexARgb(hex) {
  const m = String(hex).trim().match(/^#([0-9a-f]{6})$/i);
  if (!m) return null;
  const v = m[1];
  return [parseInt(v.slice(0, 2), 16), parseInt(v.slice(2, 4), 16), parseInt(v.slice(4, 6), 16)];
}

function paletaDeTexto(texto) {
  return String(texto || "").split(",").map(hexARgb).filter(Boolean).slice(0, 3);
}

function fondoDesde(paleta) {
  const [a, b, c] = paleta.length >= 3 ? paleta : (paleta.length ? [paleta[0], paleta[0], paleta[0]] : [[0,0,0],[0,0,0],[0,0,0]]);
  return `radial-gradient(circle at 0% 0%, rgba(${a.join(",")}, 0.2) 0%, transparent 50%), ` +
         `radial-gradient(circle at 100% 0%, rgba(${b.join(",")}, 0.2) 0%, transparent 50%), ` +
         `radial-gradient(circle at 50% -20%, rgba(${c.join(",")}, 0.25) 0%, transparent 60%), ` +
         `var(--tarjeta)`;
}

const PALETA_RESPALDO = [[140, 150, 170], [100, 110, 130], [60, 66, 84]];

function aplicarFondoModal(caja, posterModal, paleta) {
  caja.style.background = fondoDesde(paleta);
  if (posterModal) {
    posterModal.style.boxShadow = `0 12px 32px rgba(${paleta[0].join(",")}, 0.5)`;
  }
}

function aplicarPaleta(p) {
  const caja = document.querySelector("#modal .ventana");
  if (!caja) return;

  const paletaHoja = paletaDeTexto(p[NOMBRE_PALETA]);
  if (paletaHoja.length) {
    aplicarFondoModal(caja, caja.querySelector(".portada"), paletaHoja);
    return;
  }

  aplicarFondoModal(caja, caja.querySelector(".portada"), PALETA_RESPALDO);
  if (!p.portada || datosLimitados()) return;

  paletaDePoster(p.portada).then(calc => {
    if (calc.length && detalleActual === p) {
      aplicarFondoModal(caja, caja.querySelector(".portada"), calc);
    }
  });
}

function letraColumna(n) {
  let s = "";
  n = n + 1;
  while (n > 0) {
    const m = (n - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

async function sheetsFetch(path, metodo, cuerpo) {
  const r = await fetch("https://sheets.googleapis.com/v4/spreadsheets/" + HOJA_ID + "/" + path, {
    method: metodo || "GET",
    headers: { Authorization: "Bearer " + accessToken, "Content-Type": "application/json" },
    body: cuerpo ? JSON.stringify(cuerpo) : undefined
  });
  if (!r.ok) throw new Error("Sheets respondió " + r.status);
  return r.json();
}

/* ---------- Guardar paletas en la hoja (solo cuenta dueña) ---------- */
async function asegurarColumnaPaleta() {
  if (COL_PALETA !== -1) return;
  COL_PALETA = encabezados.length;
  encabezados.push(NOMBRE_PALETA);
  await sheetsFetch("values/" + letraColumna(COL_PALETA) + "1?valueInputOption=RAW", "PUT", {
    values: [[NOMBRE_PALETA]]
  });
}

async function guardarPaletasEnHoja() {
  const pendientes = peliculas.filter(p => !paletaDeTexto(p[NOMBRE_PALETA]).length && p.portada);
  if (!pendientes.length) {
    setEstado("Todas las portadas ya tienen paleta guardada.");
    return;
  }
  setEstado("Calculando paletas de " + pendientes.length + " películas...");
  const cambios = [];
  for (const p of pendientes) {
    const calc = await paletaDePoster(p.portada);
    if (calc.length) {
      p[NOMBRE_PALETA] = calc.map(rgbAHex).join(",");
      cambios.push(p);
    }
  }
  if (!cambios.length) {
    setEstado("No pude leer las portadas en este navegador.");
    return;
  }
  try {
    await asegurarColumnaPaleta();
    const data = cambios.map(p => ({
      range: letraColumna(COL_PALETA) + p._fila,
      values: [[p[NOMBRE_PALETA]]]
    }));
    await sheetsFetch("values:batchUpdate", "POST", { valueInputOption: "RAW", data: data });
    setEstado("Paletas guardadas en la hoja: " + cambios.length);
  } catch (e) {
    setEstado("No pude guardar en la hoja. Esta opción solo funciona con la cuenta dueña de la hoja.");
  }
}

/* ---------- Marcas personales en Drive ---------- */
function marcasLocales() {
  try { return JSON.parse(localStorage.getItem("catalogo_estado") || "{}"); } catch (e) { return {}; }
}

async function driveFetch(url, opts = {}) {
  const headers = Object.assign({ Authorization: "Bearer " + accessToken }, opts.headers || {});
  const r = await fetch(url, Object.assign({}, opts, { headers }));
  if (!r.ok) throw new Error("Drive respondió " + r.status);
  return r;
}

function estadoDe(p) {
  const o = marcas[p.titulo] || {};
  return {
    vista: !!o.vista,
    pendiente: !!o.pendiente,
    estrellas: o.estrellas || 0,
    conAlguien: !!o.conAlguien
  };
}

function cambiarEstado(titulo, cambios) {
  const previo = marcas[titulo] || {};
  const nuevo = Object.assign({}, previo, cambios);
  if (cambios.vista === true) {
    if (previo.conAlguien && previo.conQuien) nuevo.vistaCon = previo.conQuien;
    else delete nuevo.vistaCon;
  }
  if (cambios.vista === false) delete nuevo.vistaCon;
  if (cambios.pendiente === true && !previo.pendiente) {
    nuevo.pendienteDesde = new Date().toISOString().slice(0, 10);
  }
  if (cambios.pendiente === false || (cambios.pendiente === undefined && !nuevo.pendiente)) {
    delete nuevo.pendienteDesde;
  }
  if (cambios.vista === true || cambios.descartada === true) {
    delete nuevo.conAlguien;
    delete nuevo.conQuien;
    delete nuevo.conAlguienDesde;
    delete nuevo.conFecha;
  }
  if (cambios.descartada === true && !previo.descartada) {
    nuevo.descartadaDesde = new Date().toISOString().slice(0, 10);
    delete nuevo.revisionHecha;
  }
  if (cambios.descartada === false) {
    delete nuevo.descartadaDesde;
    delete nuevo.revisionHecha;
  }
  const eventos = [];
  if (cambios.pendiente === true && !previo.pendiente) eventos.push("pendiente");
  if (cambios.vista === true && !previo.vista) eventos.push("vista");
  if (cambios.descartada === true && !previo.descartada) eventos.push("descartada");
  if (cambios.estrellas !== undefined && cambios.estrellas !== (previo.estrellas || 0)) {
    eventos.push(cambios.estrellas ? "calificada " + cambios.estrellas + "★" : "sin calificación");
  }
  if (eventos.length) {
    const hoyH = hoyLocalISO();
    nuevo.historial = (previo.historial || []).concat(eventos.map(a => ({ f: hoyH, a }))).slice(-30);
  }
  marcas[titulo] = nuevo;
  programarGuardado();
}

function alternarConAlguien(titulo) {
  const previo = marcas[titulo] || {};
  if (previo.conAlguien) {
    const nuevo = Object.assign({}, previo);
    delete nuevo.conAlguien;
    delete nuevo.conQuien;
    delete nuevo.conAlguienDesde;
    delete nuevo.conFecha;
    marcas[titulo] = nuevo;
    programarGuardado();
    setEstado("Quitada de «Para ver con alguien».");
    return;
  }
  const quien = prompt("¿Con quién la quieres ver? (opcional, puedes dejarlo vacío)", "");
  if (quien === null) return;
  const fecha = prompt("¿Qué día la quieren ver? (opcional, formato AAAA-MM-DD, por ejemplo 2026-11-15)", "");
  if (fecha === null) return;

  const nuevo = Object.assign({}, previo, {
    conAlguien: true,
    conAlguienDesde: new Date().toISOString().slice(0, 10)
  });
  const q = String(quien).trim();
  if (q) nuevo.conQuien = q; else delete nuevo.conQuien;

  const f = String(fecha).trim();
  let aviso = "";
  if (f) {
    if (fechaValida(f)) nuevo.conFecha = f;
    else aviso = " La fecha no era válida, así que se guardó sin fecha.";
  } else {
    delete nuevo.conFecha;
  }

  marcas[titulo] = nuevo;
  programarGuardado();
  if (!nuevo.pendiente) {
    setEstado("Marcada para ver con alguien." + aviso + " Si la quieres ver pronto, también puedes ponerla en pendientes.");
  } else {
    setEstado("Marcada para ver con alguien." + aviso);
  }
}

function cambiarFechaConAlguien(titulo) {
  const previo = marcas[titulo] || {};
  if (!previo.conAlguien) {
    setEstado("Primero marca la película como «Para ver con alguien».");
    return;
  }
  const txt = prompt("Fecha para verla (AAAA-MM-DD). Déjalo vacío para quitar la fecha.", previo.conFecha || "");
  if (txt === null) return;
  const f = String(txt).trim();
  const nuevo = Object.assign({}, previo);
  if (!f) {
    delete nuevo.conFecha;
    setEstado("Fecha quitada.");
  } else if (!fechaValida(f)) {
    setEstado("Fecha no válida. Usa el formato AAAA-MM-DD, por ejemplo 2026-11-15.");
    return;
  } else {
    nuevo.conFecha = f;
    setEstado("Fecha guardada: " + f + ".");
  }
  marcas[titulo] = nuevo;
  programarGuardado();
}

function guardarNota(titulo, texto) {
  const t = String(texto || "").trim();
  const nuevo = Object.assign({}, marcas[titulo] || {});
  if (t) {
    nuevo.nota = t;
    nuevo.notaFecha = new Date().toISOString().slice(0, 10);
  } else {
    delete nuevo.nota;
    delete nuevo.notaFecha;
  }
  marcas[titulo] = nuevo;
  programarGuardado();
}

function borrarNota() {
  if (!detalleActual) return;
  const ok = confirm("¿Borrar tu nota de esta película? No se puede deshacer.");
  if (!ok) return;
  guardarNota(detalleActual.titulo, "");
  setEstado("Nota borrada");
  abrirDetalle(detalleActual);
}

/* ---------- Respaldo y restauración de marcas ---------- */
let ultimaSyncOk = null;   // momento de la última sincronización correcta con Drive

function respaldarMarcas() {
  const datos = {
    formato: "catalogo-marcas",
    version: 1,
    fecha: new Date().toISOString(),
    marcas: marcas
  };
  const blob = new Blob([JSON.stringify(datos, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "respaldo-catalogo-" + hoyLocalISO() + ".json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  setEstado("Respaldo descargado: " + Object.keys(marcas).length + " películas con marcas.");
}

function validarRespaldo(texto) {
  let datos;
  try { datos = JSON.parse(texto); } catch (e) { return { error: "El archivo no es un JSON válido." }; }
  if (!datos || typeof datos !== "object") return { error: "El archivo no es un respaldo válido." };
  const esNuevo = datos.formato === "catalogo-marcas";
  const esViejo = datos.app === "catalogo-peliculas" || (!datos.formato && !datos.app);
  if (!esNuevo && !esViejo) return { error: "Este archivo no es un respaldo de marcas del catálogo." };
  if (datos.version !== undefined && datos.version !== 1) return { error: "Versión de respaldo no compatible." };
  if (!datos.marcas || typeof datos.marcas !== "object" || Array.isArray(datos.marcas)) return { error: "El respaldo no tiene marcas válidas." };
  return { marcas: datos.marcas };
}

async function restaurarMarcasDesdeArchivo(archivo) {
  let texto;
  try { texto = await archivo.text(); } catch (e) { setEstado("No pude leer el archivo."); return; }
  const res = validarRespaldo(texto);
  if (res.error) { setEstado(res.error); return; }

  const n = Object.keys(res.marcas).filter(k => !k.startsWith("__")).length;
  const ok = confirm("¿Reemplazar tus marcas actuales (" + Object.keys(marcas).filter(k => !k.startsWith("__")).length + ") por las de este respaldo (" + n + " películas)? Esto también reemplaza tus filtros guardados. Las marcas actuales se perderán.");
  if (!ok) { setEstado("Restauración cancelada."); return; }

  clearTimeout(guardadoTimer);
  marcas = envolverMarcas(res.marcas);
  syncPendiente = true; syncGuardarLocal();
  await guardarMarcasDrive();
  refrescarTodo();
  setEstado("Marcas restauradas: " + n + " películas.");
}

/* ---------- Etiquetas con # dentro de las notas ---------- */
const TAG_RE = /#[\p{L}\p{N}_-]+/gu;

function etiquetasDeNota(texto) {
  const encontradas = String(texto || "").match(TAG_RE) || [];
  const vistos = new Set();
  const salida = [];
  encontradas.forEach(t => {
    const limpia = t.slice(1).toLowerCase();
    const clave = norm(limpia);
    if (!clave || vistos.has(clave)) return;
    vistos.add(clave);
    salida.push(limpia);
  });
  return salida;
}

function coincideEtiqueta(p, etiqueta) {
  const m = marcas[p.titulo] || {};
  const buscada = norm(etiqueta);
  return etiquetasDeNota(m.nota).some(t => norm(t) === buscada);
}

function etiquetasFichaHtml(texto) {
  const tags = etiquetasDeNota(texto);
  if (!tags.length) {
    return '<span class="ayuda-etiquetas">Escribe #palabra en tu nota para crear etiquetas.</span>';
  }
  return tags.map(t => '<button class="etiqueta" data-tag="' + esc(t) + '">#' + esc(t) + '</button>').join("");
}

function renderBarraEtiquetas() {
  const bar = $("tagsNotas");
  const conteo = new Map();
  peliculas.forEach(p => {
    etiquetasDeNota((marcas[p.titulo] || {}).nota).forEach(t => {
      const clave = norm(t);
      const previo = conteo.get(clave) || { t, n: 0 };
      previo.n++;
      conteo.set(clave, previo);
    });
  });
  if (!conteo.size) {
    bar.style.display = "none";
    bar.innerHTML = "";
    return;
  }
  const actual = norm(buscar.value.trim());
  const orden = [...conteo.values()].sort((a, b) => b.n - a.n || a.t.localeCompare(b.t, "es"));
  bar.style.display = "flex";
  bar.innerHTML = orden.map(x =>
    '<button class="etiqueta' + (actual === "#" + norm(x.t) ? ' activa' : '') + '" data-tag="' + esc(x.t) + '">#' +
    esc(x.t) + ' (' + x.n + ')</button>'
  ).join("");
}

document.addEventListener("change", e => {
  if (e.target.id === "notaTexto" && detalleActual) {
    guardarNota(detalleActual.titulo, e.target.value);
    const zona = $("etiquetasFicha");
    if (zona) zona.innerHTML = etiquetasFichaHtml(e.target.value);
    setEstado("Nota guardada");
  }
});

document.addEventListener("input", e => {
  if (e.target.id === "preguntaTexto") $("preguntaContador").textContent = e.target.value.length + "/500";
});

/* ---------- Bloques plegables (se recuerda cuáles están cerrados) ---------- */
const PLEGADAS_POR_DEFECTO = ["sagas", "actores", "mapaGustos"];

function leerPliegues() {
  const guardado = leerJSON("pliegues", null);
  if (guardado) return guardado;
  const o = {};
  PLEGADAS_POR_DEFECTO.forEach(id => { o[id] = true; });
  return o;
}

function aplicarPliegues() {
  const o = leerPliegues();
  document.querySelectorAll("section[id]").forEach(s => s.classList.toggle("plegado", s.id !== "sagas" && !!o[s.id]));
}

document.addEventListener("click", e => {
  const h = e.target.closest ? e.target.closest("section[id] h3") : null;
  if (!h) return;
  const s = h.closest("section[id]");
  if (s.id === "sagas") return;
  s.classList.toggle("plegado");
  const o = leerPliegues();
  o[s.id] = s.classList.contains("plegado");
  guardarJSON("pliegues", o);
});

aplicarPliegues();

document.addEventListener("click", e => {
  if (e.target.closest && e.target.closest("#toggleMas")) alternarPanel("panelMas");
});

vistaLista = modoGuardado("vista_tarjetas", "amplia") === "compacta";
document.body.classList.toggle("lista", vistaLista);
$("vista").textContent = vistaLista ? "Vista amplia" : "Vista compacta";

// Toque largo en celular: muestra las acciones rápidas de la tarjeta (se cierran al tocar fuera)
let suprimirClic = false;

function abrirRapida(card) {
  document.querySelectorAll(".rapida-abierta").forEach(x => x.classList.remove("rapida-abierta"));
  card.classList.add("rapida-abierta");
  if (navigator.vibrate) navigator.vibrate(15);
}

document.addEventListener("click", e => {
  if (!e.target.closest || !e.target.closest(".rapida-abierta")) {
    document.querySelectorAll(".rapida-abierta").forEach(x => x.classList.remove("rapida-abierta"));
  }
});

/* ---------- Fechas ---------- */
function fechaValida(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

function diasHasta(s) {
  const [y, m, d] = s.split("-").map(Number);
  const obj = Date.UTC(y, m - 1, d);
  const hoy = new Date();
  const hoyUTC = Date.UTC(hoy.getFullYear(), hoy.getMonth(), hoy.getDate());
  return Math.round((obj - hoyUTC) / 86400000);
}

function lineaFechaConAlguien(p) {
  const m = marcas[p.titulo] || {};
  if (!m.conFecha) return '<div class="meta" style="margin-top:6px">📅 Sin fecha</div>';
  const d = diasHasta(m.conFecha);
  const cuando = d === 0 ? "hoy" : d === 1 ? "mañana" : d < 0 ? "pasó hace " + (-d) + " días" : "en " + d + " días";
  return '<div class="meta" style="margin-top:6px">📅 ' + esc(m.conFecha) + ' · ' + cuando + '</div>';
}

// Recordatorio: planes con alguien hoy, mañana o pasado mañana. "×" lo oculta por hoy.
function recordatoriosActivos() {
  const hoy = hoyLocalISO();
  const cerrados = leerJSON("recordatorio_cerrados", []);
  const salida = [];
  peliculas.forEach(p => {
    const m = marcas[p.titulo] || {};
    if (!m.conAlguien || !m.conFecha) return;
    const d = diasHasta(m.conFecha);
    if (d < 0 || d > 2) return;
    if (cerrados.includes(p.titulo + "|" + m.conFecha + "|" + hoy)) return;
    salida.push({ p, m, d });
  });
  return salida;
}

function actualizarAvisoFecha() {
  const aviso = $("avisoFecha");
  if (hayFiltros() || pestana !== "catalogo") {
    aviso.style.display = "none";
    return;
  }
  const items = recordatoriosActivos();
  if (!items.length) {
    aviso.style.display = "none";
    return;
  }
  const etiquetas = ["Hoy", "Mañana", "Pasado mañana"];
  const lineas = [0, 1, 2]
    .map(d => ({ d, nombres: items.filter(x => x.d === d).map(x => x.p.titulo + (x.m.conQuien ? " con " + x.m.conQuien : "")) }))
    .filter(g => g.nombres.length)
    .map(g => etiquetas[g.d] + ": " + g.nombres.join(" · "));
  $("avisoFechaTexto").innerHTML = lineas.map(esc).join("<br>");
  aviso.style.display = "block";
}

function cerrarRecordatorio() {
  const hoy = hoyLocalISO();
  const previos = leerJSON("recordatorio_cerrados", []).filter(k => k.endsWith("|" + hoy));
  const nuevos = recordatoriosActivos().map(({ p, m }) => p.titulo + "|" + m.conFecha + "|" + hoy);
  guardarJSON("recordatorio_cerrados", previos.concat(nuevos));
  actualizarAvisoFecha();
}

function diasPendiente(p) {
  const f = (marcas[p.titulo] || {}).pendienteDesde;
  if (!f) return null;
  const ms = Date.now() - new Date(f + "T00:00:00").getTime();
  return Math.max(0, Math.floor(ms / 86400000));
}

function diasConAlguien(p) {
  const f = (marcas[p.titulo] || {}).conAlguienDesde;
  if (!f) return null;
  const ms = Date.now() - new Date(f + "T00:00:00").getTime();
  return Math.max(0, Math.floor(ms / 86400000));
}

function diasDescartada(p) {
  const f = (marcas[p.titulo] || {}).descartadaDesde;
  if (!f) return null;
  const ms = Date.now() - new Date(f + "T00:00:00").getTime();
  return Math.max(0, Math.floor(ms / 86400000));
}

function controlesHtml(p) {
  const s = estadoDe(p);
  const k = esc(p.titulo);
  let estrellas = "";
  for (let n = 1; n <= 5; n++) {
    estrellas += '<button class="estrella' + (n <= s.estrellas ? ' on' : '') + '" data-accion="estrella" data-clave="' + k + '" data-n="' + n + '" aria-label="Calificar con ' + n + (n === 1 ? ' estrella' : ' estrellas') + '">★</button>';
  }
  const dias = s.pendiente ? diasPendiente(p) : null;
  let textoDias = "";
  if (dias !== null) {
    textoDias = '<span class="meta" style="margin:0">' + (dias === 0 ? 'desde hoy' : 'hace ' + dias + (dias === 1 ? ' día' : ' días')) + '</span>';
  } else if (s.pendiente) {
    textoDias = '<span class="meta" style="margin:0">fecha desconocida</span>';
  }
  const descartada = !!(marcas[p.titulo] || {}).descartada;
  const botonRestaurar = descartada
    ? ' <button class="chipc" data-accion="restaurar" data-clave="' + k + '">↩ Restaurar</button>'
    : '';
  const quien = (marcas[p.titulo] || {}).conQuien;
  const etiquetaAlguien = s.conAlguien
    ? '👥 Con alguien' + (quien ? ' · ' + esc(quien) : '')
    : '👥 Con alguien';
  const fechaPlan = (marcas[p.titulo] || {}).conFecha;
  const botonFecha = s.conAlguien
    ? '<button class="chipc' + (fechaPlan ? ' activo' : '') + '" data-accion="conFecha" data-clave="' + k + '">📅 ' + (fechaPlan ? esc(fechaPlan) : 'Fecha') + '</button>'
    : '';
  return '<div class="controles">' +
    '<button class="chipc' + (s.vista ? ' activo' : '') + '" data-accion="vista" data-clave="' + k + '">' + (s.vista ? '✓ Vista' : 'Marcar vista') + '</button>' +
    '<button class="chipc' + (s.pendiente ? ' activo' : '') + '" data-accion="pendiente" data-clave="' + k + '">' + (s.pendiente ? '⏳ En pendientes' : 'Pendiente') + '</button>' +
    '<button class="chipc' + (s.conAlguien ? ' activo' : '') + '" data-accion="conAlguien" data-clave="' + k + '">' + etiquetaAlguien + '</button>' +
    botonFecha +
    textoDias +
    botonRestaurar +
    '<span class="estrellas">' + estrellas + '</span></div>';
}

function contarEstados() {
  let vistas = 0, pendientes = 0;
  peliculas.forEach(p => {
    const s = estadoDe(p);
    if (s.vista) vistas++;
    if (s.pendiente) pendientes++;
  });
  return { vistas, pendientes };
}

/* ---------- Estadísticas ---------- */
const MESES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];

function coloresGrafica() {
  const oscuro = document.body.classList.contains("oscuro");
  return {
    texto: oscuro ? "#f5f5f7" : "#1d1d1f",
    rejilla: oscuro ? "rgba(255,255,255,.12)" : "rgba(0,0,0,.08)",
    paleta: ["#0a84ff", "#30d158", "#ffd60a", "#ff9f0a", "#ff453a", "#bf5af2", "#64d2ff", "#ac8e68", "#ff375f", "#8e8e93"]
  };
}

function vistasPorMes() {
  const anio = new Date().getFullYear();
  const conteo = new Array(12).fill(0);
  Object.entries(marcas).forEach(([titulo, m]) => {
    if (!m || !m.vista || !m.vistaDesde) return;
    const f = new Date(m.vistaDesde + "T00:00:00");
    if (f.getFullYear() === anio) conteo[f.getMonth()]++;
  });
  return conteo;
}

function destruirGraficas() {
  chartsStats.forEach(c => c.destroy());
  chartsStats = [];
}

function renderGraficas() {
  if (typeof Chart === "undefined") {
    $("graficas").innerHTML = '<p class="stats-vacio">No pude cargar las gráficas. Revisa tu conexión.</p>';
    return;
  }
  destruirGraficas();
  const c = coloresGrafica();
  Chart.defaults.color = c.texto;
  Chart.defaults.borderColor = c.rejilla;

  const generos = {};
  peliculas.forEach(p => {
    if (estadoDe(p).vista) generosDe(p).forEach(g => generos[g] = (generos[g] || 0) + 1);
  });
  const topG = Object.entries(generos).sort((a, b) => b[1] - a[1]).slice(0, 8);

  const estrellas = [0, 0, 0, 0, 0];
  peliculas.forEach(p => {
    const n = estadoDe(p).estrellas;
    if (n >= 1 && n <= 5) estrellas[n - 1]++;
  });

  const vMes = vistasPorMes();

  $("graficas").innerHTML =
    '<div class="grafica-caja"><h3>Vistas por mes (año actual)</h3><canvas id="gMes"></canvas></div>' +
    '<div class="graficas-dos">' +
      '<div class="grafica-caja"><h3>Géneros que más has visto</h3>' +
        (topG.length ? '<canvas id="gGen"></canvas>' : '<p class="stats-vacio">Marca películas como vistas para ver tus géneros.</p>') +
      '</div>' +
      '<div class="grafica-caja"><h3>Tus calificaciones</h3>' +
        (estrellas.some(x => x) ? '<canvas id="gEst"></canvas>' : '<p class="stats-vacio">Aún no calificas películas.</p>') +
      '</div>' +
    '</div>';

  chartsStats.push(new Chart($("gMes"), {
    type: "bar",
    data: { labels: MESES, datasets: [{ label: "Vistas", data: vMes, backgroundColor: c.paleta[0], borderRadius: 6 }] },
    options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }
  }));

  if (topG.length) {
    chartsStats.push(new Chart($("gGen"), {
      type: "doughnut",
      data: { labels: topG.map(x => x[0]), datasets: [{ data: topG.map(x => x[1]), backgroundColor: c.paleta }] },
      options: { plugins: { legend: { position: "bottom" } } }
    }));
  }

  if (estrellas.some(x => x)) {
    chartsStats.push(new Chart($("gEst"), {
      type: "bar",
      data: {
        labels: ["1 ★", "2 ★", "3 ★", "4 ★", "5 ★"],
        datasets: [{ label: "Películas", data: estrellas, backgroundColor: "#ffb800", borderRadius: 6 }]
      },
      options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }
    }));
  }
}

function renderEstadisticas() {
  let vistas = 0, pendientes = 0, sinVer = 0, favoritas = 0;
  let minutosVistos = 0, sumaEst = 0, conEst = 0;

  peliculas.forEach(p => {
    const s = estadoDe(p);
    if (s.vista) {
      vistas++;
      minutosVistos += minutos(p);
    } else {
      sinVer++;
    }
    if (s.pendiente) pendientes++;
    if (s.estrellas >= 4) favoritas++;
    if (s.estrellas) {
      sumaEst += s.estrellas;
      conEst++;
    }
  });

  const total = peliculas.length;
  const promedio = conEst ? (sumaEst / conEst).toFixed(1) : "—";
  const horas = Math.floor(minutosVistos / 60);
  const mins = minutosVistos % 60;

  $("statsBody").innerHTML =
    '<div class="stats-resumen">' +
      '<div class="stat"><b>' + total + '</b><span>títulos</span></div>' +
      '<div class="stat"><b>' + vistas + '</b><span>vistas</span></div>' +
      '<div class="stat"><b>' + pendientes + '</b><span>pendientes</span></div>' +
      '<div class="stat"><b>' + sinVer + '</b><span>sin ver</span></div>' +
      '<div class="stat"><b>' + favoritas + '</b><span>favoritas</span></div>' +
      '<div class="stat"><b>' + promedio + '</b><span>promedio ★</span></div>' +
    '</div>' +
    '<p class="meta">Tiempo visto: <b>' + horas + ' h ' + mins + ' min</b> · ' + conEst + ' películas calificadas</p>' +
    '<div id="graficas" class="graficas"></div>';
  renderGraficas();
}

function abrirEstadisticas() {
  renderEstadisticas();
  $("statsModal").classList.add("abierto");
}

function cerrarEstadisticas() {
  $("statsModal").classList.remove("abierto");
  destruirGraficas();
}

/* ---------- Clima solar: tema y protección de la vista ---------- */
const RAD = Math.PI / 180;

function datosSolares(fecha) {
  const diaAnio = Math.floor((fecha - new Date(fecha.getFullYear(), 0, 0)) / 86400000);
  const g = 2 * Math.PI / 365 * (diaAnio - 1);
  const eq = 229.18 * (0.000075 + 0.001868 * Math.cos(g) - 0.032077 * Math.sin(g)
    - 0.014615 * Math.cos(2 * g) - 0.040849 * Math.sin(2 * g));
  const dec = 0.006918 - 0.399912 * Math.cos(g) + 0.070257 * Math.sin(g)
    - 0.006758 * Math.cos(2 * g) + 0.000907 * Math.sin(2 * g)
    - 0.002697 * Math.cos(3 * g) + 0.00148 * Math.sin(3 * g);
  return { eq, dec };
}

function alturaSol(fecha, lat, lon) {
  const { eq, dec } = datosSolares(fecha);
  const minUTC = fecha.getUTCHours() * 60 + fecha.getUTCMinutes() + fecha.getUTCSeconds() / 60;
  const minSolar = minUTC + 4 * lon + eq;
  const H = (minSolar - 720) / 4 * RAD;
  const latR = lat * RAD;
  const seno = Math.sin(latR) * Math.sin(dec) + Math.cos(latR) * Math.cos(dec) * Math.cos(H);
  return Math.asin(Math.max(-1, Math.min(1, seno))) / RAD;
}

function horasSolares(fecha, lat, lon) {
  const { eq, dec } = datosSolares(fecha);
  const latR = lat * RAD;
  const coseno = Math.cos(90.833 * RAD) / (Math.cos(latR) * Math.cos(dec)) - Math.tan(latR) * Math.tan(dec);
  if (coseno < -1 || coseno > 1) return null;
  const mitad = Math.acos(coseno) / RAD;
  const medioDiaUTC = 720 - 4 * lon - eq;
  const base = Date.UTC(fecha.getFullYear(), fecha.getMonth(), fecha.getDate());
  return {
    amanecer: new Date(base + (medioDiaUTC - 4 * mitad) * 60000),
    atardecer: new Date(base + (medioDiaUTC + 4 * mitad) * 60000)
  };
}

function oscuroDelSistema() {
  return !!(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
}

function esOscuroPorSol() {
  const ahora = new Date();
  const h = horasSolares(ahora, ubicacion.lat, ubicacion.lon);
  if (!h) return false;
  return ahora < h.amanecer || ahora >= h.atardecer;
}

function esOscuroPorHora() {
  const h = new Date().getHours();
  return h >= 19 || h < 7;
}

function decidirOscuro(modo) {
  if (modo === "premiere") return true;
  if (modo === "claro") return false;
  if (modo === "oscuro") return true;
  if (modo === "hora") return esOscuroPorHora();
  if (modo === "sol") return esOscuroPorSol();
  return oscuroDelSistema();
}

function actualizarTema() {
  document.body.classList.toggle("oscuro", decidirOscuro($("tema-modo").value));
  document.body.classList.toggle("premiere", $("tema-modo").value === "premiere");
}

function modoGuardado(clave, defecto) {
  try { return localStorage.getItem(clave) || defecto; } catch (e) { return defecto; }
}

function intensidadPorSol() {
  const alt = alturaSol(new Date(), ubicacion.lat, ubicacion.lon);
  const t = (4 - alt) / 10;
  return Math.max(0, Math.min(1, t));
}

const INTENSIDAD_MAXIMA = 0.28;

function actualizarCalido() {
  const modo = $("vista-modo").value;
  let opacidad = 0;
  if (modo === "siempre") opacidad = INTENSIDAD_MAXIMA;
  else if (modo === "auto") opacidad = intensidadPorSol() * INTENSIDAD_MAXIMA;
  $("calido").style.opacity = opacidad.toFixed(3);
}

function actualizarTodo() {
  actualizarTema();
  actualizarCalido();
}

function pedirUbicacion() {
  if (!navigator.geolocation) return;
  navigator.geolocation.getCurrentPosition(
    pos => {
      ubicacion = { lat: pos.coords.latitude, lon: pos.coords.longitude };
      actualizarTodo();
    },
    () => {},
    { timeout: 8000, maximumAge: 86400000 }
  );
}

// Búsqueda: «género: Terror» o «año: 2026» filtran; cualquier otro texto busca como antes
function coincideBusqueda(p, f) {
  const g = norm(f).trim();
  const gen = g.match(/^genero:\s*(.+)$/);
  if (gen) return generosDe(p).some(x => norm(x) === gen[1].trim());
  const anio = g.match(/^ano:\s*(\d{4})$/);
  if (anio) return String(p["año"]) === anio[1];
  const m = marcas[p.titulo] || {};
  // Sin acentos ni mayúsculas, y cada palabra debe aparecer (con tolerancia a una o dos letras mal escritas)
  const texto = norm([p.titulo, p.director, p.reparto, p.genero, m.nota || "", m.conQuien || ""].join(" "));
  const tokens = texto.split(/[^a-z0-9]+/).filter(Boolean);
  const palabras = g.split(/\s+/).filter(Boolean);
  if (!palabras.length) return true;
  return palabras.every(w => {
    if (texto.includes(w)) return true;
    if (w.length < 4) return false;
    const tolerancia = w.length >= 7 ? 2 : 1;
    return tokens.some(t => Math.abs(t.length - w.length) <= tolerancia && distanciaEdicion(w, t) <= tolerancia);
  });
}

// Distancia de Levenshtein: cuántas letras hay que cambiar para pasar de una palabra a otra
// Cuenta también el intercambio de dos letras vecinas como un solo error (amelei -> amelie)
function distanciaEdicion(a, b) {
  const d = [];
  for (let i = 0; i <= a.length; i++) { d[i] = [i]; }
  for (let j = 0; j <= b.length; j++) { d[0][j] = j; }
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const costo = a[i - 1] === b[j - 1] ? 0 : 1;
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + costo);
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
        d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
      }
    }
  }
  return d[a.length][b.length];
}

function llenarSugerencias() {
  const nombres = new Set();
  peliculas.forEach(p => {
    nombres.add(p.titulo);
    personasDe(p).forEach(n => nombres.add(n));
  });
  const dl = $("sugerencias");
  const extras = [];
  [...new Set(peliculas.flatMap(generosDe))].sort((a, b) => a.localeCompare(b, "es"))
    .forEach(g => extras.push("género: " + g));
  [...new Set(peliculas.map(p => String(p["año"] || "")).filter(Boolean))].sort((a, b) => b.localeCompare(a))
    .forEach(a => extras.push("año: " + a));
  dl.innerHTML = extras.map(x => '<option value="' + esc(x) + '"></option>').join("") +
    [...nombres].sort((a, b) => a.localeCompare(b, "es"))
    .map(n => '<option value="' + esc(n) + '"></option>').join("");
}

function llenarFiltros() {
  const llenar = (el, arr) => [...new Set(arr.filter(x => x))].sort().forEach(x => el.add(new Option(x, x)));
  llenar(sel.tipo, peliculas.map(p => p.tipo));
  llenar(sel.genero, peliculas.flatMap(generosDe));
  llenar(sel.anio, peliculas.map(p => String(p["año"] || "")));
  llenar(sel.pais, peliculas.map(p => p.pais));

  const conteo = {};
  peliculas.flatMap(temasDe).forEach(t => conteo[t] = (conteo[t] || 0) + 1);
  Object.keys(conteo).sort().forEach(t => sel.tema.add(new Option(`${t} (${conteo[t]})`, t)));
}

function pastillasHtml(p) {
  return temasDe(p).map(t => '<span class="pastilla tema">' + esc(t) + '</span>').join("");
}

function retraso(i) { return "--retraso:" + Math.min(i * 40, 400) + "ms"; }

// Tarjeta compacta: portada pequeña, título, año/duración e insignias. Al tocarla se abre la ficha.
// Vista amplia (por defecto): portada grande, sinopsis y acciones al pasar el cursor
function tarjetaAmplia(p, i, extra) {
  const s = estadoDe(p);
  const k = esc(p.titulo);
  const insignias = [];
  if (s.vista) insignias.push("✓ Vista");
  else if (s.pendiente) insignias.push("⏳ Pendiente");
  if (s.estrellas) insignias.push("★ " + s.estrellas);
  if (s.conAlguien) insignias.push("👥");
  const portada = (p.portada && !datosLimitados())
    ? '<img class="portada" loading="lazy" decoding="async" src="' + esc(p.portada) + '" alt="">'
    : '<div class="sinportada">🎬</div>';
  return '<article class="tarjeta amplia animar" style="' + retraso(i) + '" data-i="' + i + '">' + portada +
    '<h2>' + esc(p.titulo) + '</h2>' +
    '<div class="meta">' + esc(p["año"]) + ' · ' + esc(p.duracion) + (p.pais ? ' · ' + esc(p.pais) : '') + '</div>' +
    (insignias.length ? '<div class="mini-insignias">' + insignias.map(t => '<span class="badge">' + esc(t) + '</span>').join("") + '</div>' : '') +
    '<p class="sinopsis clamp-2">' + esc(p.sinopsis) + '</p>' +
    '<div class="acciones-rapidas">' +
      '<button class="chipc' + (s.vista ? ' activo' : '') + '" data-accion="vista" data-clave="' + k + '">' + (s.vista ? '✓ Vista' : 'Vista') + '</button>' +
      '<button class="chipc' + (s.pendiente ? ' activo' : '') + '" data-accion="pendiente" data-clave="' + k + '">' + (s.pendiente ? '⏳' : 'Pendiente') + '</button>' +
      [1, 2, 3, 4, 5].map(n => '<button class="estrella' + (n <= s.estrellas ? ' on' : '') + '" data-accion="estrella" data-clave="' + k + '" data-n="' + n + '" aria-label="Calificar con ' + n + (n === 1 ? ' estrella' : ' estrellas') + '">★</button>').join("") +
    '</div>' +
    (extra || '') +
    '</article>';
}

// Elige la vista: amplia (por defecto) o compacta
function tarjeta(p, i) {
  return vistaLista ? tarjetaCompacta(p, i) : tarjetaAmplia(p, i);
}

// Vista compacta: fila con portada pequeña
function tarjetaCompacta(p, i) {
  const s = estadoDe(p);
  const insignias = [];
  if (s.vista) insignias.push("✓ Vista");
  else if (s.pendiente) insignias.push("⏳ Pendiente");
  if (s.estrellas) insignias.push("★ " + s.estrellas);
  if (s.conAlguien) insignias.push("👥");
  const portada = (p.portada && !datosLimitados())
    ? '<img class="mini-portada" src="' + esc(p.portada) + '" alt="">'
    : '<div class="mini-portada mini-sinportada">🎬</div>';
  return '<article class="tarjeta compacta animar" style="' + retraso(i) + '" data-i="' + i + '">' + portada +
    '<div class="mini-info"><h2>' + esc(p.titulo) + '</h2>' +
    '<div class="meta">' + esc(p["año"]) + ' · ' + esc(p.duracion) + '</div>' +
    (insignias.length ? '<div class="mini-insignias">' + insignias.map(t => '<span class="badge">' + esc(t) + '</span>').join("") + '</div>' : '') +
    '<div class="acciones-rapidas">' +
      '<button class="chipc' + (s.vista ? ' activo' : '') + '" data-accion="vista" data-clave="' + esc(p.titulo) + '">' + (s.vista ? '✓ Vista' : 'Vista') + '</button>' +
      '<button class="chipc' + (s.pendiente ? ' activo' : '') + '" data-accion="pendiente" data-clave="' + esc(p.titulo) + '">' + (s.pendiente ? '⏳' : 'Pendiente') + '</button>' +
      [1, 2, 3, 4, 5].map(n => '<button class="estrella' + (n <= s.estrellas ? ' on' : '') + '" data-accion="estrella" data-clave="' + esc(p.titulo) + '" data-n="' + n + '" aria-label="Calificar con ' + n + (n === 1 ? ' estrella' : ' estrellas') + '">★</button>').join("") +
    '</div>' +
    '</div></article>';
}

function filaHtml(p, i) {
  return tarjetaCompacta(p, i);
}

// Misma tarjeta compacta que Catálogo; "extra" agrega lo propio de cada pestaña (nota, fechas, etc.)
function heroPestana(tipo, items, extras) {
  const tile = (n, t, acento) => '<div class="pest-stat' + (acento ? ' acento' : '') + '"><b>' + n + '</b><span>' + t + '</span></div>';
  if (tipo === "vistas") {
    const mes = hoyLocalISO().slice(0, 7);
    const delMes = items.filter(p => String((marcas[p.titulo] || {}).vistaDesde || "").slice(0, 7) === mes).length;
    const conNota = items.filter(p => (marcas[p.titulo] || {}).estrellas || estadoDe(p).estrellas);
    const prom = conNota.length ? (conNota.reduce((a, p) => a + Number(estadoDe(p).estrellas || 0), 0) / conNota.length).toFixed(1) : "–";
    return '<div class="pest-hero">' + tile(items.length, "vistas", false) + tile(delMes, "este mes", true) + tile("★ " + prom, "promedio", false) + '</div>';
  }
  const planeadas = extras.planeadas || 0;
  const antigua = extras.antigua;
  return '<div class="pest-hero">' + tile(items.length, "pendientes", true) + tile(planeadas, "para ver con alguien", false) +
    tile(antigua === null ? "–" : antigua + "d", "la más antigua", false) + '</div>';
}

function filaPestana(p, i, extra) {
  if (!vistaLista) return tarjetaAmplia(p, i, extra);
  const s = estadoDe(p);
  const insignias = [];
  if (s.vista) insignias.push("✓ Vista");
  else if (s.pendiente) insignias.push("⏳ Pendiente");
  if (s.estrellas) insignias.push("★ " + s.estrellas);
  if (s.conAlguien) insignias.push("👥");
  const portada = (p.portada && !datosLimitados())
    ? '<img class="mini-portada" src="' + esc(p.portada) + '" alt="">'
    : '<div class="mini-portada mini-sinportada">🎬</div>';
  return '<article class="tarjeta compacta animar" style="' + retraso(i) + '" data-i="' + i + '">' + portada +
    '<div class="mini-info"><h2>' + esc(p.titulo) + '</h2>' +
    '<div class="meta">' + esc(p["año"]) + ' · ' + esc(p.duracion) + '</div>' +
    (insignias.length ? '<div class="mini-insignias">' + insignias.map(t => '<span class="badge">' + esc(t) + '</span>').join("") + '</div>' : '') +
    (extra || '') +
    '</div></article>';
}

function renderDestacados() {
  const fechaValida = f => /^\d{4}-\d{2}-\d{2}$/.test(String(f || ""));
  const hoy = hoyLocalISO();
  const dias = f => Math.round((new Date(f + "T00:00") - new Date(hoy + "T00:00")) / 86400000);
  const MESES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
  const DIAS = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"];
  const etiquetaFecha = f => { const [a, m, d] = f.split("-"); return Number(d) + " " + MESES[Number(m) - 1] + " " + a; };
  const etiquetaDia = f => DIAS[new Date(f + "T00:00").getDay()] + " " + etiquetaFecha(f);
  const conFecha = peliculas.filter(p => fechaValida(p.estreno));
  let lista, sub;
  if (conFecha.length) {
    const ya = conFecha.filter(p => p.estreno <= hoy && dias(p.estreno) >= -120).sort((a, b) => b.estreno.localeCompare(a.estreno)).slice(0, 8);
    const pronto = conFecha.filter(p => p.estreno > hoy).sort((a, b) => a.estreno.localeCompare(b.estreno)).slice(0, 4);
    lista = ya.map(p => ({ p, tipo: "ya" })).concat(pronto.map(p => ({ p, tipo: "pronto" })));
    sub = "Según su fecha de estreno real";
  } else {
    lista = [...peliculas].filter(p => Number(p["año"]))
      .sort((a, b) => Number(b["año"]) - Number(a["año"])).slice(0, 8).map(p => ({ p, tipo: "" }));
    sub = "";
  }
  $("destSub").textContent = sub;
  renderProximosCines();
  $("carrusel").innerHTML = lista.map(({ p, tipo }) => {
    const idx = peliculas.indexOf(p);
    const s = estadoDe(p);
    const img = (p.portada && !datosLimitados())
      ? '<img src="' + esc(p.portada) + '" alt="" loading="lazy">'
      : '<div class="dest2-sinportada">🎬</div>';
    let etiqueta = "";
    let fecha = p["año"] ? String(p["año"]) : "";
    if (tipo === "ya") {
      const d = dias(p.estreno);
      if (d >= -30) etiqueta = '<span class="dest2-tag nuevo">Nuevo</span>';
      fecha = "Estrenó el " + etiquetaDia(p.estreno);
    } else if (tipo === "pronto") {
      const d = dias(p.estreno);
      etiqueta = '<span class="dest2-tag prox">' + (d === 1 ? "Mañana" : "En " + d + " días") + '</span>';
      fecha = "Se estrena el " + etiquetaDia(p.estreno);
    }
    const estado = s.vista ? '<span class="dest2-estado">✓</span>' : (s.pendiente ? '<span class="dest2-estado">⏳</span>' : "");
    return '<div class="dest2" data-idx="' + idx + '">' +
      '<div class="dest2-poster">' + img + etiqueta + estado + '</div>' +
      '<div class="dest2-info"><div class="dest2-titulo">' + esc(p.titulo) + '</div>' +
      '<div class="dest2-fecha">' + esc(fecha) + '</div></div></div>';
  }).join("");
}

let proximosCines = [];
const normTxt = t => String(t || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();

async function cargarProximosCines() {
  if (!accessToken || !HOJA_ID) return;
  try {
    const r = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${HOJA_ID}/values/proximos!A:E`, {
      headers: { Authorization: "Bearer " + accessToken }
    });
    if (!r.ok) return;
    const j = await r.json();
    proximosCines = (j.values || []).slice(1)
      .filter(f => f[0] && /^\d{4}-\d{2}-\d{2}$/.test(f[1] || ""))
      .map(f => ({ titulo: f[0], fecha: f[1], portada: f[2] || "", tmdb: f[3] || "", sinopsis: f[4] || "" }))
      .sort((a, b) => a.fecha.localeCompare(b.fecha));
    renderProximosCines();
  } catch (e) {}
}

function renderProximosCines() {
  const cont = document.getElementById("proximosCines");
  if (!cont) return;
  const DIAS_C = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"];
  const MESES_C = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
  const hoy = hoyLocalISO();
  const lista = proximosCines.filter(x => x.fecha >= hoy).slice(0, 12);
  document.getElementById("proxSub").textContent = lista.length ? "Cartelera de cines en México. Toca una para ver de qué trata." : "";
  cont.innerHTML = lista.map((x, i) => {
    const idx = peliculas.findIndex(p => normTxt(p.titulo) === normTxt(x.titulo));
    const [a, m, d] = x.fecha.split("-");
    const dif = Math.round((new Date(x.fecha + "T00:00") - new Date(hoy + "T00:00")) / 86400000);
    const etiqueta = dif === 0 ? "Hoy" : (dif === 1 ? "Mañana" : "En " + dif + " días");
    const img = (x.portada && !datosLimitados())
      ? '<img src="' + esc(x.portada) + '" alt="" loading="lazy">'
      : '<div class="dest2-sinportada">🎬</div>';
    return '<div class="dest2" data-prox="' + i + '"' + (idx !== -1 ? ' data-idx="' + idx + '"' : '') + '>' +
      '<div class="dest2-poster">' + img +
      '<span class="dest2-tag prox">' + etiqueta + '</span>' +
      (idx !== -1 ? '<span class="dest2-estado" title="Ya está en tu catálogo">★</span>' : '') + '</div>' +
      '<div class="dest2-info"><div class="dest2-titulo">' + esc(x.titulo) + '</div>' +
      '<div class="dest2-fecha">' + esc(DIAS_C[new Date(x.fecha + "T00:00").getDay()] + " " + Number(d) + " " + MESES_C[Number(m) - 1]) + '</div></div></div>';
  }).join("") || '';
  if (!cont.dataset.listo) {
    cont.dataset.listo = "1";
    cont.addEventListener("click", e => {
      const t = e.target.closest("[data-prox]");
      if (!t) return;
      if (t.dataset.idx !== undefined) { desdeAleatorio = false; abrirDetalle(peliculas[Number(t.dataset.idx)]); return; }
      const x = proximosCines[Number(t.dataset.prox)];
      const hoyTxt = hoyLocalISO();
      if (x) abrirVentanaSimple("ventanaProximo", x.titulo,
        '<p class="meta">Se estrena el ' + esc(x.fecha) + '</p>' +
        '<p>' + esc(x.sinopsis || "Sin sinopsis por ahora.") + '</p>' +
        '<p class="meta">No está en tu catálogo todavía.</p>');
    });
  }
}

// Estrenos se reacomoda solo: se vuelve a pintar cada hora (cambia de «próximo» a «estrenó» al pasar la fecha)
setInterval(() => { if (peliculas.length) renderDestacados(); }, 60 * 60 * 1000);

function hayFiltros() {
  return buscar.value.trim() !== "" || Object.values(sel).some(s => s.value !== "");
}

function actualizarBotonAvanzados() {
  const n = AVANZADOS.filter(k => sel[k].value).length;
  const boton = $("toggleAvanzados");
  boton.textContent = "⚙" + (n ? " " + n : "");
  boton.setAttribute("aria-label", "Filtros avanzados" + (n ? ", " + n + " activos" : ""));
  boton.classList.toggle("destacado", n > 0);
}

function textoOpcion(select) {
  const opt = select.options[select.selectedIndex];
  return opt ? opt.text.replace(/\s*\(\d+\)$/, "") : select.value;
}

function renderChips() {
  const activos = [];
  if (buscar.value.trim()) activos.push({ clave:"buscar", texto:'Búsqueda: "' + buscar.value.trim() + '"' });
  Object.keys(sel).forEach(k => {
    if (sel[k].value) activos.push({ clave:k, texto:etiquetas[k] + ": " + textoOpcion(sel[k]) });
  });
  chips.innerHTML = activos.map(a =>
    '<span class="chip" data-clave="' + a.clave + '">' + esc(a.texto) + '<span>×</span></span>'
  ).join("");
}

function coincideEstado(p, valor) {
  if (marcas[p.titulo] && marcas[p.titulo].descartada) return false;
  if (!valor) return true;
  const s = estadoDe(p);
  if (valor === "vista") return s.vista;
  if (valor === "sin_ver") return !s.vista;
  if (valor === "pendiente") return s.pendiente;
  if (valor === "conAlguien") return s.conAlguien;
  if (valor === "estancados") {
    const d = diasPendiente(p);
    return s.pendiente && d !== null && d > 30;
  }
  if (valor === "favoritas") return s.estrellas >= 4;
  return true;
}

function renderAgrupado() {
  const temas = [...new Set(visibles.flatMap(temasDe))].sort((a, b) => a.localeCompare(b, "es"));
  const bloques = temas.map(t => {
    const grupo = visibles.filter(p => temasDe(p).includes(t));
    return { nombre: t, items: grupo };
  });
  const sinTema = visibles.filter(p => temasDe(p).length === 0);
  if (sinTema.length) bloques.push({ nombre: "Sin tema", items: sinTema });

  return bloques.map(b => {
    const cuerpo = b.items.map(p => {
      const i = visibles.indexOf(p);
      return vistaLista ? filaHtml(p, i) : tarjeta(p, i);
    }).join("");
    return '<section class="grupo"><h3>' + esc(b.nombre) + ' (' + b.items.length + ')</h3>' +
      '<div class="grupo-items">' + cuerpo + '</div></section>';
  }).join("");
}

function actualizarBotonSalud() {
  const oculto = modoGuardado("salud_oculta", "1") === "1";
  $("salud").classList.toggle("oculto", oculto);
  $("toggleSalud").textContent = oculto ? "🩺 Mostrar salud de la hoja" : "🩺 Ocultar salud de la hoja";
}

function revisarSalud() {
  const sec = $("salud");
  if (!peliculas.length) return;

  const sinEs = [], sinPortada = [], sinPaleta = [], sinTrailer = [], linkRevisar = [];
  const titulosVistos = new Map();
  const duplicados = [];

  peliculas.forEach(p => {
    const t = String(p.titulo || "").trim();
    const clave = slugDe(p);
    if (titulosVistos.has(clave)) duplicados.push(t);
    else titulosVistos.set(clave, t);

    const es = String(p.trailer_es || "").trim();
    const en = String(p.trailer_en || "").trim();
    if (!es || es === "sin tráiler") sinEs.push(t);
    if ((!es && !en) || (es === "sin tráiler" && en === "sin tráiler")) sinTrailer.push(t);
    if (!String(p.portada || "").trim()) sinPortada.push(t);
    if (!paletaDeTexto(p[NOMBRE_PALETA]).length) sinPaleta.push(t);
    const estadoLink = String(p.estado_link || "").trim();
    if (estadoLink && estadoLink.indexOf("activo") === -1) linkRevisar.push(t);
  });

  const bloque = (titulo, lista, mensajeOk) => {
    if (!lista.length) return '<li class="ok">✓ ' + mensajeOk + '</li>';
    return '<li class="alerta">' + titulo + ': ' + lista.length +
      (lista.length <= 8 ? ' (' + lista.map(esc).join(', ') + ')' : '') + '</li>';
  };

  sec.innerHTML =
    '<details open><summary><b>Salud de la hoja</b> · ' + peliculas.length + ' títulos</summary>' +
    '<ul>' +
      bloque("Sin tráiler en español", sinEs, "Todas tienen tráiler en español") +
      bloque("Sin ningún tráiler", sinTrailer, "Todas tienen algún tráiler") +
      bloque("Sin portada", sinPortada, "Todas tienen portada") +
      bloque("Sin paleta de color", sinPaleta, "Todas tienen paleta guardada") +
      bloque("Link que no responde", linkRevisar, "Todos los links responden") +
      (duplicados.length
        ? '<li class="alerta">Posibles duplicados: ' + duplicados.map(esc).join(', ') + '</li>'
        : '<li class="ok">✓ No hay títulos duplicados</li>') +
    '</ul></details>';
}

/* ---------- Aviso de estancadas con botón Decidir ---------- */
function listaEstancadas() {
  const pend = peliculas
    .filter(p => {
      const m = marcas[p.titulo] || {};
      if (m.descartada) return false;
      const d = diasPendiente(p);
      return estadoDe(p).pendiente && d !== null && d > 30;
    })
    .map(p => ({ p, tipo: "pendiente", dias: diasPendiente(p) }));
  const planeadas = peliculas
    .filter(p => {
      const d = diasConAlguien(p);
      return estadoDe(p).conAlguien && d !== null && d > 30;
    })
    .map(p => ({ p, tipo: "planeada", dias: diasConAlguien(p) }));
  return [...pend, ...planeadas];
}

function renderAvisoEstancados() {
  const aviso = $("avisoEstancados");
  const items = listaEstancadas();

  const firmaActual = items.map(x => x.p.titulo + x.tipo).join("|");
  if (firmaActual !== firmaAvisoCerrado) avisoCerrado = false;

  if (hayFiltros() || pestana !== "catalogo" || !items.length || avisoCerrado) {
    aviso.style.display = "none";
    return;
  }

  const n = items.filter(x => x.tipo === "pendiente").length;
  const planeadas = items.length - n;
  const partes = [];
  if (n) partes.push(n + (n === 1 ? " pendiente lleva" : " pendientes llevan") + " más de 30 días sin ver");
  if (planeadas) partes.push(planeadas + (planeadas === 1 ? " planeada con alguien lleva" : " planeadas con alguien llevan") + " más de 30 días");
  $("avisoEstancadosTexto").textContent = partes.join(" · ") + ".";

  $("avisoLista").innerHTML = items.map(x => {
    const k = esc(x.p.titulo);
    const detalle = x.tipo === "pendiente"
      ? "Pendiente hace " + x.dias + " días"
      : "Planeada con alguien hace " + x.dias + " días" + ((marcas[x.p.titulo] || {}).conFecha ? " · " + esc(marcas[x.p.titulo].conFecha) : "");
    const abierta = decidiendo === x.p.titulo;
    const opciones = x.tipo === "pendiente"
      ? '<button class="pildora destacado" data-decidir="ver" data-clave="' + k + '">Ver ahora</button>' +
        '<button class="pildora" data-decidir="planear" data-clave="' + k + '">Planear fecha</button>' +
        '<button class="pildora" data-decidir="descartar" data-clave="' + k + '">Descartar</button>'
      : '<button class="pildora destacado" data-decidir="ver" data-clave="' + k + '">Ver ahora</button>' +
        '<button class="pildora" data-decidir="cambiarFecha" data-clave="' + k + '">Cambiar fecha</button>' +
        '<button class="pildora" data-decidir="quitarPlan" data-clave="' + k + '">Quitar de planeadas</button>';
    return '<div class="aviso-item"><div class="info-aviso">' + esc(x.p.titulo) +
      '<small>' + detalle + '</small></div>' +
      (abierta
        ? '<div class="aviso-opciones">' + opciones + '</div>'
        : '<div class="aviso-opciones"><button class="pildora" data-decidir-abrir="' + k + '">Decidir</button></div>') +
      '</div>';
  }).join("");

  aviso.style.display = "block";
}

// Muestra el aviso con Deshacer. items: [{ titulo, previo }], donde previo es el estado anterior (o null)
function mostrarDeshacer(texto, items) {
  if (deshacerDescarte && deshacerDescarte.timer) clearTimeout(deshacerDescarte.timer);
  deshacerDescarte = { items };
  $("avisoDeshacerTexto").textContent = texto;
  $("avisoDeshacer").hidden = false;
  deshacerDescarte.timer = setTimeout(() => {
    $("avisoDeshacer").hidden = true;
    deshacerDescarte = null;
  }, 6000);
}

function deshacerUltimoDescarte() {
  if (!deshacerDescarte) return;
  deshacerDescarte.items.forEach(({ titulo, previo }) => {
    if (previo) marcas[titulo] = previo; else delete marcas[titulo];
  });
  clearTimeout(deshacerDescarte.timer);
  deshacerDescarte = null;
  $("avisoDeshacer").hidden = true;
  programarGuardado();
  refrescarTodo();
  setEstado("Cambio deshecho.");
}

function accionDecidir(accion, titulo) {
  const p = peliculas.find(x => x.titulo === titulo);
  if (!p) return;
  decidiendo = null;

  if (accion === "ver") {
    desdeAleatorio = false;
    abrirDetalle(p);
    return;
  }
  if (accion === "planear") {
    alternarConAlguien(titulo);
    if (!(marcas[titulo] || {}).conAlguien) { decidiendo = titulo; renderAvisoEstancados(); }
    refrescarTodo();
    return;
  }
  if (accion === "cambiarFecha") {
    cambiarFechaConAlguien(titulo);
    refrescarTodo();
    return;
  }
  if (accion === "quitarPlan") {
    alternarConAlguien(titulo);
    refrescarTodo();
    return;
  }
  if (accion === "descartar") {
    const previo = marcas[titulo] ? Object.assign({}, marcas[titulo]) : null;
    cambiarEstado(titulo, { descartada: true, pendiente: false, vista: false });
    mostrarDeshacer("«" + titulo + "» descartada.", [{ titulo, previo }]);
    refrescarTodo();
  }
}

/* ---------- Pestaña Descartadas ---------- */
function listaDescartadas() {
  return peliculas.filter(p => (marcas[p.titulo] || {}).descartada);
}

function revisionesPendientes() {
  return listaDescartadas().filter(p => {
    const m = marcas[p.titulo] || {};
    if (m.revisionHecha) return false;
    const d = diasDescartada(p);
    return d !== null && d >= 90;
  });
}

// Filtra solo las filas (sin repintar la barra) para no perder el foco del buscador
function filtrarFilasDescartadas() {
  const texto = ($("buscarDesc") ? $("buscarDesc").value : "").trim().toLowerCase();
  document.querySelectorAll("[data-fila-desc]").forEach(fila => {
    const titulo = fila.dataset.filaDesc.toLowerCase();
    const nota = (marcas[fila.dataset.filaDesc] || {}).nota || "";
    fila.style.display = (titulo + " " + nota.toLowerCase()).includes(texto) ? "" : "none";
  });
}

function renderPestanaDescartadas() {
  const todas = listaDescartadas();
  const texto = ($("buscarDesc") ? $("buscarDesc").value : buscar.value).trim().toLowerCase();
  const revisiones = revisionesPendientes();

  seleccionDesc = new Set([...seleccionDesc].filter(t => todas.some(p => p.titulo === t)));

  const visiblesDesc = todas
    .filter(p => {
      const m = marcas[p.titulo] || {};
      return [p.titulo, m.nota || ""].join(" ").toLowerCase().includes(texto);
    })
    .sort((a, b) => String(a.titulo).localeCompare(String(b.titulo), "es"));

  visibles = visiblesDesc;
  contador.textContent = "Descartadas: " + todas.length + " · mostrando " + visiblesDesc.length;
  chips.innerHTML = "";

  let html = "";

  if (revisiones.length) {
    html += '<div class="desc-bloque"><h3>Lleva más de 90 días descartada: ¿la reconsideras?</h3>' +
      '<p class="meta">Tú decides. Nada cambia hasta que pulses un botón.</p>' +
      revisiones.map(p => {
        const k = esc(p.titulo);
        return '<div class="desc-item"><div class="info-desc">' + esc(p.titulo) +
          '<small>Descartada hace ' + diasDescartada(p) + ' días</small></div>' +
          '<div class="desc-acciones">' +
          '<button class="pildora destacado" data-revision="restaurar" data-clave="' + k + '">Restaurar</button>' +
          '<button class="pildora" data-revision="dejar" data-clave="' + k + '">Dejar así</button>' +
          '</div></div>';
      }).join("") +
      '</div>';
  }

  html += '<div class="desc-barra">' +
    '<input type="search" id="buscarDesc" placeholder="Buscar en descartadas" value="' + esc(buscar.value) + '">' +
    '<button class="pildora" id="selTodasDesc">Seleccionar todas las visibles</button>' +
    '<button class="pildora destacado" id="restaurarSelDesc"' + (seleccionDesc.size ? '' : ' disabled') + '>Restaurar seleccionadas (' + seleccionDesc.size + ')</button>' +
    '<button class="pildora" id="descartarBtnDesc">🗑 Descartar…</button>' +
    '</div>';

  if (!todas.length) {
    html += '<p class="vacio">Aún no descartas películas. Si una no te interesa, ábrela y usa «Descartar»; así no te la vuelvo a sugerir.</p>';
  } else {
    html += todas.map(p => {
      const k = esc(p.titulo);
      const d = diasDescartada(p);
      const cuando = d === null ? "fecha desconocida" : "descartada hace " + d + (d === 1 ? " día" : " días");
      return '<div class="desc-fila" data-fila-desc="' + k + '"' +
        (visiblesDesc.includes(p) ? '' : ' style="display:none"') + '>' +
        '<input type="checkbox" data-sel="' + k + '"' + (seleccionDesc.has(p.titulo) ? ' checked' : '') + '>' +
        ((p.portada && !datosLimitados()) ? '<img class="mini-portada" src="' + esc(p.portada) + '" alt="">' : '<div class="mini-portada mini-sinportada">🎬</div>') +
        '<div class="info-fila"><h2>' + esc(p.titulo) + '</h2>' +
        '<div class="meta">' + esc(p["año"]) + ' · ' + cuando + '</div></div>' +
        '<button class="chipc" data-restaurar-una="' + k + '">↩ Restaurar</button>' +
        '</div>';
    }).join("");
  }

  lista.innerHTML = html;
}

function accionRevision(accion, titulo) {
  if (accion === "restaurar") {
    cambiarEstado(titulo, { descartada: false });
  } else {
    marcas[titulo] = Object.assign({}, marcas[titulo] || {}, { revisionHecha: true });
    programarGuardado();
  }
  refrescarTodo();
}

function restaurarTitulos(titulos) {
  if (!titulos.length) return;
  titulos.forEach(t => cambiarEstado(t, { descartada: false }));
  seleccionDesc.clear();
  setEstado(titulos.length + (titulos.length === 1 ? " película restaurada." : " películas restauradas."));
  refrescarTodo();
}

// Descarta las seleccionadas desde la propia pestaña, con aviso de Deshacer
function descartarSeleccionadas() {
  const titulos = [...seleccionDesc];
  if (!titulos.length) { setEstado("Marca al menos una película para descartarla."); return; }
  const items = titulos.map(t => ({ titulo: t, previo: marcas[t] ? Object.assign({}, marcas[t]) : null }));
  titulos.forEach(t => cambiarEstado(t, { descartada: true, pendiente: false, vista: false }));
  seleccionDesc.clear();
  const texto = titulos.length + (titulos.length === 1 ? " película descartada." : " películas descartadas.");
  mostrarDeshacer(texto, items);
  setEstado(texto);
  refrescarTodo();
}

/* ---------- Pintado principal ---------- */
function pintar() {
  document.body.dataset.pestana = pestana;
  if (pestana !== "catalogo") { pintarPestana(); return; }
  $("tagsNotas").style.display = "none";

  const f = buscar.value.trim().toLowerCase();
  visibles = peliculas.filter(p => {
    const m = marcas[p.titulo] || {};
    const texto = [p.titulo, p.director, p.reparto, m.nota || "", m.conQuien || ""].join(" ").toLowerCase();
    return coincideBusqueda(p, f) &&
      (!sel.tipo.value || p.tipo === sel.tipo.value) &&
      (!sel.genero.value || generosDe(p).includes(sel.genero.value)) &&
      (!sel.tema.value || temasDe(p).includes(sel.tema.value)) &&
      (!sel.anio.value || String(p["año"]) === sel.anio.value) &&
      (!sel.pais.value || p.pais === sel.pais.value) &&
      enRangoDuracion(p, sel.duracion.value) &&
      coincideEstado(p, sel.estado.value);
  });
  visibles.sort(ordenes[$("orden").value]);
  visibles = ordenarPorAnimo(visibles);

  const { vistas, pendientes } = contarEstados();
  $("destacados").style.display = hayFiltros() ? "none" : "block";
  renderRecomendaciones();
  if (typeof renderSaludoPersonal === "function") renderSaludoPersonal();
  if (typeof renderTarjetaAuto === "function") renderTarjetaAuto();
  renderHoy();
  actualizarAhora();
  renderAvisoEstancados();
  actualizarAvisoFecha();
  renderCena();
  renderEstaSemana();
  renderPregunta();
  renderBienvenida();
  renderDuelo();
  renderSagas();
  renderActores();
  revisarSalud();
  actualizarBotonSalud();
  actualizarBotonAvanzados();
  renderChips();
  contador.textContent = visibles.length + " de " + peliculas.length + " títulos · " +
    vistas + " vistas · " + pendientes + " pendientes" + (datosLimitados() ? " · modo ahorro" : "");

  ajustarQueVer();
  if (!visibles.length) {
    lista.innerHTML = '<p class="vacio">No encontré películas con esos criterios. Prueba quitando algún filtro o cambiando la búsqueda.</p>';
    return;
  }
  if (agrupado) {
    lista.innerHTML = renderAgrupado();
    return;
  }
  lista.innerHTML = visibles.map((p, i) => vistaLista ? filaHtml(p, i) : tarjeta(p, i)).join("");
  marcarAnimo();
}

function pintarPestana() {
  $("resumenSemana").style.display = "none";
  $("avisoFecha").style.display = "none";
  $("avisoEstancados").style.display = "none";
  $("tagsNotas").style.display = "none";
  $("toolbarNotas").style.display = "none";
  $("toolbarVistas").style.display = "none";
  $("destacados").style.display = "none";
  $("salud").classList.add("oculto");
  $("ahora").style.display = "none";
  $("queVer").style.display = "none";
  $("estaSemana").style.display = "none";
  $("duelo").style.display = "none";
  $("pregunta").style.display = "none";
  $("bienvenida").style.display = "none";
  $("mapaGustos").style.display = "none";
  destruirMapa();
  $("recomendaciones").style.display = "none";
  chips.innerHTML = "";

  if (pestana === "vistas") {
    actualizarResumenSemana();
    renderActividad();
  renderRetoMes();
  renderExtrasActividad();
    renderMapaGustos();
  }

  if (pestana === "descartadas") {
    renderPestanaDescartadas();
    return;
  }

  let items = [], extra = null, titulo = "";

  if (pestana === "notas") {
    const f = buscar.value.trim().toLowerCase();
    const etiquetaBuscada = f.startsWith("#") ? f.slice(1) : "";
    titulo = "Mis notas";
    items = peliculas.filter(p => (marcas[p.titulo] || {}).nota)
      .filter(p => etiquetaBuscada
        ? coincideEtiqueta(p, etiquetaBuscada)
        : [p.titulo, (marcas[p.titulo] || {}).nota].join(" ").toLowerCase().includes(f))
      .sort(ordenNotasFn());
    extra = p => {
      const m = marcas[p.titulo] || {};
      const txt = String(m.nota || "").slice(0, 160) + (String(m.nota || "").length > 160 ? "…" : "");
      const tags = etiquetasDeNota(m.nota).map(t => '<button class="etiqueta" data-tag="' + esc(t) + '">#' + esc(t) + '</button>').join("");
      return '<p class="nota-corta">' + esc(txt) + '</p>' +
        (tags ? '<div class="etiquetas-fila">' + tags + '</div>' : '') +
        '<div class="meta" style="margin-top:6px">Editada: ' + esc(m.notaFecha || "") + '</div>';
    };
    $("toolbarNotas").style.display = "flex";
    renderBarraEtiquetas();
  } else if (pestana === "pendientes") {
    titulo = "Pendientes";
    const todas = peliculas.filter(p => estadoDe(p).pendiente);
    const planeadas = todas.filter(p => estadoDe(p).conAlguien)
      .sort((a, b) => {
        const fa = (marcas[a.titulo] || {}).conFecha || "9999-12-31";
        const fb = (marcas[b.titulo] || {}).conFecha || "9999-12-31";
        return fa.localeCompare(fb) || String((marcas[a.titulo] || {}).conAlguienDesde || "").localeCompare(String((marcas[b.titulo] || {}).conAlguienDesde || ""));
      });
    const resto = todas.filter(p => !estadoDe(p).conAlguien)
      .sort((a, b) => String((marcas[a.titulo] || {}).pendienteDesde || "9999").localeCompare(String((marcas[b.titulo] || {}).pendienteDesde || "9999")));
    items = [...planeadas, ...resto];
    extra = p => '<div class="meta" style="margin-top:6px">' + esc(diasPendiente(p) === null ? "fecha desconocida" : "hace " + diasPendiente(p) + " días") + '</div>';

    visibles = items;
    contador.textContent = "Pendientes: " + items.length + " · con alguien: " + planeadas.length;

    if (!items.length) {
      lista.innerHTML = '<p class="vacio">Aún no tienes pendientes. Marca una película con «Pendiente» para verla después.</p>';
      return;
    }
    let html = "";
    if (planeadas.length) {
      html += '<div class="bloque-pend"><h3>Para ver con alguien (' + planeadas.length + ')</h3>' +
        '<div class="grupo-items">' +
        planeadas.map((p, i) => filaPestana(p, i,
          extra(p) +
          (marcas[p.titulo] && marcas[p.titulo].conQuien ? '<div class="meta">con ' + esc(marcas[p.titulo].conQuien) + '</div>' : '') +
          lineaFechaConAlguien(p)
        )).join("") +
        '</div></div>';
    }
    if (resto.length) {
      html += '<div class="bloque-pend"><h3>Otras pendientes (' + resto.length + ')</h3>' +
        '<div class="grupo-items">' +
        resto.map((p, i) => filaPestana(p, i, extra(p))).join("") +
        '</div></div>';
    }
    const diasResto = resto.map(p => diasPendiente(p)).filter(d => d !== null);
    const antigua = diasResto.length ? Math.max(...diasResto) : null;
    lista.innerHTML = heroPestana("pendientes", todas, { planeadas: planeadas.length, antigua: antigua }) + htmlCalendario() + html;
    return;
  } else if (pestana === "vistas") {
    titulo = "Vistas";
    items = peliculas.filter(p => estadoDe(p).vista)
      .sort((a, b) => String((marcas[b.titulo] || {}).vistaDesde || "").localeCompare(String((marcas[a.titulo] || {}).vistaDesde || "")));
    $("toolbarVistas").style.display = "flex";
    const personas = [...new Set(peliculas.map(p => (marcas[p.titulo] || {}).vistaCon).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b, "es"));
    const selP = $("personaVistas");
    const previoP = selP.value;
    selP.innerHTML = '<option value="">Todas</option>' + personas.map(x => '<option value="' + esc(x) + '">' + esc(x) + '</option>').join("");
    selP.value = personas.includes(previoP) ? previoP : "";
    if (selP.value) items = items.filter(p => (marcas[p.titulo] || {}).vistaCon === selP.value);
    extra = p => {
      const m = marcas[p.titulo] || {};
      return (m.vistaDesde ? '<div class="meta" style="margin-top:6px">Vista el ' + esc(m.vistaDesde) + (m.vistaCon ? ' con ' + esc(m.vistaCon) : '') + '</div>' : '') +
        (m.nota ? '<details class="nota-recuerdo"><summary>Ver mi nota</summary><p class="nota-corta">' + esc(String(m.nota)) + '</p>' +
          (m.notaFecha ? '<div class="meta">Editada: ' + esc(m.notaFecha) + '</div>' : '') + '</details>' : '');
    };
  }

  visibles = items;
  contador.textContent = titulo + ": " + items.length + (items.length === 1 ? " título" : " títulos");

  if (!items.length) {
    const msg = pestana === "notas"
      ? "Aún no tienes notas. Abre una película y escribe en «Mi nota». Usa #palabras para etiquetarlas."
      : "Aún no marcas películas como vistas. Abre una película y pulsa «Vista» para empezar tu historial.";
    lista.innerHTML = '<p class="vacio">' + msg + '</p>';
    return;
  }
  const heroHtml = pestana === "vistas" ? heroPestana("vistas", items, {}) : "";
  lista.innerHTML = heroHtml + items.map((p, i) => filaPestana(p, i, extra ? extra(p) : "")).join("");
}

function iframeTrailer(codigo, titulo, auto = false) {
  const parametros = "?cc_load_policy=1&cc_lang_pref=es&hl=es&rel=0" + (auto ? "&autoplay=1" : "");
  return '<iframe src="https://www.youtube.com/embed/' + esc(codigo) + parametros + '" title="Tráiler de ' + esc(titulo) + '" ' +
    'allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" ' +
    'allowfullscreen loading="lazy"></iframe>';
}

function bloqueTrailer(p) {
  const es = String(p.trailer_es || "").trim();
  const en = String(p.trailer_en || "").trim();
  const hayEs = es && es !== "sin tráiler";
  const hayEn = en && en !== "sin tráiler";

  if (!hayEs && !hayEn) {
    return '<div class="trailer"><div class="trailer-vacio">Esta película no tiene tráiler disponible.</div></div>';
  }

  if (hayEs && hayEn) {
    return '<div class="trailer"><div class="trailer-titulo">Tráiler</div>' +
      '<div class="trailer-opciones">' +
        '<button class="chipc activo" data-trailer="es" data-codigo="' + esc(es) + '">Español</button>' +
        '<button class="chipc" data-trailer="en" data-codigo="' + esc(en) + '">Inglés</button>' +
      '</div>' +
      '<div class="trailer-caja" id="trailerCaja">' + contenidoTrailer(es, p.titulo) + '</div></div>';
  }

  if (hayEs) {
    return '<div class="trailer"><div class="trailer-titulo">Tráiler en español</div>' +
      '<div class="trailer-caja">' + contenidoTrailer(es, p.titulo) + '</div></div>';
  }

  return '<div class="trailer"><div class="trailer-titulo">Tráiler en su idioma original (inglés)</div>' +
    '<div class="trailer-caja">' + contenidoTrailer(en, p.titulo) + '</div>' +
    '<div class="trailer-nota">Activa los subtítulos en el reproductor (CC) para verlos en español.</div></div>';
}

function urlReproducible(link) {
  const t = String(link || "").trim();
  if (!t) return "";
  const yt = t.match(/(?:youtube\.com\/watch\?(?:.*&)?v=|youtu\.be\/)([\w-]{6,})/);
  if (yt) return "https://www.youtube.com/embed/" + yt[1] + "?rel=0&hl=es";
  return /^https:\/\//.test(t) ? t : "";
}
function abrirVerPelicula(titulo, es, en, link, auto = false) {
  const codigo = (es && es !== "sin tráiler") ? es : ((en && en !== "sin tráiler") ? en : "");
  const peli = urlReproducible(link);
  const peliSrc = auto && /youtube\.com\/embed/.test(peli) ? peli + (peli.includes("?") ? "&" : "?") + "autoplay=1" : peli;
  const previo = document.getElementById("miniReproductor");
  if (previo) previo.remove();
  const div = document.createElement("div");
  div.id = "miniReproductor";
  div.setAttribute("role", "region");
  div.setAttribute("aria-label", "Reproductor de " + titulo);
  div.dataset.titulo = titulo;
  div.dataset.codigo = codigo;
  div.dataset.peli = peli;
  div.innerHTML =
    '<div class="mr-barra"><span class="mr-titulo">▶ ' + esc(titulo) + '</span>' +
      '<span class="mr-pestanas">' +
        (peli ? '<button type="button" class="mr-chip activo" data-mr="peli">Película</button>' : '') +
        (codigo ? '<button type="button" class="mr-chip' + (peli ? '' : ' activo') + '" data-mr="trailer">Tráiler</button>' : '') +
      '</span>' +
      '<span class="mr-botones"><button type="button" data-mr="tamano" aria-label="Cambiar tamaño">⤢</button>' +
      (peli && !/youtube\.com\/embed/.test(peli) ? '<button type="button" data-mr="recorte" aria-label="Recortar barra lateral" title="Recortar barra lateral">✂</button>' : '') +
      '<button type="button" data-mr="min" aria-label="Minimizar">▁</button>' +
      '<button type="button" data-mr="cerrar" aria-label="Cerrar">✕</button></span></div>' +
    '<div class="mr-caja" id="mrCaja"></div>' +
    '<p class="mr-nota" id="mrNota"></p>';
  const caja = div.querySelector("#mrCaja");
  const nota = div.querySelector("#mrNota");
  const mostrar = (modo) => {
    div.querySelectorAll("[data-mr=peli],[data-mr=trailer]").forEach(b => b.classList.toggle("activo", b.dataset.mr === modo));
    if (modo === "peli" && peli) {
      caja.innerHTML = '<div class="mr-recorte" data-ancho="0"><iframe src="' + esc(peliSrc) + '" allow="autoplay; encrypted-media; fullscreen; picture-in-picture" allowfullscreen referrerpolicy="strict-origin-when-cross-origin" title="' + esc(titulo) + '"></iframe></div>';
      const bRec = div.querySelector("[data-mr=recorte]");
      if (bRec) bRec.hidden = false;
      nota.innerHTML = 'Si la pantalla sale en blanco, esa página no permite verla dentro de la app. <a href="' + esc(link) + '" target="_blank" rel="noopener">Abrir en otra pestaña</a>';
    } else {
      caja.innerHTML = codigo ? iframeTrailer(codigo, titulo, auto) : '<div class="mr-vacio">Esta película no tiene tráiler disponible.</div>';
      const bRec2 = div.querySelector("[data-mr=recorte]");
      if (bRec2) bRec2.hidden = true;
      nota.textContent = "Tráiler en la app.";
    }
  };
  div.addEventListener("click", e => {
    const b = e.target.closest && e.target.closest("[data-mr]");
    if (!b) return;
    if (b.dataset.mr === "cerrar") { div.remove(); document.body.classList.remove("con-reproductor"); }
    else if (b.dataset.mr === "min") div.classList.toggle("mr-min");
    else if (b.dataset.mr === "recorte") {
      const rec = div.querySelector(".mr-recorte");
      if (rec) {
        const pasos = [0, 150, 260];
        const i = (pasos.indexOf(Number(rec.dataset.ancho)) + 1) % pasos.length;
        rec.dataset.ancho = String(pasos[i]);
        rec.style.setProperty("--recorte", pasos[i] + "px");
      }
    }
    else if (b.dataset.mr === "tamano") {
      const pantallaCompleta = div.classList.contains("mr-completa");
      div.classList.toggle("mr-completa", !pantallaCompleta);
      div.classList.remove("mr-grande");
    }
    else mostrar(b.dataset.mr);
  });
  document.body.appendChild(div);
  document.body.classList.add("con-reproductor");
  mostrar(peli ? "peli" : "trailer");
}
document.addEventListener("click", e => {
  const b = e.target.closest && e.target.closest("#btnVerPelicula");
  if (!b) return;
  abrirVerPelicula(b.dataset.titulo, b.dataset.es, b.dataset.en, b.dataset.link);
});

function datosCompartir(p) {
  const es = String(p.trailer_es || "").trim();
  const en = String(p.trailer_en || "").trim();
  const codigo = (es && es !== "sin tráiler") ? es : ((en && en !== "sin tráiler") ? en : "");
  const url = codigo ? "https://www.youtube.com/watch?v=" + codigo : "";
  const anio = p["año"] ? " (" + p["año"] + ")" : "";
  return {
    title: p.titulo,
    text: 'Te recomiendo "' + p.titulo + '"' + anio,
    url: url
  };
}

async function compartirPelicula(p) {
  const datos = datosCompartir(p);
  if (navigator.share) {
    try {
      await navigator.share(datos);
    } catch (e) {}
    return;
  }
  const texto = datos.text + (datos.url ? "\n" + datos.url : "");
  try {
    await navigator.clipboard.writeText(texto);
    setEstado("Texto copiado. Pégalo donde quieras compartirlo.");
  } catch (e) {
    setEstado("Este navegador no permite compartir directamente.");
  }
}


/* ---------- Continuidad: la portada viaja desde la lista hasta la ficha ---------- */
let origenPoster = null;   // portada que se tocó para abrir la ficha
function abrirDetalle(p) {
  const reducir = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (!document.startViewTransition || reducir) return abrirDetalleBase(p);
  if (origenPoster) origenPoster.style.viewTransitionName = "poster-activo";
  const t = document.startViewTransition(() => {
    abrirDetalleBase(p);
    const nuevo = document.querySelector("#modal .ventana > #detalle img.portada");
    if (nuevo) nuevo.style.viewTransitionName = "poster-activo";
  });
  t.finished.finally(() => {
    if (origenPoster) origenPoster.style.viewTransitionName = "";
    origenPoster = null;
  });
}

function abrirDetalleBase(p) {
  detalleActual = p;
  ponerIdEnUrl(slugDe(p));
  const notaActual = (marcas[p.titulo] || {}).nota || "";
  $("detalle").innerHTML =
    (p.portada && !datosLimitados() ? '<img class="portada" loading="lazy" decoding="async" src="' + esc(p.portada) + '" alt="">' : '') +
    '<h2>' + esc(p.titulo) + '</h2>' +
    '<div class="meta">' + esc(p.tipo) + ' · ' + esc(p["año"]) + ' · ' + esc(p.duracion) + ' · ' + esc(p.pais) + '</div>' +
    '<div class="meta">Género: ' + esc(p.genero) + '</div>' +
    '<div class="meta">Dirección: ' + esc(p.director) + '</div>' +
    '<div class="meta">Reparto: ' + nombresReparto(p).map(n => '<button class="etiqueta" data-actor="' + esc(n) + '">' + ((fotosActores[n] && !datosLimitados()) ? '<img class="actor-chip-foto" loading="lazy" decoding="async" src="' + esc(fotosActores[n]) + '" alt="">' : '') + esc(n) + '</button>').join(" ") + '</div>' +
    '<div class="pastillas">' + pastillasHtml(p) + '</div>' +
    '<h4 class="ficha-h">Mi estado</h4>' + controlesHtml(p) +
    siguienteHtml(p) +
    historialHtml(p) +
    preguntasFichaHtml(p) +
    '<p class="sinopsis">' + esc(p.sinopsis) + '</p>' +
    curiosidadesFichaHtml(p) +
    '<div class="nota-bloque"><label for="notaTexto">Mi nota</label>' +
      '<textarea id="notaTexto" placeholder="Escribe lo que te pareció. Usa #etiquetas para encontrarla después.">' + esc(notaActual) + '</textarea>' +
      '<div id="etiquetasFicha" class="etiquetas-fila">' + etiquetasFichaHtml(notaActual) + '</div>' +
      (notaActual ? '<div class="nota-acciones"><button id="btnBorrarNota">Borrar nota</button></div>' : '') +
    '</div>' +
    bloqueTrailer(p) +
    '<div class="acciones">' +
      '<button type="button" class="boton" id="btnVerPelicula" data-es="' + esc(String(p.trailer_es || "")) + '" data-en="' + esc(String(p.trailer_en || "")) + '" data-titulo="' + esc(p.titulo) + '" data-link="' + esc(p.link || "") + '">Ver película</button>' +
      '<button class="pildora" id="btnCompartir">Compartir</button>' +
      '<button class="pildora" id="btnEnlace">🔗 Copiar enlace</button>' +
    '</div>';

  $("detalle").insertAdjacentHTML("beforeend",
    '<div class="acciones-ficha"><button type="button" class="pildora" id="fichaCarta">📬 Escribir carta</button>' +
    '<button type="button" class="pildora" id="fichaVotar">🗳 Votar en pareja</button></div>');
  document.getElementById("fichaCarta").addEventListener("click", () => { cerrarDetalle(); abrirBuzon(); });
  document.getElementById("fichaVotar").addEventListener("click", () => { cerrarDetalle(); abrirVotacionPareja(); });
  $("otra").innerHTML = desdeAleatorio
    ? '<button class="pildora destacado" id="otraSugerencia">🎲 Otra sugerencia</button>'
    : '';
  $("modal").classList.add("abierto");
  aplicarPaleta(p);
}

function cerrarDetalle() {
  $("modal").classList.remove("abierto");
  $("detalle").innerHTML = "";
  desdeAleatorio = false;
  detalleActual = null;
  $("otra").innerHTML = "";
  ponerIdEnUrl(null);
}

function sugerirAleatoria() {
  if (modoPareja()) { sugerirParaDos(); return; }
  if (!visibles.length) {
    contador.textContent = "No hay películas con esos criterios para sugerir.";
    return;
  }
  let p = visibles[Math.floor(Math.random() * visibles.length)];
  const actual = $("detalle").querySelector("h2")?.textContent;
  if (visibles.length > 1 && p.titulo === actual) {
    p = visibles[(visibles.indexOf(p) + 1) % visibles.length];
  }
  desdeAleatorio = true;
  abrirDetalle(p);
}

/* ---------- Qué ver esta noche: elige según el tiempo disponible ---------- */
let ultimaNoche = null;

const estiloNoche = document.createElement("style");
estiloNoche.textContent = `
.noche-panel{position:fixed;left:50%;bottom:20px;transform:translateX(-50%);width:min(420px,92vw);background:var(--tarjeta);color:var(--texto);border-radius:var(--radio-grande);box-shadow:var(--sombra);padding:16px;z-index:60}
.noche-cab{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
.noche-cab button{background:none;border:0;font-size:22px;color:var(--gris);cursor:pointer}
.noche-panel select{width:100%;padding:10px 12px;border-radius:999px;border:1px solid var(--borde);background:var(--fondo);color:var(--texto);font-size:14px;margin-bottom:10px}
.noche-tarjeta{display:flex;gap:12px;margin-top:12px;align-items:flex-start}
.noche-tarjeta img{width:96px;height:144px;object-fit:cover;border-radius:12px;flex-shrink:0}
.noche-tarjeta .noche-sin{width:96px;height:144px;display:grid;place-items:center;font-size:36px;background:var(--boton-suave);border-radius:12px;flex-shrink:0}
.noche-info{min-width:0}
.noche-info h3{margin:0 0 4px;font-size:17px}
.noche-info p{margin:0 0 10px;font-size:13px;color:var(--gris)}
.noche-acciones{display:flex;flex-wrap:wrap;gap:6px}
.noche-acciones button{border:0;border-radius:999px;padding:7px 12px;font-size:13px;background:var(--boton-suave);color:var(--texto);cursor:pointer}
.noche-acciones button.principal{background:var(--azul);color:#fff}
.noche-vacio{font-size:14px;color:var(--gris);margin:12px 0 0}`;
document.head.appendChild(estiloNoche);

function abrirQueVerEstaNoche() {
  let panel = document.getElementById("nochePanel");
  if (panel) panel.remove();
  panel = document.createElement("div");
  panel.id = "nochePanel";
  panel.className = "noche-panel";

  const cab = document.createElement("div");
  cab.className = "noche-cab";
  const titulo = document.createElement("b");
  titulo.textContent = "🍿 ¿Cuánto tiempo tienes?";
  const cerrar = document.createElement("button");
  cerrar.type = "button";
  cerrar.setAttribute("aria-label", "Cerrar");
  cerrar.textContent = "×";
  cerrar.addEventListener("click", () => panel.remove());
  cab.append(titulo, cerrar);

  const sel = document.createElement("select");
  sel.id = "nocheTiempo";
  [["60", "Hasta 1 hora"], ["90", "Hasta 1 h 30 min"], ["120", "Hasta 2 horas"], ["150", "Hasta 2 h 30 min"], ["180", "Hasta 3 horas"], ["0", "Sin límite"]]
    .forEach(([v, t], i) => {
      const o = document.createElement("option");
      o.value = v;
      o.textContent = t;
      if (v === "120") o.selected = true;
      sel.appendChild(o);
    });

  const elegir = document.createElement("button");
  elegir.type = "button";
  elegir.className = "pildora destacado";
  elegir.textContent = "Elegir película";
  elegir.addEventListener("click", () => elegirNoche(false));

  const resultado = document.createElement("div");
  resultado.id = "nocheResultado";
  panel.append(cab, sel, elegir, resultado);
  document.body.appendChild(panel);
  ultimaNoche = null;
  elegirNoche(false);
}

function elegirNoche(otra) {
  const sel = document.getElementById("nocheTiempo");
  const res = document.getElementById("nocheResultado");
  if (!sel || !res) return;
  const tiempo = Number(sel.value);
  const base = peliculas.filter(p => !estadoDe(p).vista && !(marcas[p.titulo] || {}).descartada);
  const cabe = p => !tiempo || (minutos(p) > 0 && minutos(p) <= tiempo);
  let pool = base.filter(p => estadoDe(p).pendiente && cabe(p));
  if (!pool.length) pool = base.filter(cabe);
  if (otra && ultimaNoche && pool.length > 1) pool = pool.filter(p => p.titulo !== ultimaNoche.titulo);

  res.textContent = "";
  if (!pool.length) {
    const vacio = document.createElement("p");
    vacio.className = "noche-vacio";
    vacio.textContent = "Ninguna de tus pendientes cabe en ese tiempo. Prueba con más minutos o agrega películas a pendientes.";
    res.appendChild(vacio);
    return;
  }
  const p = pool[Math.floor(Math.random() * pool.length)];
  ultimaNoche = p;

  const tarjeta = document.createElement("div");
  tarjeta.className = "noche-tarjeta";
  if (p.portada) {
    const img = document.createElement("img");
    img.src = p.portada;
    img.alt = "";
    tarjeta.appendChild(img);
  } else {
    const sinPortada = document.createElement("div");
    sinPortada.className = "noche-sin";
    sinPortada.textContent = "🎬";
    tarjeta.appendChild(sinPortada);
  }

  const info = document.createElement("div");
  info.className = "noche-info";
  const h = document.createElement("h3");
  h.textContent = p.titulo;
  const meta = document.createElement("p");
  const partes = [p["año"], p.duracion, p.director].filter(Boolean);
  const durMin = minutos(p);
  const fmtMin = m => (Math.floor(m / 60) ? Math.floor(m / 60) + " h " : "") + (m % 60) + " min";
  meta.textContent = partes.join(" · ");
  if (tiempo && durMin) {
    const sobra = document.createElement("span");
    sobra.className = "noche-sobra";
    sobra.textContent = "Te sobran " + fmtMin(tiempo - durMin);
    meta.appendChild(document.createElement("br"));
    meta.appendChild(sobra);
  }
  const acciones = document.createElement("div");
  acciones.className = "noche-acciones";

  const verFicha = document.createElement("button");
  verFicha.type = "button";
  verFicha.className = "principal";
  verFicha.textContent = "Ver ficha";
  verFicha.addEventListener("click", () => { document.getElementById("nochePanel")?.remove(); abrirDetalle(p); });

  const otraBtn = document.createElement("button");
  otraBtn.type = "button";
  otraBtn.textContent = "Otra";
  otraBtn.addEventListener("click", () => elegirNoche(true));

  const vista = document.createElement("button");
  vista.type = "button";
  vista.textContent = "Ya la vi";
  vista.addEventListener("click", () => {
    cambiarEstado(p.titulo, { vista: true });
    refrescarTodo();
    elegirNoche(true);
  });

  acciones.append(verFicha, otraBtn, vista);
  info.append(h, meta, acciones);
  tarjeta.appendChild(info);
  res.appendChild(tarjeta);
}

function refrescarTodo() {
  pintar();
  if ($("modal").classList.contains("abierto")) {
    const actual = peliculas.find(p => p.titulo === $("detalle").querySelector("h2")?.textContent);
    if (actual) abrirDetalle(actual);
  }
}

const ZONAS_PELICULAS = [["lista","Lista"],["estrenos","Estrenos"],["sagas","Sagas"],["actores","Actores"],["duelo","Duelo"]];
const ZONAS_VISTAS = [["lista","Películas vistas"],["resumen","Resumen"],["actividad","Actividad"],["mapa","Mapa de gustos"],["descartadas","Descartadas"]];

// Qué pestaña de la barra está activa
function tabActiva() {
  if (pestana === "descartadas") return "vistas";
  if (pestana === "catalogo") return zonaPeli === "inicio" ? "inicio" : "catalogo";
  return pestana;
}

// Qué bloque de la página corresponde a la vista actual
function zonaActual() {
  if (pestana === "catalogo") return zonaPeli;
  if (pestana === "vistas") return zonaVistas;
  return "lista";
}

// Cambia el estado según la pestaña de la barra (sin pintar)
function fijarTab(nombre) {
  if (nombre === "inicio") { pestana = "catalogo"; zonaPeli = "inicio"; return; }
  if (nombre === "catalogo") { pestana = "catalogo"; zonaPeli = "lista"; return; }
  if (nombre === "vistas") { pestana = "vistas"; zonaVistas = "lista"; return; }
  pestana = nombre; // notas, pendientes, descartadas
}

function guardarTab() {
  const v = pestana === "catalogo" ? (zonaPeli === "inicio" ? "inicio" : "catalogo") : pestana;
  try { localStorage.setItem("pestana_activa", v); } catch (e) {}
}

// Paneles del encabezado (⚙ filtros y ⋯ menú): se muestran como hoja inferior y solo uno a la vez
function cerrarPaneles() {
  document.getElementById("panelMas").classList.remove("abierto");
  document.getElementById("panelAvanzados").classList.remove("abierto");
  document.body.classList.remove("panel-abierto");
}

function alternarPanel(id) {
  const el = document.getElementById(id);
  const abrir = !el.classList.contains("abierto");
  cerrarPaneles();
  if (abrir) {
    el.classList.add("abierto");
    el.scrollTop = 0;
    document.body.classList.add("panel-abierto");
  }
}

document.getElementById("velo").addEventListener("click", cerrarPaneles);
document.addEventListener("keydown", e => { if (e.key === "Escape") cerrarPaneles(); });

function limpiarFiltros() {
  buscar.value = "";
  Object.values(sel).forEach(s => s.value = "");
  cerrarPaneles();
}

// Muestra solo los bloques de la zona actual, marca la pestaña y el selector interno
function aplicarZona() {
  const actual = zonaActual();
  document.querySelectorAll("[data-zona]").forEach(el => {
    el.classList.toggle("fuera-zona", el.dataset.zona !== actual);
  });
  const tab = tabActiva();
  document.querySelectorAll("#tabbar button").forEach(b => b.classList.toggle("activa", b.dataset.tab === tab));

  const cont = $("selectorZona");
  let opciones = null;
  if (pestana === "catalogo" && zonaPeli !== "inicio") opciones = ZONAS_PELICULAS;
  else if (pestana === "vistas" || pestana === "descartadas") opciones = ZONAS_VISTAS;
  if (!opciones) { cont.style.display = "none"; cont.innerHTML = ""; return; }
  const activa = pestana === "descartadas" ? "descartadas" : actual;
  cont.style.display = "";
  cont.innerHTML = opciones.map(([v, t]) =>
    '<button type="button" data-zona-op="' + v + '" class="' + (v === activa ? "activa" : "") + '">' + t + '</button>'
  ).join("");
}

function aplicarEstadoTabs() {
  document.body.classList.toggle("solo-lista", pestana !== "catalogo");
  $("buscar").placeholder = pestana === "notas"
    ? "Busca en tus notas o escribe #etiqueta..."
    : pestana === "descartadas" ? "Buscar en descartadas..." : "Busca por título, director o actor";
  aplicarZona();
}

function cambiarPestana(nombre) {
  fijarTab(nombre);
  if (pestana !== "catalogo" || zonaPeli === "inicio") limpiarFiltros();
  setEstado("");
  guardarTab();
  aplicarEstadoTabs();
  pintar();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// Selector interno: Películas (lista, estrenos, sagas, actores, duelo) o Vistas (lista, resumen, actividad, mapa, descartadas)
function elegirZona(v) {
  if (pestana === "catalogo") zonaPeli = v;
  else if (v === "descartadas") pestana = "descartadas";
  else { pestana = "vistas"; zonaVistas = v; }
  if (pestana !== "catalogo") limpiarFiltros();
  setEstado("");
  guardarTab();
  aplicarEstadoTabs();
  pintar();
}

let cls = { cola: [], pila: [], x: 0, dx: 0, activo: false };

function candidatasClasificar() {
  return peliculas.filter(p => {
    const o = marcas[p.titulo] || {};
    if (o.vista || o.pendiente || o.descartada) return false;
    if (sel.genero.value && !generosDe(p).includes(sel.genero.value)) return false;
    return true;
  });
}

function clasActual() { return cls.cola[0]; }

function pintarClasificador() {
  const p = clasActual();
  const zona = $("clasZona");
  $("clasContador").textContent = cls.cola.length
    ? cls.cola.length + " por clasificar"
    : "Listo";
  $("clasIzq").disabled = !p;
  $("clasDer").disabled = !p;
  $("clasDeshacer").disabled = !cls.pila.length;

  if (!p) {
    zona.innerHTML = '<p class="vacio">Ya no quedan películas por clasificar. ¡Buen trabajo!</p>';
    return;
  }

  zona.innerHTML =
    '<div class="clas-card" id="clasCard">' +
      '<div class="clas-sello izq">DESCARTAR</div>' +
      '<div class="clas-sello der">PENDIENTE</div>' +
      (p.portada && !datosLimitados() ? '<img src="' + esc(p.portada) + '" alt="">' : '<div class="sinportada">🎬</div>') +
      '<h2>' + esc(p.titulo) + '</h2>' +
      '<div class="meta">' + esc(p.tipo) + ' · ' + esc(p["año"]) + ' · ' + esc(p.duracion) + ' · ' + esc(p.pais) + '</div>' +
      '<div class="meta">' + esc(p.genero) + '</div>' +
      '<p class="sinopsis">' + esc(p.sinopsis) + '</p>' +
    '</div>';
}

function clasAccion(dir) {
  const p = clasActual();
  if (!p) return;
  const prev = marcas[p.titulo] ? Object.assign({}, marcas[p.titulo]) : null;
  cls.pila.push({ p, prev });

  if (dir === "der") cambiarEstado(p.titulo, { pendiente: true, vista: false, descartada: false });
  else cambiarEstado(p.titulo, { descartada: true, pendiente: false, vista: false });

  cls.cola.shift();
  pintarClasificador();
  refrescarTodo();
}

function clasDeshacer() {
  const ult = cls.pila.pop();
  if (!ult) return;
  if (ult.prev) marcas[ult.p.titulo] = ult.prev;
  else delete marcas[ult.p.titulo];
  programarGuardado();
  cls.cola.unshift(ult.p);
  pintarClasificador();
  refrescarTodo();
}

function abrirClasificador() {
  cls.cola = candidatasClasificar();
  cls.pila = [];
  $("clasificador").classList.add("abierto");
  pintarClasificador();
}

function cerrarClasificador() {
  $("clasificador").classList.remove("abierto");
  refrescarTodo();
}

function moverSellos(dx) {
  const card = $("clasCard");
  if (!card) return;
  const fuerza = Math.min(Math.abs(dx) / 110, 1);
  card.querySelector(".clas-sello.der").style.opacity = dx > 0 ? fuerza : 0;
  card.querySelector(".clas-sello.izq").style.opacity = dx < 0 ? fuerza : 0;
}

// Comprueba que la cuenta que inició sesión sea la institucional. Sin dominio configurado, no restringe.
async function cuentaPermitida(token) {
  if (!DOMINIO_INSTITUCIONAL) return true;
  try {
    const r = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
      headers: { Authorization: "Bearer " + token }
    });
    if (!r.ok) return false;
    const j = await r.json();
    const correo = String(j.email || "").toLowerCase();
    const dominio = DOMINIO_INSTITUCIONAL.toLowerCase();
    // En Google Workspace, "hd" indica la organización de la cuenta; si viene, debe coincidir
    const orgOk = !j.hd || String(j.hd).toLowerCase() === dominio;
    return j.email_verified !== false && correo.endsWith("@" + dominio) && orgOk;
  } catch (e) {
    return false;
  }
}

function mostrarError(msg) {
  $("error").textContent = msg;
  $("btnLogin").disabled = false;
  $("btnLogin").textContent = "Iniciar sesión con Google";
}

/* ---------- Modo sin conexión: copia local del catálogo ---------- */
async function actualizarCopiaEnSegundoPlano() {
  if (!accessToken || !navigator.onLine || !HOJA_ID) return;
  try {
    const r = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${HOJA_ID}/values/A:Z`, {
      headers: { Authorization: "Bearer " + accessToken }
    });
    if (!r.ok) return;
    const j = await r.json();
    const nuevas = j.values || [];
    let previas = null;
    try { previas = (JSON.parse(localStorage.getItem("catalogo_hoja_cache") || "null") || {}).filas || null; } catch (e) {}
    if (JSON.stringify(previas) === JSON.stringify(nuevas)) return;
    guardarCopiaHoja(nuevas);
    const b = document.getElementById("bannerSinConexion");
    if (b) {
      b.textContent = "Hay cambios nuevos en el catálogo. Recarga la página para verlos.";
      b.hidden = false;
    }
  } catch (e) { /* sin conexión o error: se intenta en la siguiente vuelta */ }
}
function guardarCopiaHoja(filas) {
  try { localStorage.setItem("catalogo_hoja_cache", JSON.stringify({ fecha: new Date().toISOString(), filas: filas })); }
  catch (e) { /* si la copia no cabe, simplemente no se guarda */ }
}

function mostrarBannerOffline(fechaISO) {
  const b = document.getElementById("bannerSinConexion");
  if (!b) return;
  const fecha = fechaISO ? new Date(fechaISO).toLocaleString("es-MX", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "";
  b.textContent = "Sin conexión: viendo la copia" + (fecha ? " del " + fecha : "") + ". Tus cambios se guardan aquí y se suben al volver la conexión.";
  b.hidden = false;
}

function ocultarBannerOffline() {
  const b = document.getElementById("bannerSinConexion");
  if (b) b.hidden = true;
}

async function cargarDesdeCopia() {
  let copia = null;
  try { copia = JSON.parse(localStorage.getItem("catalogo_hoja_cache") || "null"); } catch (e) { copia = null; }
  if (!copia || !copia.filas || !copia.filas.length) return false;

  const filas = copia.filas;
  encabezados = (filas[0] || []).slice();
  COL_PALETA = encabezados.indexOf(NOMBRE_PALETA);
  peliculas = [];
  filas.slice(1).forEach((f, i) => {
    if (!f[0]) return;
    const o = { _fila: i + 2 };
    encabezados.forEach((n, j) => o[n] = f[j] ?? "");
    peliculas.push(o);
  });
  fotosActores = {};
  peliculas.forEach(p => {
    try {
      const m = JSON.parse(p.fotos_reparto || "{}");
      Object.entries(m).forEach(([n, u]) => { if (!fotosActores[n]) fotosActores[n] = u; });
    } catch (e) {}
  });

  await cargarMarcas();
  $("login").style.display = "none";
  $("app").style.display = "block";
  const botonChat = document.getElementById("chatAbrir");
  if (botonChat) botonChat.style.display = "";
  document.body.classList.add("con-sesion");
  llenarFiltros();
  llenarSugerencias();
  renderDestacados();
  pintar();
  mostrarBannerOffline(copia.fecha);
  return true;
}

async function cargarHoja() {
  try {
    const r = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${HOJA_ID}/values/A:Z`, {
      headers: { Authorization: "Bearer " + accessToken }
    });
    const json = await r.json();
    if (!r.ok) throw new Error(json.error?.message || "No se pudo leer la hoja.");

    const filas = json.values || [];
    encabezados = (filas[0] || []).slice();
    COL_PALETA = encabezados.indexOf(NOMBRE_PALETA);

    peliculas = [];
    filas.slice(1).forEach((f, i) => {
      if (!f[0]) return;
      const o = { _fila: i + 2 };
      encabezados.forEach((n, j) => o[n] = f[j] ?? "");
      peliculas.push(o);
    });

    fotosActores = {};
    peliculas.forEach(p => {
      try {
        const m = JSON.parse(p.fotos_reparto || "{}");
        Object.entries(m).forEach(([n, u]) => { if (!fotosActores[n]) fotosActores[n] = u; });
      } catch (e) {}
    });
    guardarCopiaHoja(filas);

    $("login").style.display = "none";
    $("app").style.display = "block";
    const botonChat = document.getElementById("chatAbrir");
    if (botonChat) botonChat.style.display = "";
    document.body.classList.add("con-sesion");
    llenarFiltros();
    llenarSugerencias();
    renderDestacados();
    pintar();
    abrirDesdeUrl();
  } catch (e) {
    mostrarError(e.message);
  }
}

/* ---------- Curiosidades ----------
   Fuentes: (1) pestaña «curiosidades» de tu hoja (tmdb_id, titulo, tema, texto, fuente)
            (2) datos de tu propio catálogo (año, país, duración, director, reparto): siempre verificables.
   Sin internet se usa la copia guardada en el dispositivo. */
let curiosidadesTabla = [];
let curioOffset = 0;
const CURIOS_CACHE = "curiosidades_cache";

let indiceDirectoresCache = { ref: null, n: -1, mapa: null };
function indiceDirectores() {
  if (indiceDirectoresCache.ref === peliculas && indiceDirectoresCache.n === peliculas.length) return indiceDirectoresCache.mapa;
  const mapa = new Map();
  peliculas.forEach(x => directoresDe(x).forEach(d => mapa.set(d, (mapa.get(d) || 0) + 1)));
  indiceDirectoresCache = { ref: peliculas, n: peliculas.length, mapa };
  return mapa;
}

// Rankings, sagas, países, actores y calificaciones de TODA la colección; se calculan una sola vez
let indiceDatosCache = { ref: null, n: -1, d: null };
function indiceDatos() {
  if (indiceDatosCache.ref === peliculas && indiceDatosCache.n === peliculas.length) return indiceDatosCache.d;
  const anios = [], mins = [], sagas = new Map(), paises = new Map(), actores = new Map();
  let suma = 0, cuantas = 0;
  peliculas.forEach(x => {
    const serie = /serie/i.test(String(x.tipo || ""));
    const a = Number(x["año"]);
    if (a && !serie) anios.push(a);
    const m = parseInt(String(x.duracion || ""), 10);
    if (m && !serie) mins.push(m);
    const s = String(x.saga || "").trim();
    if (s && s !== "-") sagas.set(s, (sagas.get(s) || 0) + 1);
    String(x.pais || "").split(",").map(t => t.trim()).filter(Boolean).forEach(t => paises.set(t, (paises.get(t) || 0) + 1));
    nombresReparto(x).forEach(n => actores.set(n, (actores.get(n) || 0) + 1));
    const e = Number(estadoDe(x).estrellas);
    if (e) { suma += e; cuantas++; }
  });
  anios.sort((a, b) => a - b);
  mins.sort((a, b) => a - b);
  const d = { anios, mins, sagas, paises, actores, promEst: cuantas ? suma / cuantas : null };
  indiceDatosCache = { ref: peliculas, n: peliculas.length, d };
  return d;
}

// Cuántos valores de una lista ordenada son menores que v (búsqueda binaria)
function menoresQue(arr, v) {
  let lo = 0, hi = arr.length;
  while (lo < hi) { const mid = (lo + hi) >> 1; if (arr[mid] < v) lo = mid + 1; else hi = mid; }
  return lo;
}

function curiosidadesAuto(p) {
  const out = [];
  const D = indiceDatos();
  const fuente = "Tu catálogo";
  const esSerie = /serie/i.test(String(p.tipo || ""));

  // Récords: solo aparecen cuando la película está entre las extremas de tu colección
  const a = Number(p["año"]);
  if (!esSerie && a && D.anios.length > 10) {
    const masViejas = menoresQue(D.anios, a);
    const masNuevas = D.anios.length - menoresQue(D.anios, a + 1);
    if (masViejas < 10) out.push({ tema: "Récord", texto: "Solo hay " + masViejas + " películas más antiguas que ella en tu colección.", fuente });
    else if (masNuevas < 10) out.push({ tema: "Récord", texto: "Solo hay " + masNuevas + " películas más nuevas que ella en tu colección.", fuente });
  }
  const m = parseInt(String(p.duracion || ""), 10);
  if (!esSerie && m && D.mins.length > 10) {
    const masCortas = menoresQue(D.mins, m);
    const masLargas = D.mins.length - menoresQue(D.mins, m + 1);
    if (masLargas < 10) out.push({ tema: "Récord", texto: "Solo hay " + masLargas + " películas más largas que ella en tu colección.", fuente });
    else if (masCortas < 10) out.push({ tema: "Récord", texto: "Solo hay " + masCortas + " películas más cortas que ella en tu colección.", fuente });
  }

  const s = String(p.saga || "").trim();
  if (s && s !== "-" && (D.sagas.get(s) || 0) > 1) {
    out.push({ tema: "Saga", texto: "Forma parte de la saga «" + s + "»: tienes " + D.sagas.get(s) + " películas de ella en tu colección.", fuente });
  }

  const pais = String(p.pais || "").split(",")[0].trim();
  if (pais && (D.paises.get(pais) || 0) > 1) {
    out.push({ tema: "País", texto: "De " + pais + " tienes " + D.paises.get(pais) + " películas en tu colección, incluida esta.", fuente });
  }

  const dir = directoresDe(p);
  if (dir.length) {
    const total = indiceDirectores().get(dir[0]) || 0;
    if (total > 1) out.push({ tema: "Director", texto: "De " + dir[0] + " tienes " + total + " películas en tu colección, incluida esta.", fuente });
  }

  // El actor de esta película que más se repite en tu colección
  const actor = nombresReparto(p).map(n => [n, D.actores.get(n) || 0]).sort((x, y) => y[1] - x[1])[0];
  if (actor && actor[1] > 1) out.push({ tema: "Reparto", texto: actor[0] + " aparece en " + actor[1] + " películas de tu colección, incluida esta.", fuente });

  // Tu calificación frente a tu promedio
  const e = Number(estadoDe(p).estrellas);
  if (e && D.promEst) out.push({ tema: "Tu calificación", texto: "Le diste " + e + "★. Tu promedio general es " + D.promEst.toFixed(1) + "★.", fuente: "Tus calificaciones" });

  return out;
}

function curiosidadesDe(p) {
  const id = String(p.tmdb_id || "").trim();
  const curadas = curiosidadesTabla.filter(c => (c.tmdb && c.tmdb === id) || (c.titulo && c.titulo.toLowerCase() === String(p.titulo).toLowerCase()));
  return curadas.concat(curiosidadesAuto(p));
}

// Cache: con cientos de películas, recalcular todas las curiosidades en cada pintado sería lento
let todasCache = { peliculas: null, n: -1, tabla: null, lista: null };
function todasLasCuriosidades() {
  if (todasCache.lista && todasCache.peliculas === peliculas && todasCache.n === peliculas.length && todasCache.tabla === curiosidadesTabla) return todasCache.lista;
  const lista = calcularTodasLasCuriosidades();
  todasCache = { peliculas, n: peliculas.length, tabla: curiosidadesTabla, lista };
  return lista;
}

function calcularTodasLasCuriosidades() {
  const curadas = curiosidadesTabla.map(c => {
    const peli = peliculas.find(p => (c.tmdb && String(p.tmdb_id || "").trim() === c.tmdb) || (c.titulo && String(p.titulo).toLowerCase() === c.titulo.toLowerCase()));
    return Object.assign({}, c, { peli: peli || null });
  }).filter(c => c.peli);
  const autos = peliculas.flatMap(p => curiosidadesAuto(p).map(c => Object.assign({}, c, { peli: p })));
  return curadas.concat(autos);
}

function curiosidadDelDia() {
  const lista = todasLasCuriosidades();
  if (!lista.length) return null;
  const dia = Math.floor(Date.parse(hoyLocalISO() + "T00:00") / 86400000);
  return lista[(dia + curioOffset) % lista.length];
}

function curiosidadesFichaHtml(p) {
  const lista = curiosidadesDe(p).slice(0, 3);
  if (!lista.length) return "";
  return '<h4 class="ficha-h">Lo que quizá no sabías</h4><ul class="cur-lista">' +
    lista.map(c => '<li><span class="cur-tema">' + esc(c.tema || "Dato") + '</span> ' + esc(c.texto) +
      (c.fuente ? ' <small>' + esc(c.fuente) + '</small>' : '') + '</li>').join("") + '</ul>';
}

function abrirTodasCuriosidades(temaElegido) {
  const todas = todasLasCuriosidades();
  const temas = [...new Set(todas.map(c => c.tema || "Dato"))];
  const filtradas = temaElegido ? todas.filter(c => (c.tema || "Dato") === temaElegido) : todas;
  let panel = document.getElementById("curiosidadesTodas");
  if (!panel) {
    panel = document.createElement("div");
    panel.id = "curiosidadesTodas";
    document.body.appendChild(panel);
  }
  panel.innerHTML =
    '<div class="cur-panel-caja" role="dialog" aria-label="Todas las curiosidades">' +
      '<div class="cur-panel-cab"><strong>Curiosidades</strong><button type="button" data-cur-cerrar aria-label="Cerrar">✕</button></div>' +
      '<div class="cur-temas">' +
        '<button type="button" data-cur-tema="" class="' + (!temaElegido ? 'activo' : '') + '">Todas</button>' +
        temas.map(t => '<button type="button" data-cur-tema="' + esc(t) + '" class="' + (t === temaElegido ? 'activo' : '') + '">' + esc(t) + '</button>').join("") +
      '</div>' +
      '<ul class="cur-lista cur-lista-todas">' +
        (filtradas.length ? filtradas.slice(0, 200).map((c, i) =>
          '<li data-cur-peli="' + i + '"><span class="cur-tema">' + esc(c.tema || "Dato") + '</span> <strong>' + esc(c.peli.titulo) + '</strong><br>' +
          esc(c.texto) + (c.fuente ? ' <small>' + esc(c.fuente) + '</small>' : '') + '</li>').join("")
          : '<li>No hay curiosidades en este tema.</li>') +
      '</ul>' +
    '</div>';
  panel.onclick = e => {
    if (e.target === panel || e.target.closest("[data-cur-cerrar]")) { panel.remove(); return; }
    const t = e.target.closest("[data-cur-tema]");
    if (t) { abrirTodasCuriosidades(t.dataset.curTema || null); return; }
    const li = e.target.closest("[data-cur-peli]");
    if (li) { const c = filtradas[Number(li.dataset.curPeli)]; panel.remove(); if (c && c.peli) abrirDetalle(c.peli); }
  };
}

// La curiosidad ya no es una barra: se abre con el botón ✨ (ver abrirCuriosidad).
function renderCuriosidadDia() {}

// URL del servidor (la misma Aplicación web de Apps Script que usa el asistente)
const CURIO_URL = "PEGA_AQUI_LA_URL_DE_TU_APPS_SCRIPT";
const CURIO_HIST = "curio_historial";

function historialCurio() {
  try { return JSON.parse(localStorage.getItem(CURIO_HIST) || "[]"); } catch (e) { return []; }
}
function guardarHistorialCurio(lista) {
  try { localStorage.setItem(CURIO_HIST, JSON.stringify(lista.slice(-60))); } catch (e) {}
}

function elegirPeliculaCurio() {
  const hist = historialCurio();
  const pool = peliculas.filter(p => p.titulo && !/serie/i.test(String(p.tipo || "")));
  const nuevas = pool.filter(p => !hist.some(h => h.titulo === p.titulo));
  const base = nuevas.length ? nuevas : pool;
  return base[Math.floor(Math.random() * base.length)];
}

function abrirCuriosidadSheet() {
  let hoja = document.getElementById("curioSheet");
  if (!hoja) {
    hoja = document.createElement("div");
    hoja.id = "curioSheet";
    hoja.className = "cur-sheet";
    hoja.innerHTML = '<div class="cur-sheet-caja" role="dialog" aria-label="Curiosidad"><div class="cur-sheet-cuerpo" id="curioSheetCuerpo"></div></div>';
    hoja.addEventListener("click", e => { if (e.target === hoja) hoja.classList.remove("abierta"); });
    document.body.appendChild(hoja);
  }
  hoja.classList.add("abierta");
  generarCuriosidadNueva();
}

async function generarCuriosidadNueva() {
  const cuerpo = document.getElementById("curioSheetCuerpo");
  const peli = elegirPeliculaCurio();
  curioPeliActual = peli || null;
  if (!peli) { cuerpo.innerHTML = '<p class="cur-texto">Agrega películas para ver curiosidades.</p>'; return; }
  cuerpo.innerHTML = '<div class="cur-tema">' + esc(peli.titulo) + '</div><p class="cur-texto cur-cargando">Buscando una curiosidad verificada…</p>';

  const hist = historialCurio();
  try {
    const r = await fetch(CURIO_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify({
        token: accessToken,
        accion: "curiosidad",
        pelicula: { titulo: peli.titulo, año: peli.año, director: peli.director, reparto: peli.reparto, genero: peli.genero, pais: peli.pais },
        evitar: hist.map(h => h.texto)
      })
    });
    const j = await r.json();
    if (j.error) {
      cuerpo.innerHTML = '<div class="cur-tema">' + esc(peli.titulo) + '</div><p class="cur-texto">' + esc(j.error) + '</p>' + pieCurio(peli, null);
      return;
    }
    hist.push({ titulo: peli.titulo, texto: j.texto });
    guardarHistorialCurio(hist);
    cuerpo.innerHTML =
      '<div class="cur-tema">' + esc(j.tema) + ' · ' + esc(peli.titulo) + '</div>' +
      '<p class="cur-texto">' + esc(j.texto) + '</p>' +
      '<small class="cur-fuente">Fuente: <a href="' + esc(j.url) + '" target="_blank" rel="noopener">' + esc(j.fuente || j.url) + '</a></small>' +
      pieCurio(peli, j.texto);
  } catch (e) {
    cuerpo.innerHTML = '<p class="cur-texto">No pude conectar. Revisa tu conexión e inténtalo de nuevo.</p>' + pieCurio(peli, null);
  }
}

function pieCurio(peli, texto) {
  return '<div class="cur-pie">' +
    '<button type="button" class="pildora" data-cur="historia">Historia</button>' +
    '<button type="button" class="pildora" data-cur="otra">Otra</button>' +
    '<button type="button" class="pildora" data-cur="ver">Ver ficha</button>' +
    (texto ? '<button type="button" class="pildora" data-cur="copiar">Copiar</button>' : '') +
    '<button type="button" class="pildora" data-cur="cerrar">Cerrar</button>' +
    '</div>';
}

let curioPeliActual = null;

const FORMATOS_HISTORIA = ["una escena breve", "una carta", "una página de diario", "un diálogo", "una noticia de periódico ficticia", "un monólogo"];

function contextoHistoria(peli) {
  const h = new Date().getHours();
  const momento = h < 6 ? "madrugada" : h < 12 ? "mañana" : h < 19 ? "tarde" : "noche";
  const estado = (typeof estadoDe === "function") ? estadoDe(peli) : {};
  return { momento, estrellas: estado.estrellas || 0, conAlguien: !!estado.conAlguien, vista: !!estado.vista };
}

async function generarHistoria(peli) {
  const cuerpo = document.getElementById("curioSheetCuerpo");
  const formato = FORMATOS_HISTORIA[Math.floor(Math.random() * FORMATOS_HISTORIA.length)];
  const usarPersonajesOriginales = Math.random() < 0.5;
  cuerpo.innerHTML = '<div class="cur-tema">' + esc(peli.titulo) + '</div><p class="cur-texto cur-cargando">Escribiendo una historia…</p>';
  try {
    const r = await fetch(CURIO_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify({
        token: accessToken,
        accion: "historia",
        pelicula: { titulo: peli.titulo, año: peli.año, director: peli.director, reparto: peli.reparto, genero: peli.genero, tema: peli.temas },
        contexto: Object.assign(contextoHistoria(peli), { formato: formato, personajes: usarPersonajesOriginales ? "de la película" : "nuevos, inspirados en la trama" })
      })
    });
    const j = await r.json();
    if (j.error) {
      cuerpo.innerHTML = '<p class="cur-texto">' + esc(j.error) + '</p>' + pieCurio(peli, null);
      return;
    }
    cuerpo.innerHTML =
      '<div class="cur-tema">Ficción inspirada en ' + esc(peli.titulo) + '</div>' +
      '<h4 class="cur-historia-titulo">' + esc(j.titulo) + '</h4>' +
      '<p class="cur-texto cur-historia">' + esc(j.texto) + '</p>' +
      '<small class="cur-fuente">Historia inventada. No es un hecho real.</small>' +
      '<div class="cur-pie">' +
        '<button type="button" class="pildora" data-cur="historia-otra">Otra historia</button>' +
        '<button type="button" class="pildora" data-cur="ver">Ver ficha</button>' +
        '<button type="button" class="pildora" data-cur="cerrar">Cerrar</button>' +
      '</div>';
  } catch (e) {
    cuerpo.innerHTML = '<p class="cur-texto">No pude conectar. Revisa tu conexión e inténtalo de nuevo.</p>' + pieCurio(peli, null);
  }
}

document.addEventListener("click", e => {
  const b = e.target.closest && e.target.closest("#curioSheet [data-cur]");
  if (!b) return;
  const hoja = document.getElementById("curioSheet");
  const accion = b.dataset.cur;
  if (accion === "otra") generarCuriosidadNueva();
  else if (accion === "historia") { if (curioPeliActual) generarHistoria(curioPeliActual); }
  else if (accion === "historia-otra") { if (curioPeliActual) generarHistoria(curioPeliActual); }
  else if (accion === "cerrar") hoja.classList.remove("abierta");
  else if (accion === "ver") {
    hoja.classList.remove("abierta");
    const h = historialCurio();
    const ult = h[h.length - 1];
    const p = peliculas.find(x => x.titulo === (ult && ult.titulo));
    if (p) abrirDetalle(p);
  }
  else if (accion === "copiar") {
    const h = historialCurio();
    const ult = h[h.length - 1];
    if (ult) navigator.clipboard.writeText(ult.titulo + ": " + ult.texto)
      .then(() => { b.textContent = "¡Copiado!"; setTimeout(() => { b.textContent = "Copiar"; }, 1500); })
      .catch(() => {});
  }
});

async function cargarCuriosidades() {
  try {
    if (!accessToken || !HOJA_ID) throw new Error("sin sesión");
    const r = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${HOJA_ID}/values/curiosidades!A:E`, {
      headers: { Authorization: "Bearer " + accessToken }
    });
    if (!r.ok) throw new Error("sin pestaña");
    const j = await r.json();
    curiosidadesTabla = (j.values || []).slice(1)
      .map(f => ({ tmdb: String(f[0] || "").trim(), titulo: String(f[1] || "").trim(), tema: String(f[2] || "").trim() || "Dato", texto: String(f[3] || "").trim(), fuente: String(f[4] || "").trim() }))
      .filter(c => c.texto && (c.tmdb || c.titulo));
    escribirLS(CURIOS_CACHE, JSON.stringify(curiosidadesTabla));
  } catch (e) {
    // Sin internet o sin la pestaña: usa la copia guardada (o solo los datos del catálogo)
    try { curiosidadesTabla = JSON.parse(leerLS(CURIOS_CACHE) || "[]") || []; } catch (x) { curiosidadesTabla = []; }
  }
  renderCuriosidadDia();
}

if (!document.getElementById("estiloCuriosidades")) {
  const st = document.createElement("style");
  st.id = "estiloCuriosidades";
  st.textContent = `
#curiosidades .curiosidad-dia{background:var(--tarjeta,rgba(255,255,255,.7));border-radius:18px;padding:18px 20px;box-shadow:0 6px 24px rgba(0,0,0,.08)}
#curiosidades .cur-tema{font-size:.78rem;letter-spacing:.04em;text-transform:uppercase;opacity:.7;margin-bottom:6px}
#curiosidades .cur-texto{font-size:1.08rem;line-height:1.5;margin:0 0 8px}
#curiosidades .cur-fuente{opacity:.6}
#curiosidades .cur-pie{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
.cur-lista{list-style:none;padding:0;margin:8px 0}
.cur-lista li{padding:8px 0;border-bottom:1px solid rgba(127,127,127,.2);line-height:1.45}
.cur-lista small{opacity:.6}
.cur-tema{font-weight:600;color:var(--azul,#0a84ff);margin-right:4px}
#curiosidadesTodas{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9000;display:flex;align-items:center;justify-content:center;padding:16px}
.cur-panel-caja{background:var(--fondo,#fff);color:inherit;max-width:560px;width:100%;max-height:86vh;overflow:auto;border-radius:18px;padding:18px}
.cur-panel-cab{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
.cur-panel-cab button{border:0;background:none;font-size:1.2rem;cursor:pointer;color:inherit}
.cur-temas{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px}
.cur-temas button{border:1px solid rgba(127,127,127,.4);background:none;border-radius:999px;padding:4px 12px;cursor:pointer;color:inherit}
.cur-temas button.activo{background:var(--azul,#0a84ff);color:#fff;border-color:transparent}
.cur-lista-todas li{cursor:pointer}
`;
  document.head.appendChild(st);
}

async function iniciarApp() {
  await cargarMarcas();
  await cargarHoja();
  cargarProximosCines();
  cargarCuriosidades();
}

window.addEventListener("load", () => {
  setInterval(actualizarCopiaEnSegundoPlano, 15 * 60 * 1000);
  window.addEventListener("online", () => {
    ocultarBannerOffline();
    setTimeout(actualizarCopiaEnSegundoPlano, 3000);
    // Intenta reconectar en silencio para subir los cambios pendientes
    if (!accessToken && tokenClient) {
      try { tokenClient.requestAccessToken({ prompt: "" }); } catch (e) {}
    }
  });
  window.addEventListener("offline", () => {
    if (accessToken && peliculas.length) mostrarBannerOffline(new Date().toISOString());
  });
  if (!navigator.onLine) {
    cargarDesdeCopia();
  }

  $("tema-modo").value = modoGuardado("tema_modo", "sistema");
  $("vista-modo").value = modoGuardado("vista_modo", "apagada");
  $("ahorro-modo").value = modoGuardado("ahorro_modo", "auto");
  actualizarTodo();
  actualizarAhorro();
  pedirUbicacion();
  setInterval(actualizarTodo, 60000);

  if (window.matchMedia) {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const alCambiar = () => actualizarTema();
    if (mq.addEventListener) mq.addEventListener("change", alCambiar);
    else if (mq.addListener) mq.addListener(alCambiar);

    const mqDatos = window.matchMedia("(prefers-reduced-data: reduce)");
    if (mqDatos.addEventListener) mqDatos.addEventListener("change", actualizarAhorro);
  }

  if (navigator.connection && navigator.connection.addEventListener) {
    navigator.connection.addEventListener("change", actualizarAhorro);
  }

  if (DOMINIO_INSTITUCIONAL) {
    $("avisoInstitucional").textContent = "Usa tu correo @" + DOMINIO_INSTITUCIONAL + ". Las cuentas personales no tienen acceso.";
  }

  tokenClient = google.accounts.oauth2.initTokenClient({
    client_id: CLIENT_ID,
    scope: SCOPES,
    hosted_domain: DOMINIO_INSTITUCIONAL || undefined,
    callback: async resp => {
      if (!resp.access_token) { mostrarError("No se pudo iniciar sesión."); return; }
      const token = resp.access_token;
      $("btnLogin").textContent = "Verificando tu cuenta…";
      if (!(await cuentaPermitida(token))) {
        try { google.accounts.oauth2.revoke(token, () => {}); } catch (e) {}
        accessToken = null;
        mostrarError("Esta app es solo para cuentas institucionales" + (DOMINIO_INSTITUCIONAL ? " (@" + DOMINIO_INSTITUCIONAL + ")" : "") + ". Vuelve a intentar con tu correo institucional.");
        return;
      }
      accessToken = token;
      iniciarApp();
    }
  });

  $("btnLogin").addEventListener("click", () => {
    $("btnLogin").disabled = true;
    $("btnLogin").textContent = "Cargando películas...";
    tokenClient.requestAccessToken();
  });

  $("toggleAvanzados").addEventListener("click", () => {
    if (pestana === "catalogo" && zonaPeli === "inicio") { zonaPeli = "lista"; aplicarEstadoTabs(); pintar(); }
    alternarPanel("panelAvanzados");
  });

  $("tema-modo").addEventListener("change", () => {
    try { localStorage.setItem("tema_modo", $("tema-modo").value); } catch (e) {}
    actualizarTema();
  });

  $("vista-modo").addEventListener("change", () => {
    try { localStorage.setItem("vista_modo", $("vista-modo").value); } catch (e) {}
    actualizarCalido();
  });

  $("ahorro-modo").addEventListener("change", () => {
    try { localStorage.setItem("ahorro_modo", $("ahorro-modo").value); } catch (e) {}
    ahorroActivo = null;
    actualizarAhorro();
  });

  // La búsqueda espera 120 ms a que dejes de escribir: un solo render en vez de uno por letra
  let pintarBusquedaTimer = null;
  buscar.addEventListener("input", () => {
    clearTimeout(pintarBusquedaTimer);
    pintarBusquedaTimer = setTimeout(pintar, 120);
  });
  [sel.tipo, sel.genero, sel.tema, sel.anio, sel.pais, sel.duracion, sel.estado, $("orden")]
    .forEach(el => el.addEventListener("input", pintar));
  buscar.addEventListener("input", () => {
    if (pestana === "catalogo" && zonaPeli === "inicio" && buscar.value.trim()) { zonaPeli = "lista"; aplicarEstadoTabs(); }
  });
  $("selectorZona").addEventListener("click", e => {
    const b = e.target.closest("[data-zona-op]");
    if (b) elegirZona(b.dataset.zonaOp);
  });

  document.querySelectorAll("#tabbar button[data-tab]").forEach(b => {
    b.addEventListener("click", () => cambiarPestana(b.dataset.tab));
  });
  const guardada = modoGuardado("pestana_activa", "inicio");
  if (["inicio", "catalogo", "notas", "pendientes", "vistas", "descartadas"].includes(guardada)) fijarTab(guardada);
  aplicarEstadoTabs();

  chips.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    const clave = chip.dataset.clave;
    if (clave === "buscar") buscar.value = "";
    else sel[clave].value = "";
    pintar();
  });

  // Un solo listener delegado para toda la lista: Descartadas primero, luego tarjetas
  lista.addEventListener("click", e => {
    if (suprimirClic) { suprimirClic = false; return; }
    if (e.target.id === "selTodasDesc") {
      document.querySelectorAll("[data-fila-desc]").forEach(fila => {
        if (fila.style.display === "none") return;
        const t = fila.dataset.filaDesc;
        seleccionDesc.add(t);
        const cb = fila.querySelector("[data-sel]");
        if (cb) cb.checked = true;
      });
      const btn = $("restaurarSelDesc");
      if (btn) {
        btn.textContent = "Restaurar seleccionadas (" + seleccionDesc.size + ")";
        btn.disabled = seleccionDesc.size === 0;
      }
      return;
    }
    if (e.target.id === "restaurarSelDesc") { restaurarTitulos([...seleccionDesc]); return; }
    if (e.target.id === "descartarBtnDesc") { descartarSeleccionadas(); return; }
    const una = e.target.closest("[data-restaurar-una]");
    if (una) { restaurarTitulos([una.dataset.restaurarUna]); return; }
    const rev = e.target.closest("[data-revision]");
    if (rev) { accionRevision(rev.dataset.revision, rev.dataset.clave); return; }

    // Clic en tarjetas (los controles interactivos no abren la ficha)
    if (e.target.closest("a, [data-accion], [data-tag], [data-sel], button, input")) return;
    const card = e.target.closest("[data-i]");
    if (card) {
      desdeAleatorio = false;
      origenPoster = card.querySelector("img.portada");
      abrirDetalle(visibles[Number(card.dataset.i)]);
    }
  });

  // Buscador de Descartadas: solo filtra las filas, así conserva el foco
  lista.addEventListener("input", e => {
    if (e.target.id === "buscarDesc") {
      buscar.value = e.target.value;
      filtrarFilasDescartadas();
    }
  });

  lista.addEventListener("change", e => {
    if (e.target.dataset && e.target.dataset.sel) {
      const t = e.target.dataset.sel;
      if (e.target.checked) seleccionDesc.add(t); else seleccionDesc.delete(t);
      const btn = $("restaurarSelDesc");
      if (btn) {
        btn.textContent = "Restaurar seleccionadas (" + seleccionDesc.size + ")";
        btn.disabled = seleccionDesc.size === 0;
      }
    }
  });

  $("sagas").addEventListener("click", e => {
    const d = e.target.closest("[data-idx]");
    if (d && peliculas[Number(d.dataset.idx)]) {
      desdeAleatorio = false;
      origenPoster = d.querySelector("img"); abrirDetalle(peliculas[Number(d.dataset.idx)]);
    }
  });

  $("carrusel").addEventListener("click", e => {
    const d = e.target.closest("[data-idx]");
    if (d) {
      desdeAleatorio = false;
      origenPoster = d.querySelector("img"); abrirDetalle(peliculas[Number(d.dataset.idx)]);
    }
  });

  // Carrusel de recomendaciones: el botón ¿Por qué? despliega o oculta el desglose; el resto abre la ficha
  $("recomCarrusel").addEventListener("click", e => {
    const pq = e.target.closest("[data-porque]");
    if (pq) {
      const titulo = peliculas[Number(pq.dataset.porque)].titulo;
      if (porQueAbiertos.has(titulo)) porQueAbiertos.delete(titulo);
      else porQueAbiertos.add(titulo);
      renderRecomendaciones();
      return;
    }
    const d = e.target.closest("[data-idx]");
    if (d) {
      desdeAleatorio = false;
      origenPoster = d.querySelector("img"); abrirDetalle(peliculas[Number(d.dataset.idx)]);
    }
  });

  document.addEventListener("click", e => {
    const etiqueta = e.target.closest("[data-tag]");
    if (etiqueta) {
      const tag = etiqueta.dataset.tag;
      if ($("modal").classList.contains("abierto")) cerrarDetalle();
      if (pestana !== "notas") cambiarPestana("notas");
      buscar.value = "#" + tag;
      pintar();
      return;
    }

    const abrir = e.target.closest("[data-decidir-abrir]");
    if (abrir) { decidiendo = abrir.dataset.decidirAbrir; renderAvisoEstancados(); return; }
    const decision = e.target.closest("[data-decidir]");
    if (decision) { accionDecidir(decision.dataset.decidir, decision.dataset.clave); return; }

    if (e.target.id === "avisoFechaCerrar") { cerrarRecordatorio(); return; }
    const tabVer = e.target.closest("[data-ver]");
    if (tabVer) { verActual = tabVer.dataset.ver; ajustarQueVer(); return; }
    if (e.target.id === "preguntaGuardar") { guardarRespuestaDia(e.target.dataset.titulo); return; }
    if (e.target.id === "preguntaOmitir") { omitirPreguntaHoy(); return; }
    if (e.target.id === "avisoCerrar") {
      avisoCerrado = true;
      firmaAvisoCerrado = listaEstancadas().map(x => x.p.titulo + x.tipo).join("|");
      $("avisoEstancados").style.display = "none";
      return;
    }
    if (e.target.id === "avisoDeshacerBtn") { deshacerUltimoDescarte(); return; }

    if (e.target.id === "cerrarResumen") { cerrarResumenSemana(); return; }
    if (e.target.id === "resumenVer") {
      const p = peliculas.find(x => x.titulo === e.target.dataset.titulo);
      if (p) { desdeAleatorio = false; abrirDetalle(p); }
      return;
    }
    if (e.target.id === "btnBorrarNota") { borrarNota(); return; }
    if (e.target.id === "otraSugerencia") { sugerirAleatoria(); return; }
    if (e.target.id === "btnCompartir") {
      if (detalleActual) compartirPelicula(detalleActual);
      return;
    }
    if (e.target.id === "btnEnlace") { copiarEnlace(); return; }
    if (e.target.id === "btnCompartirRec") { compartirRecomendacion(); return; }
    if (e.target.id === "btnCena" || e.target.id === "cenaOtra") { elegirCena(e.target.id === "cenaOtra"); return; }
    if (e.target.id === "calPrev" || e.target.id === "calNext") {
      mesCalendario = desplazarMes(mesCalendario || hoyLocalISO().slice(0, 7), e.target.id === "calNext" ? 1 : -1);
      pintar();
      return;
    }
    const botonActor = e.target.closest("[data-actor]");
    if (botonActor) { cerrarDetalle(); abrirActor(botonActor.dataset.actor); return; }
    const filaActor = e.target.closest("[data-actor-titulo]");
    if (filaActor) {
      const p = peliculas.find(x => x.titulo === filaActor.dataset.actorTitulo);
      cerrarActor();
      if (p) { desdeAleatorio = false; abrirDetalle(p); }
      return;
    }
    const elegidaDuelo = e.target.closest("[data-duelo-elige]");
    if (elegidaDuelo) { elegirEnDuelo(elegidaDuelo.dataset.dueloElige); return; }
    if (e.target.closest("[data-duelo-otro]")) { parDuelo = null; renderDuelo(); return; }
    const botonSaga = e.target.closest("[data-saga-pend]");
    if (botonSaga) { marcarSagaPendiente(botonSaga.dataset.sagaPend); return; }
    const botonSiguiente = e.target.closest("[data-siguiente]");
    if (botonSiguiente) {
      const p = peliculas.find(x => x.titulo === botonSiguiente.dataset.siguiente);
      if (p) { desdeAleatorio = false; abrirDetalle(p); }
      return;
    }
    if (e.target.id === "cenaVer") {
      const p = peliculas.find(x => x.titulo === e.target.dataset.titulo);
      if (p) { desdeAleatorio = false; abrirDetalle(p); }
      return;
    }

    if (e.target.id === "ahoraVer") {
      if (sugeridaActual) { desdeAleatorio = false; abrirDetalle(sugeridaActual); }
      return;
    }
    if (e.target.id === "ahoraOtra") { nuevaSugerencia(sugeridaActual); return; }

    const cargar = e.target.closest("[data-cargar-trailer]");
    if (cargar) {
      const caja = cargar.closest(".trailer-caja");
      const titulo = $("detalle").querySelector("h2")?.textContent || "";
      if (caja) caja.innerHTML = iframeTrailer(cargar.dataset.cargarTrailer, titulo);
      return;
    }

    const idioma = e.target.closest("[data-trailer]");
    if (idioma) {
      const caja = $("trailerCaja");
      const titulo = $("detalle").querySelector("h2")?.textContent || "";
      caja.innerHTML = contenidoTrailer(idioma.dataset.codigo, titulo);
      document.querySelectorAll("[data-trailer]").forEach(b => b.classList.toggle("activo", b === idioma));
      return;
    }

    const b = e.target.closest("[data-accion]");
    if (!b) return;
    e.preventDefault();
    e.stopPropagation();

    const titulo = b.dataset.clave;
    const p = peliculas.find(x => x.titulo === titulo);
    if (!p) return;
    const s = estadoDe(p);

    if (b.dataset.accion === "vista") {
      cambiarEstado(titulo, { vista: !s.vista, pendiente: false, vistaDesde: !s.vista ? new Date().toISOString().slice(0, 10) : undefined });
    } else if (b.dataset.accion === "pendiente") {
      cambiarEstado(titulo, { pendiente: !s.pendiente, vista: false });
    } else if (b.dataset.accion === "conAlguien") {
      alternarConAlguien(titulo);
    } else if (b.dataset.accion === "conFecha") {
      cambiarFechaConAlguien(titulo);
    } else if (b.dataset.accion === "restaurar") {
      cambiarEstado(titulo, { descartada: false });
    } else if (b.dataset.accion === "estrella") {
      const n = Number(b.dataset.n);
      cambiarEstado(titulo, { estrellas: s.estrellas === n ? 0 : n });
    }
    refrescarTodo();
  });

  $("aleatorio").addEventListener("click", sugerirAleatoria);
  $("queVerNoche").addEventListener("click", abrirQueVerEstaNoche);
  $("estadisticas").addEventListener("click", abrirEstadisticas);
  $("guardarPaletas").addEventListener("click", guardarPaletasEnHoja);
  $("deshacer").addEventListener("click", deshacerUltimo);
  $("atajos").addEventListener("click", toggleAyudaAtajos);
  $("capsula").addEventListener("click", abrirCapsulaAno);
  $("parejaBtn").addEventListener("click", alternarModoPareja);
  $("diario").addEventListener("click", abrirDiario);
  $("nocheTema").addEventListener("click", nocheTematica);
  $("maraton").addEventListener("click", abrirMaraton);
  $("sorpresa").addEventListener("click", abrirSorpresa);
  $("votarPareja").addEventListener("click", abrirVotacionPareja);
  $("animoBtn").addEventListener("click", abrirAnimo);
  $("mapaViaje").addEventListener("click", abrirMapaViaje);
  $("buzon").addEventListener("click", abrirBuzon);
  $("prepararViaje").addEventListener("click", prepararViaje);
  $("verViaje").addEventListener("click", abrirModoViaje);
  if (modoPareja()) { $("parejaBtn").textContent = "💑 Modo pareja: activo"; $("parejaBtn").classList.add("destacado"); }
  $("cerrarStats").addEventListener("click", cerrarEstadisticas);
  $("statsModal").addEventListener("click", e => { if (e.target.id === "statsModal") cerrarEstadisticas(); });

  $("cerrarModal").addEventListener("click", cerrarDetalle);
  $("modal").addEventListener("click", e => { if (e.target.id === "modal") cerrarDetalle(); });

  $("vista").addEventListener("click", () => {
    vistaLista = !vistaLista;
    document.body.classList.toggle("lista", vistaLista);
    $("vista").textContent = vistaLista ? "Vista amplia" : "Vista compacta";
    try { localStorage.setItem("vista_tarjetas", vistaLista ? "compacta" : "amplia"); } catch (e) {}
    pintar();
  });

  function alternarAgrupado() {
    agrupado = !agrupado;
    const txt = agrupado ? "Quitar agrupación" : "Agrupar por tema";
    $("agrupar").textContent = txt;
    $("agruparNotas").textContent = txt;
    pintar();
  }
  $("agrupar").addEventListener("click", alternarAgrupado);
  $("agruparNotas").addEventListener("click", alternarAgrupado);
  $("ordenNotas").addEventListener("change", () => pintar());
  $("personaVistas").addEventListener("change", () => pintar());
  $("presetGuardar").addEventListener("click", guardarPreset);
  $("presetBorrar").addEventListener("click", borrarPreset);
  $("presetsSel").addEventListener("change", aplicarPreset);
  renderPresets();
  $("cerrarActor").addEventListener("click", cerrarActor);
  $("actorModal").addEventListener("click", e => { if (e.target.id === "actorModal") cerrarActor(); });

  $("limpiar").addEventListener("click", () => {
    buscar.value = "";
    Object.values(sel).forEach(s => s.value = "");
    $("orden").value = "titulo";
    pintar();
  });

  $("clasificar").addEventListener("click", abrirClasificador);
  $("clasCerrar").addEventListener("click", cerrarClasificador);
  $("clasIzq").addEventListener("click", () => clasAccion("izq"));
  $("clasDer").addEventListener("click", () => clasAccion("der"));
  $("clasDeshacer").addEventListener("click", clasDeshacer);

  $("toggleSalud").addEventListener("click", () => {
    const oculta = modoGuardado("salud_oculta", "1") === "1";
    try { localStorage.setItem("salud_oculta", oculta ? "0" : "1"); } catch (e) {}
    actualizarBotonSalud();
  });

  $("respaldarMarcas").addEventListener("click", respaldarMarcas);
  $("restaurarMarcas").addEventListener("click", () => $("archivoRestaurar").click());
  $("archivoRestaurar").addEventListener("change", e => {
    const archivo = e.target.files && e.target.files[0];
    e.target.value = "";
    if (archivo) restaurarMarcasDesdeArchivo(archivo);
  });
});

async function borrarMisMarcas() {
  const ok = confirm("¿Borrar todas tus marcas (vistas, pendientes, estrellas, notas, «con alguien» y descartadas)? Esta acción no se puede deshacer.");
  if (!ok) return;
  if (!confirm("Última confirmación: se borrarán todas tus marcas y sus respaldos semanales de Drive, y no se pueden recuperar. ¿Seguro?")) return;
  clearTimeout(guardadoTimer);
  try {
    await syncBorrarTodoDrive();
  } catch (e) {
    setEstado("No pude borrar tus marcas de Drive. Intenta de nuevo.");
    return;
  }
  idMarcas = null;
  marcas = envolverMarcas({});
  seleccionDesc.clear();
  porQueAbiertos.clear();
  syncBorrarLocal();
  refrescarTodo();
  setEstado("Tus marcas se borraron de Drive y de este navegador.");
}

$("borrarMarcas").addEventListener("click", borrarMisMarcas);

function exportarCSV() {
  const columnas = ["titulo", "tipo", "año", "duracion", "pais", "director", "genero", "reparto", "temas", "link", "vista", "pendiente", "estrellas", "nota", "conAlguien", "conQuien", "conFecha"];

  const esc = v => {
    const s = String(v == null ? "" : v);
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };

  const filas = [columnas.join(",")];
  peliculas.forEach(p => {
    const s = estadoDe(p);
    const m = marcas[p.titulo] || {};
    const valores = columnas.map(c => {
      if (c === "vista") return s.vista ? "sí" : "no";
      if (c === "pendiente") return s.pendiente ? "sí" : "no";
      if (c === "estrellas") return s.estrellas || "";
      if (c === "nota") return m.nota || "";
      if (c === "conAlguien") return s.conAlguien ? "sí" : "no";
      if (c === "conQuien") return m.conQuien || "";
      if (c === "conFecha") return m.conFecha || "";
      return p[c] ?? "";
    });
    filas.push(valores.map(esc).join(","));
  });

  const blob = new Blob(["\uFEFF" + filas.join("\r\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "mi_catalogo_" + new Date().toISOString().slice(0, 10) + ".csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  setEstado("CSV exportado: " + peliculas.length + " títulos.");
}

$("exportar").addEventListener("click", exportarCSV);

let swipe = null;

// Gesto a la izquierda: marca como vista. Nunca desmarca; se puede deshacer con el aviso.
function marcarVistaGesto(p) {
  if (estadoDe(p).vista) {
    setEstado("Ya está en tus vistas.");
    refrescarTodo();
    return;
  }
  const previo = marcas[p.titulo] ? Object.assign({}, marcas[p.titulo]) : null;
  cambiarEstado(p.titulo, { vista: true, pendiente: false, vistaDesde: hoyLocalISO() });
  mostrarDeshacer("«" + p.titulo + "» marcada como vista.", [{ titulo: p.titulo, previo }]);
  refrescarTodo();
}

function reiniciarTarjeta(el) {
  if (!el) return;
  el.style.transition = "transform .25s var(--ease)";
  el.style.transform = "";
}

lista.addEventListener("touchstart", e => {
  const card = e.target.closest("[data-i]");
  if (!card || e.target.closest("a, button, select, input")) { swipe = null; return; }
  const t = e.touches[0];
  swipe = { el: card, i: Number(card.dataset.i), x: t.clientX, y: t.clientY, dx: 0, activo: false, lp: false, timer: null };
  swipe.timer = setTimeout(() => {
    if (!swipe) return;
    swipe.lp = true;
    abrirRapida(card);
  }, 500);
}, { passive: true });

lista.addEventListener("touchmove", e => {
  if (!swipe) return;
  const t = e.touches[0];
  const dx = t.clientX - swipe.x;
  const dy = t.clientY - swipe.y;
  if (Math.abs(dx) > 12 || Math.abs(dy) > 12) clearTimeout(swipe.timer);
  if (swipe.lp) return;
  if (!swipe.activo) {
    if (Math.abs(dy) > Math.abs(dx)) { reiniciarTarjeta(swipe.el); swipe = null; return; }
    if (Math.abs(dx) < 12) return;
    swipe.activo = true;
  }
  swipe.dx = dx;
  swipe.el.style.transition = "none";
  swipe.el.style.transform = "translateX(" + Math.max(-120, Math.min(120, dx)) + "px)";
  swipe.el.dataset.swipe = dx <= -30 ? "vista" : (dx >= 30 ? "pendiente" : "");
}, { passive: true });

lista.addEventListener("touchend", () => {
  if (!swipe) return;
  const s = swipe;
  swipe = null;
  reiniciarTarjeta(s.el);
  delete s.el.dataset.swipe;
  clearTimeout(s.timer);
  if (s.lp) {
    suprimirClic = true;
    setTimeout(() => { suprimirClic = false; }, 400);
    return;
  }
  if (!s.activo) return;
  const p = visibles[s.i];
  if (!p) return;
  if (s.dx <= -90) { marcarVistaGesto(p); return; }
  if (s.dx >= 90) {
    const pendienteActual = estadoDe(p).pendiente;
    const previo = marcas[p.titulo] ? Object.assign({}, marcas[p.titulo]) : null;
    cambiarEstado(p.titulo, { pendiente: !pendienteActual, vista: false });
    mostrarDeshacer(pendienteActual
      ? "«" + p.titulo + "» quitada de pendientes."
      : "«" + p.titulo + "» puesta en pendientes.", [{ titulo: p.titulo, previo }]);
    refrescarTodo();
  }
});

lista.addEventListener("touchcancel", () => {
  if (swipe) { clearTimeout(swipe.timer); reiniciarTarjeta(swipe.el); delete swipe.el.dataset.swipe; }
  swipe = null;
});

const zonaClas = $("clasZona");

zonaClas.addEventListener("touchstart", e => {
  if (!clasActual()) return;
  cls.x = e.touches[0].clientX;
  cls.dx = 0;
  cls.activo = true;
  const card = $("clasCard");
  if (card) card.style.transition = "none";
}, { passive: true });

zonaClas.addEventListener("touchmove", e => {
  if (!cls.activo) return;
  const card = $("clasCard");
  if (!card) return;
  cls.dx = e.touches[0].clientX - cls.x;
  card.style.transform = "translateX(" + cls.dx + "px) rotate(" + (cls.dx / 25) + "deg)";
  moverSellos(cls.dx);
}, { passive: true });

zonaClas.addEventListener("touchend", () => {
  if (!cls.activo) return;
  cls.activo = false;
  const card = $("clasCard");
  if (!card) return;
  const dx = cls.dx;
  cls.dx = 0;
  if (Math.abs(dx) >= 110) {
    const dir = dx > 0 ? "der" : "izq";
    const salida = dx > 0 ? window.innerWidth : -window.innerWidth;
    card.style.transition = "transform .25s ease";
    card.style.transform = "translateX(" + salida + "px) rotate(" + (dx > 0 ? 20 : -20) + "deg)";
    setTimeout(() => clasAccion(dir), 220);
  } else {
    card.style.transition = "transform .25s var(--ease)";
    card.style.transform = "";
    moverSellos(0);
  }
});

zonaClas.addEventListener("touchcancel", () => {
  cls.activo = false;
  cls.dx = 0;
  const card = $("clasCard");
  if (card) { card.style.transition = "transform .25s var(--ease)"; card.style.transform = ""; }
  moverSellos(0);
});

/* --- bloque 2 --- */
(function () {
  const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
  const btn = document.getElementById("voz");
  const buscarEl = document.getElementById("buscar");
  if (!Rec || !btn) return;

  btn.hidden = false;
  const rec = new Rec();
  rec.lang = "es-MX";
  rec.interimResults = true;
  rec.continuous = false;
  rec.maxAlternatives = 1;
  let escuchando = false;

  function mensaje(texto) {
    const el = document.getElementById("estadoGuardado");
    if (el) el.textContent = texto;
  }
  function parar() {
    escuchando = false;
    btn.classList.remove("escuchando");
  }

  rec.onresult = e => {
    let texto = "";
    for (let i = e.resultIndex; i < e.results.length; i++) {
      texto += e.results[i][0].transcript;
    }
    buscarEl.value = texto.replace(/[.,;:!?¿¡]+/g, " ").replace(/\s+/g, " ").trim();
    buscarEl.dispatchEvent(new Event("input"));
  };

  rec.onerror = e => {
    parar();
    mensaje(e.error === "not-allowed"
      ? "Permite el uso del micrófono en el navegador para buscar por voz."
      : "No entendí, intenta de nuevo.");
  };

  rec.onend = parar;

  btn.addEventListener("click", () => {
    if (escuchando) {
      rec.stop();
      parar();
      return;
    }
    try {
      rec.start();
      escuchando = true;
      btn.classList.add("escuchando");
      mensaje("Escuchando... di un título, director o actor.");
    } catch (e) {
      mensaje("No pude iniciar el micrófono. Intenta de nuevo.");
    }
  });
})();

/* --- bloque 3 --- */
(function () {
  const header = document.querySelector("#app > header");
  const rango = document.getElementById("vidrioAlfa");
  const valor = document.getElementById("vidrioAlfaValor");
  if (!header || !rango || !valor) return;

  function aplicarVidrio(v) {
    const n = Math.min(95, Math.max(40, Math.round(Number(v)) || 72));
    document.documentElement.style.setProperty("--opacidad", (n / 100).toFixed(2));
    document.documentElement.style.setProperty("--desenfoque", Math.round(n * 0.3) + "px");
    rango.value = n;
    valor.textContent = n;
    return n;
  }
  aplicarVidrio(modoGuardado("vidrio_alfa", "72"));

  rango.addEventListener("input", () => {
    const n = aplicarVidrio(rango.value);
    try { localStorage.setItem("vidrio_alfa", String(n)); } catch (e) {}
  });


  // Reglas:
  // - Se compacta solo al bajar, pasando 180 px (así siempre hay espacio para compensar el salto).
  // - Se expande solo al llegar arriba (y <= 20). Nunca mientras se sube, para no pelear con el scroll.
  // - La compensación del scroll solo se aplica al compactar, que es cuando el contenido sube.
  const UMBRAL_COMPACTA = 180;
  let compacta = false, ultimoY = window.scrollY, ignorarHasta = 0, pendiente = false;

  function cambiarEstado(v, y) {
    if (compacta === v) return;
    compacta = v;
    const antes = header.offsetHeight;
    document.body.classList.toggle("barra-compacta", v);
    const despues = header.offsetHeight;
    if (v && y > 0 && despues !== antes) {
      ignorarHasta = performance.now() + 200;
      window.scrollBy(0, despues - antes);
    }
  }

  function alDesplazar() {
    if (pendiente) return;
    pendiente = true;
    requestAnimationFrame(() => {
      pendiente = false;
      if (performance.now() < ignorarHasta) return;
      const y = window.scrollY;
      if (!compacta) {
        if (y > UMBRAL_COMPACTA && y > ultimoY) cambiarEstado(true, y);
      } else if (y <= 20) {
        cambiarEstado(false, y);
      }
      ultimoY = y;
    });
  }

  window.addEventListener("scroll", alDesplazar, { passive: true });
})();

/* --- bloque 4 --- */
(function () {
  const modal = document.getElementById("modal");
  const ventana = modal.querySelector(".ventana");

  const tirador = document.createElement("div");
  tirador.className = "hoja-tirador";
  tirador.setAttribute("aria-hidden", "true");
  ventana.insertBefore(tirador, ventana.firstChild);

  // Escape cierra la ficha
  document.addEventListener("keydown", e => {
    if (e.key === "Escape" && modal.classList.contains("abierto")) cerrarDetalle();
  });

  // Deslizar hacia abajo cierra la hoja (solo cuando el contenido está arriba del todo)
  let inicio = null, dy = 0, arrastrando = false;

  function reiniciar() {
    inicio = null;
    arrastrando = false;
    dy = 0;
  }

  ventana.addEventListener("touchstart", e => {
    if (ventana.scrollTop > 0 || e.target.closest("textarea, input, select, iframe")) { reiniciar(); return; }
    inicio = e.touches[0].clientY;
    arrastrando = false;
    dy = 0;
  }, { passive: true });

  ventana.addEventListener("touchmove", e => {
    if (inicio === null) return;
    const d = e.touches[0].clientY - inicio;
    if (!arrastrando) {
      if (d < 8) return;
      arrastrando = true;
      ventana.style.transition = "none";
    }
    if (e.cancelable) e.preventDefault();
    dy = Math.max(0, d);
    ventana.style.transform = "translateY(" + (dy * 0.9) + "px)";
  }, { passive: false });

  ventana.addEventListener("touchend", () => {
    if (inicio === null) return;
    const cerrar = arrastrando && dy > 110;
    const estabaArrastrando = arrastrando;
    reiniciar();
    if (!estabaArrastrando) return;
    ventana.style.transition = "transform .3s var(--ease)";
    if (cerrar) {
      ventana.style.transform = "translateY(100%)";
      setTimeout(() => {
        cerrarDetalle();
        ventana.style.transform = "";
        ventana.style.transition = "";
      }, 260);
    } else {
      ventana.style.transform = "";
    }
  });

  ventana.addEventListener("touchcancel", () => {
    reiniciar();
    ventana.style.transition = "transform .3s var(--ease)";
    ventana.style.transform = "";
  });
})();

/* --- bloque 5 --- */
(function () {
  const estado = document.getElementById("estado");
  const botones = document.querySelectorAll(".segmentado button");
  if (!estado || !botones.length) return;

  function sincronizar() {
    botones.forEach(b => {
      const activa = b.dataset.seg === estado.value;
      b.classList.toggle("activa", activa);
      b.setAttribute("aria-pressed", activa ? "true" : "false");
    });
  }

  botones.forEach(b => {
    b.addEventListener("click", () => {
      estado.value = b.dataset.seg;
      estado.dispatchEvent(new Event("input"));
      sincronizar();
    });
  });

  // Mantiene el selector sincronizado con los demás controles (panel, chips, Limpiar)
  estado.addEventListener("input", sincronizar);
  document.addEventListener("click", () => setTimeout(sincronizar, 0));
  sincronizar();

  // Aviso «Deshacer» para Vista y Pendiente desde los botones de la tarjeta o la ficha
  let snap = null;
  document.addEventListener("click", e => {
    const b = e.target.closest('[data-accion="pendiente"], [data-accion="vista"]');
    if (!b) { snap = null; return; }
    const t = b.dataset.clave;
    snap = {
      titulo: t,
      tipo: b.dataset.accion,
      previo: marcas[t] ? Object.assign({}, marcas[t]) : null
    };
  }, true);

  document.addEventListener("click", () => {
    if (!snap) return;
    const s = snap;
    snap = null;
    const antes = JSON.stringify(s.previo);
    const despues = JSON.stringify(marcas[s.titulo] || null);
    if (antes === despues) return;
    const etiqueta = s.tipo === "vista" ? "marcada como vista" : "puesta en pendientes";
    mostrarDeshacer("«" + s.titulo + "» " + etiqueta + ".", [{ titulo: s.titulo, previo: s.previo }]);
  });
})();

/* --- bloque 6 --- */
(function () {
  const LOTE = 24;
  const lista = document.getElementById("lista");

  let cola = [];          // HTML de las tarjetas aún no cargadas, en orden
  let mostradas = LOTE;   // cuántas tarjetas reales hay en pantalla
  let firmaAnterior = "";

  const observerMut = new MutationObserver(() => preparar());
  const observerLote = new IntersectionObserver(entradas => {
    if (entradas.some(e => e.isIntersecting)) cargarSiguiente(false);
  }, { rootMargin: "400px 0px" });

  function pausar() { observerMut.disconnect(); }
  function reanudar() { observerMut.observe(lista, { childList: true }); }

  function quitarSentinela() {
    observerLote.disconnect();
    const s = document.getElementById("sentinelaLote");
    if (s) s.remove();
  }

  function terminar() {
    quitarSentinela();
    cola = [];
  }

  // Cambia la firma cuando cambia la búsqueda, los filtros, el orden o la pestaña.
  // Si solo cambia una marca, se conserva cuántas tarjetas ya estaban cargadas.
  function firma() {
    return [buscar.value, ...Object.values(sel).map(s => s.value), $("orden").value, pestana, agrupado].join("|");
  }

  function actualizarBoton() {
    const b = document.getElementById("cargarTodas");
    const quedan = lista.querySelectorAll(".esqueleto").length;
    if (b) b.textContent = "Cargar las " + quedan + " restantes";
  }

  function preparar() {
    pausar();
    if (pestana !== "catalogo" || agrupado) { terminar(); reanudar(); return; }

    const hijos = [...lista.children].filter(el => el.hasAttribute("data-i"));
    const f = firma();
    if (f !== firmaAnterior) { mostradas = LOTE; firmaAnterior = f; }

    if (hijos.length <= mostradas) { terminar(); reanudar(); return; }

    const resto = hijos.slice(mostradas);
    cola = resto.map(el => el.outerHTML);
    resto.forEach((el, k) => {
      const s = document.createElement("div");
      s.className = "esqueleto";
      s.dataset.n = String(k);
      s.setAttribute("aria-hidden", "true");
      el.replaceWith(s);
    });

    quitarSentinela();
    const sent = document.createElement("div");
    sent.id = "sentinelaLote";
    sent.className = "lote-sentinela";
    sent.innerHTML = '<button type="button" class="pildora" id="cargarTodas"></button>';
    lista.appendChild(sent);
    actualizarBoton();
    reanudar();
    observerLote.observe(sent);
  }

  function cargarSiguiente(todas) {
    const sk = [...lista.querySelectorAll(".esqueleto")];
    if (!sk.length) { terminar(); return; }

    pausar();
    const grupo = todas ? sk : sk.slice(0, LOTE);
    grupo.forEach(s => {
      const k = Number(s.dataset.n);
      const plantilla = document.createElement("template");
      plantilla.innerHTML = cola[k];
      const tarjeta = plantilla.content.firstElementChild;
      if (tarjeta) s.replaceWith(tarjeta); else s.remove();
    });
    mostradas += grupo.length;

    if (!lista.querySelector(".esqueleto")) { terminar(); reanudar(); return; }

    actualizarBoton();
    reanudar();
    const sent = document.getElementById("sentinelaLote");
    if (sent) { observerLote.unobserve(sent); observerLote.observe(sent); }
  }

  // Botón de respaldo: carga todas las restantes de una vez
  document.addEventListener("click", e => {
    if (e.target.closest && e.target.closest("#cargarTodas")) cargarSiguiente(true);
  });

  reanudar();
})();

/* --- bloque 7 --- */
(function () {
  // 1. Tarjetas y carrusel accesibles con teclado
  function hacerEnfocables(raiz) {
    raiz.querySelectorAll("[data-i]:not([tabindex]), [data-idx]:not([tabindex])").forEach(el => {
      el.setAttribute("tabindex", "0");
      el.setAttribute("role", "button");
      if (!el.getAttribute("aria-label")) {
        const t = el.querySelector("h2, .dest-titulo");
        if (t) el.setAttribute("aria-label", t.textContent.trim());
      }
    });
  }
  hacerEnfocables(document);
  const obsEnfocables = new MutationObserver(() => hacerEnfocables(document));
  obsEnfocables.observe(document.getElementById("app"), { childList: true, subtree: true });

  // Enter o Espacio abren la ficha cuando la tarjeta misma tiene el foco
  document.addEventListener("keydown", e => {
    if (e.key !== "Enter" && e.key !== " ") return;
    const t = e.target;
    if (!t.matches || !t.matches("[data-i][tabindex], [data-idx][tabindex]")) return;
    e.preventDefault();
    t.click();
  });

  // 2. Foco al abrir la ficha y regreso al elemento anterior al cerrar
  const modal = document.getElementById("modal");
  let elementoPrevio = null;
  new MutationObserver(() => {
    if (modal.classList.contains("abierto")) {
      if (!elementoPrevio) {
        elementoPrevio = document.activeElement;
        const cerrar = document.getElementById("cerrarModal");
        if (cerrar) cerrar.focus({ preventScroll: true });
      }
    } else if (elementoPrevio) {
      const previo = elementoPrevio;
      elementoPrevio = null;
      if (previo && previo.isConnected && previo.focus) previo.focus({ preventScroll: true });
    }
  }).observe(modal, { attributes: true, attributeFilter: ["class"] });

  // 3. Foco visible en controles del encabezado y barra inferior (ya cubierto por CSS global; aquí se asegura el aria-pressed del segmentado)
  document.querySelectorAll("#tabbar button").forEach(b => {
    b.setAttribute("aria-label", b.textContent.trim());
    b.setAttribute("aria-current", b.classList.contains("activa") ? "page" : "false");
  });
  new MutationObserver(() => {
    document.querySelectorAll("#tabbar button").forEach(b => {
      b.setAttribute("aria-current", b.classList.contains("activa") ? "page" : "false");
    });
  }).observe(document.getElementById("tabbar"), { attributes: true, subtree: true, attributeFilter: ["class"] });
})();

/* --- bloque 8 --- */
(function () {
  // Tarjeta de sugerencia: tocarla abre la ficha
  document.addEventListener("click", e => {
    const card = e.target.closest("#ahoraCaja .ahora-card");
    if (!card || e.target.closest("button")) return;
    const b = document.getElementById("ahoraVer");
    if (b) b.click();
  });

  // Descartadas ahora está en el menú ⋯
  document.addEventListener("click", e => {
    if (!e.target.closest || !e.target.closest("#verDescartadas")) return;
    cerrarPaneles();
    cambiarPestana("descartadas");
  });

  // Si la última pestaña guardada era Descartadas, vuelve al catálogo
  window.addEventListener("load", () => {
    if (pestana === "descartadas") cambiarPestana("catalogo");
  });
})();

/* --- bloque 9 --- */
(function () {
  // El título de la sugerencia cambia según la hora del día
  function tituloSegunHora() {
    const h = new Date().getHours();
    const t = h >= 19 || h < 5 ? "Para esta noche" : h < 12 ? "Para esta mañana" : "Para esta tarde";
    const el = document.getElementById("tituloAhora");
    if (el && el.textContent !== t) el.textContent = t;
  }
  tituloSegunHora();
  setInterval(tituloSegunHora, 60000);
})();

/* --- bloque 10 --- */
(function () {
  // ---------- Estado visible de la copia en Drive ----------
  function textoEstadoRespaldo() {
    let fecha = null, lunes = null;
    try { fecha = localStorage.getItem("respaldo_drive_fecha"); lunes = localStorage.getItem("respaldo_semana"); } catch (e) {}
    if (!fecha && !lunes) return { texto: "Aún no hay copia en tu Drive. Se crea sola cuando tengas marcas.", alerta: true };
    if (!fecha) return { texto: "Copia semanal activa (semana del " + lunes + "). Se conservan las últimas 4.", alerta: false };
    const d = new Date(fecha);
    const dias = Math.floor((Date.now() - d.getTime()) / 86400000);
    const cuando = dias <= 0 ? "hoy" : dias === 1 ? "ayer" : "hace " + dias + " días";
    const dia = d.toLocaleDateString("es-MX", { day: "numeric", month: "long" });
    return {
      texto: "Última copia en tu Drive: " + cuando + " (" + dia + "). Se conservan las últimas 4." + (dias > 8 ? " Hace más de una semana; revisa tu conexión." : ""),
      alerta: dias > 8
    };
  }

  function mostrarEstadoRespaldo() {
    const el = document.getElementById("estadoRespaldo");
    if (!el) return;
    const r = textoEstadoRespaldo();
    el.textContent = r.texto;
    el.classList.toggle("alerta-respaldo", r.alerta);
  }

  // ---------- 2. Respaldo semanal de marcas en tu Drive (se conservan 4) ----------
  async function respaldoSemanal() {
    if (!accessToken || !idMarcas || !Object.keys(marcas).length) return;
    const lunes = inicioSemanaISO(hoyLocalISO());
    if (modoGuardado("respaldo_semana", "") === lunes) return;
    try {
      const nombre = "respaldo-marcas-" + lunes + ".json";
      const frontera = "respaldo_frontera";
      const meta = JSON.stringify({ name: nombre, parents: ["appDataFolder"] });
      const cuerpo = JSON.stringify(marcas);
      const partes = "--" + frontera + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + meta +
        "\r\n--" + frontera + "\r\nContent-Type: application/json\r\n\r\n" + cuerpo + "\r\n--" + frontera + "--";
      await driveFetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", {
        method: "POST",
        headers: { "Content-Type": "multipart/related; boundary=" + frontera },
        body: partes
      });
      const q = encodeURIComponent("name contains 'respaldo-marcas-'");
      const orden = encodeURIComponent("name desc");
      const r = await driveFetch("https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=" + q + "&orderBy=" + orden + "&fields=files(id,name)");
      const j = await r.json();
      for (const f of (j.files || []).slice(4)) {
        await driveFetch("https://www.googleapis.com/drive/v3/files/" + f.id, { method: "DELETE" });
      }
      try { localStorage.setItem("respaldo_semana", lunes); localStorage.setItem("respaldo_drive_fecha", new Date().toISOString()); } catch (e) {}
      mostrarEstadoRespaldo();
    } catch (e) {}
  }

  // ---------- 3. Limpieza de avisos y datos viejos (cada minuto) ----------
  function mantener() {
    const hoy = hoyLocalISO();
    guardarJSON("recordatorio_cerrados", leerJSON("recordatorio_cerrados", []).filter(k => k.endsWith("|" + hoy)));
    if (!peliculas.length || pestana !== "catalogo") return;
    renderAvisoEstancados();
    actualizarAvisoFecha();
  }

  // ---------- 4. Recordar dónde te quedaste ----------
  const CLAVE_SESION = "ultima_sesion";
  const CAMPOS = ["estado", "tipo", "genero", "tema", "anio", "pais", "duracion"];

  function guardarSesion() {
    if (!peliculas.length) return;
    const datos = { y: window.scrollY, buscar: buscar.value, orden: $("orden").value };
    CAMPOS.forEach(k => { datos[k] = sel[k].value; });
    guardarJSON(CLAVE_SESION, datos);
  }
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") guardarSesion(); });
  window.addEventListener("pagehide", guardarSesion);

  function restaurarSesion() {
    if (new URLSearchParams(location.search).get("id")) return;
    const s = leerJSON(CLAVE_SESION, null);
    if (!s) return;
    buscar.value = s.buscar || "";
    $("orden").value = s.orden || "titulo";
    CAMPOS.forEach(k => { sel[k].value = s[k] || ""; });
    // Con filtros activos, la portada se oculta: muestra la lista para que se vean los resultados
    if (hayFiltros()) { zonaPeli = "lista"; aplicarEstadoTabs(); }
    sel.estado.dispatchEvent(new Event("input"));
    // Siempre se empieza arriba, en el menú principal
    requestAnimationFrame(() => window.scrollTo(0, 0));
  }

  // Cuando la hoja ya cargó: restaura la sesión y revisa el respaldo una vez
  const espera = setInterval(() => {
    if (!peliculas.length || $("app").style.display !== "block") return;
    clearInterval(espera);
    restaurarSesion();
    respaldoSemanal();
    mostrarEstadoRespaldo();
  }, 300);

  setInterval(mantener, 60000);
  setInterval(respaldoSemanal, 600000);
})();

/* --- bloque 11 --- */
/* ===== Sincronización segura de marcas (punto 1) ===== */
let syncUid = null;          // id estable de la cuenta de Google (sub)
let syncBase = {};           // última versión confirmada en Drive
let syncPendiente = false;   // hay cambios de este dispositivo sin subir
let syncEnCurso = false;
let syncOtraVez = false;
let syncReintento = null;
let syncUltimaVuelta = 0;

const syncClave = () => "marcas_v6_" + syncUid;
const syncIguales = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const syncClon = o => JSON.parse(JSON.stringify(o));

function syncLeerLocal() {
  if (!syncUid) return null;
  try { return JSON.parse(localStorage.getItem(syncClave()) || "null"); } catch (e) { return null; }
}

function syncGuardarLocal() {
  if (!syncUid) return;
  try {
    localStorage.setItem(syncClave(), JSON.stringify({ marcas: marcas, base: syncBase, pendiente: syncPendiente }));
  } catch (e) {}
}

function syncBorrarLocal() {
  syncBase = {};
  syncPendiente = false;
  if (syncUid) { try { localStorage.removeItem(syncClave()); } catch (e) {} }
}

// Marca la hora solo en las películas que cambiaron desde la última sincronización
function syncMarcarCambios() {
  const ahora = Date.now();
  new Set([...Object.keys(marcas), ...Object.keys(syncBase)]).forEach(k => {
    if (k.startsWith("__") || !marcas[k]) return;
    if (!syncIguales(marcas[k], syncBase[k])) marcas[k].mod = ahora;
  });
}

// Cuenta los cambios de este dispositivo que todavía no están en Drive
function syncContarPendientes() {
  let n = 0;
  new Set([...Object.keys(marcas), ...Object.keys(syncBase)]).forEach(k => {
    if (k.startsWith("__")) return;
    if (!syncIguales(marcas[k], syncBase[k])) n++;
  });
  return n;
}

function mensajeSinConexion() {
  const n = syncContarPendientes();
  return "Sin conexión: " + (n ? n + (n === 1 ? " cambio" : " cambios") + " por subir" : "todo guardado en este dispositivo") + ".";
}

// Mezcla película por película: usa la base común para saber qué cambió de cada lado
function syncMezclar(local, remota, base) {
  const res = {};
  new Set([...Object.keys(local), ...Object.keys(remota), ...Object.keys(base)]).forEach(k => {
    const l = local[k], r = remota[k], b = base[k];
    const cambioLocal = !syncIguales(l, b);
    const cambioRemoto = !syncIguales(r, b);
    let v;
    if (!cambioLocal && !cambioRemoto) v = b;
    else if (cambioLocal && !cambioRemoto) v = l;
    else if (!cambioLocal && cambioRemoto) v = r;
    else if (k.startsWith("__") || !r) v = l;
    else if (!l) v = r;
    else v = ((l.mod || 0) >= (r.mod || 0)) ? l : r;
    if (v !== undefined) res[k] = v;
  });
  return res;
}

// Identidad de la cuenta: permite separar la copia local de cada persona
async function syncCargarUid() {
  try {
    const r = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
      headers: { Authorization: "Bearer " + accessToken }
    });
    if (!r.ok) throw new Error("userinfo " + r.status);
    const j = await r.json();
    syncUid = j.sub || null;
    if (syncUid) { try { localStorage.setItem("sync_uid_cache", syncUid); } catch (e) {} }
  } catch (e) {
    // Sin señal: usa el id guardado en la última sesión con conexión
    try { syncUid = localStorage.getItem("sync_uid_cache"); } catch (e2) { syncUid = null; }
  }
  if (!syncUid) throw new Error("sin id de cuenta");
}

// Lee todos los marcas.json de tu Drive y los combina, para no perder nada si hubo duplicados
async function syncLeerTodos() {
  const q = encodeURIComponent("name='marcas.json'");
  // Si esto falla, lanza error: no seguimos y no creamos archivos nuevos
  const r = await driveFetch(`https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=${q}&orderBy=modifiedTime%20desc&fields=files(id,modifiedTime)`);
  const j = await r.json();
  const ids = (j.files || []).map(f => f.id);
  let combinado = {};
  for (const id of ids) {
    const c = await driveFetch(`https://www.googleapis.com/drive/v3/files/${id}?alt=media`);
    const datos = await c.json();
    combinado = syncMezclar(combinado, datos || {}, {});
  }
  return { ids, combinado };
}
async function syncSubir(id, datos) {
  const cuerpo = JSON.stringify(datos);
  if (id) {
    await driveFetch(`https://www.googleapis.com/upload/drive/v3/files/${id}?uploadType=media`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: cuerpo
    });
    return id;
  }
  const frontera = "marcas_frontera";
  const meta = JSON.stringify({ name: "marcas.json", parents: ["appDataFolder"] });
  const partes = `--${frontera}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n` +
    `--${frontera}\r\nContent-Type: application/json\r\n\r\n${cuerpo}\r\n--${frontera}--`;
  const r = await driveFetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", {
    method: "POST",
    headers: { "Content-Type": `multipart/related; boundary=${frontera}` },
    body: partes
  });
  const j = await r.json();
  return j.id;
}

// Función central: lee Drive, combina, sube y solo confirma "guardado" si la subida funcionó
async function syncTodo() {
  if (!accessToken) return;
  if (syncEnCurso) { syncOtraVez = true; return; }
  if (navigator.onLine === false) {
    syncMarcarCambios();
    syncPendiente = syncContarPendientes() > 0;
    syncGuardarLocal();
    setEstado(mensajeSinConexion());
    return;
  }
  syncEnCurso = true;
  clearTimeout(syncReintento);
  if (syncContarPendientes() > 0) setEstado("Guardando…");
  try {
    syncMarcarCambios();
    const { ids, combinado } = await syncLeerTodos();
    const antes = syncClon(marcas);
    marcas = envolverMarcas(syncMezclar(marcas, combinado, syncBase));
    const cambio = !syncIguales(antes, marcas);
    const enviar = syncClon(marcas);
    if (!syncIguales(enviar, combinado) || ids.length > 1) {
      if (ids.length || Object.keys(enviar).length) {
        idMarcas = await syncSubir(ids[0] || null, enviar);
        for (const id of ids.slice(1)) {
          await driveFetch(`https://www.googleapis.com/drive/v3/files/${id}`, { method: "DELETE" });
        }
      }
    } else {
      idMarcas = ids[0] || null;
    }
    syncBase = enviar;
    syncPendiente = !syncIguales(marcas, enviar);
    syncGuardarLocal();
    if (cambio && peliculas.length) refrescarTodo();
    const hora = new Date().toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" });
    ultimaSyncOk = Date.now();
    setEstado((syncPendiente ? "Hay cambios nuevos por subir…" : "Guardado en tu Drive · " + hora) + avisoIds());
  } catch (e) {
    syncPendiente = !syncIguales(marcas, syncBase);
    syncGuardarLocal();
    setEstado(navigator.onLine === false
      ? mensajeSinConexion()
      : "No se pudo subir ahora. Reintentaré en 30 segundos.");
    syncReintento = setTimeout(syncTodo, 30000);
  } finally {
    syncEnCurso = false;
    if (syncOtraVez) { syncOtraVez = false; syncTodo(); }
  }
}

// Avisa en la barra de estado si hay marcas que ya no coinciden con ninguna fila de la hoja
function avisoIds() {
  if (!peliculas.length) return "";
  const ids = new Set(peliculas.map(idDe));
  const huerfanas = Object.keys(marcas).filter(k => !k.startsWith("__") && marcas[k] && !ids.has(k)).length;
  const sinId = peliculas.filter(p => !/^\d+$/.test(String(p.tmdb_id || "").trim())).length;
  let t = "";
  if (huerfanas) t += " · " + huerfanas + (huerfanas === 1 ? " marca sin película en la hoja" : " marcas sin película en la hoja");
  if (sinId) t += " · " + sinId + (sinId === 1 ? " película sin tmdb_id" : " películas sin tmdb_id");
  return t;
}

// Identidad estable de cada película: su tmdb_id; si no tiene, una versión normalizada del título
function idDe(p) {
  const t = String(p.tmdb_id || "").trim();
  return /^\d+$/.test(t) ? "tmdb:" + t : "slug:" + slugDe(p);
}

/* ---------- Claves estables: las marcas se guardan por id (tmdb:123), no por título ---------- */
function claveDe(p) { return idDe(p); }

let mapaTitulos = {};   // título -> clave estable (se llena al cargar la hoja)
const tieneProp = (o, k) => Object.prototype.hasOwnProperty.call(o, k);

function construirMapaTitulos() {
  mapaTitulos = {};
  peliculas.forEach(p => { if (!tieneProp(mapaTitulos, p.titulo)) mapaTitulos[p.titulo] = claveDe(p); });
}

// Pasa las claves de título a su clave estable; si dos registros chocan, combina sus campos (gana el más reciente)
function normalizarClaves(obj) {
  const out = {};
  Object.keys(obj || {}).forEach(k => {
    const destino = (!k.startsWith("__") && tieneProp(mapaTitulos, k)) ? mapaTitulos[k] : k;
    const v = obj[k];
    if (tieneProp(out, destino) && out[destino] && v) {
      const a = out[destino];
      out[destino] = (a.mod || 0) > (v.mod || 0) ? Object.assign({}, v, a) : Object.assign({}, a, v);
      return;
    }
    out[destino] = v;
  });
  return out;
}

// Envuelve las marcas: el resto de la página puede seguir usando marcas[título]; por dentro se guarda por id
function envolverMarcas(obj) {
  const base = normalizarClaves(obj);
  const traducir = k => (typeof k === "string" && !k.startsWith("__") && tieneProp(mapaTitulos, k)) ? mapaTitulos[k] : k;
  return new Proxy(base, {
    get: (t, k) => t[traducir(k)],
    set: (t, k, v) => { t[traducir(k)] = v; return true; },
    deleteProperty: (t, k) => { delete t[traducir(k)]; return true; },
    has: (t, k) => traducir(k) in t
  });
}

// Migración única: respaldo local previo, conversión de claves y marca de versión 2
function migrarClaves() {
  if (marcas.__version === 2) return false;
  if (syncUid) { try { localStorage.setItem("respaldo_antes_de_claves_" + syncUid, JSON.stringify(marcas)); } catch (e) {} }
  const antes = JSON.stringify(marcas);
  marcas = envolverMarcas(marcas);
  marcas.__version = 2;
  programarGuardado();
  return JSON.stringify(marcas) !== antes;
}

// Funciones que usa el resto de la página
/* ---------- Ventana sencilla reutilizable ---------- */
function abrirVentanaSimple(id, titulo, cuerpo) {
  const previa = document.getElementById(id);
  if (previa) previa.remove();
  const div = document.createElement("div");
  div.id = id;
  div.className = "ayuda-atajos";
  div.innerHTML = '<div class="ayuda-caja ventana-larga" role="dialog" aria-label="' + esc(titulo) + '">' +
    '<button type="button" class="dlg-x" data-cerrar aria-label="Cerrar">×</button>' +
    '<h3>' + esc(titulo) + '</h3>' + cuerpo + '</div>';
  div.addEventListener("click", e => { if (e.target === div || e.target.hasAttribute("data-cerrar")) div.remove(); });
  document.body.appendChild(div);
}

/* ---------- Cápsula del año ---------- */
function vistasDelAno(ano) {
  return peliculas.filter(p => ((marcas[p.titulo] || {}).historial || [])
    .some(h => h.a === "vista" && String(h.f).startsWith(ano)));
}

function abrirCapsulaAno() {
  const ano = String(new Date().getFullYear());
  const vistas = vistasDelAno(ano);
  if (!vistas.length) {
    abrirVentanaSimple("capsulaAno", "Cápsula " + ano,
      '<p class="meta">Aún no marcas películas como vistas este año. Cuando lo hagas, aquí verás tu resumen.</p>');
    return;
  }
  const est = p => (marcas[p.titulo] || {}).estrellas || 0;
  const top = vistas.slice().sort((a, b) => est(b) - est(a)).slice(0, 5);
  const genero = {};
  vistas.forEach(p => String(p.genero || "").split(/[,\/]/).map(x => x.trim()).filter(Boolean)
    .forEach(g => genero[g] = (genero[g] || 0) + 1));
  const generos = Object.entries(genero).sort((a, b) => b[1] - a[1]).slice(0, 3).map(x => x[0]).join(", ") || "sin datos";
  const calificadas = vistas.filter(p => est(p) > 0);
  const promedio = calificadas.length
    ? (calificadas.reduce((s, p) => s + est(p), 0) / calificadas.length).toFixed(1) : "—";
  const cuerpo =
    '<div class="capsula-stats">' +
    '<div><b>' + vistas.length + '</b><span>vistas</span></div>' +
    '<div><b>' + promedio + '★</b><span>promedio</span></div>' +
    '<div><b>' + esc(generos) + '</b><span>géneros favoritos</span></div></div>' +
    '<h4>Tus favoritas del año</h4><ol>' +
    top.map(p => '<li>' + esc(p.titulo) + (est(p) ? ' · ' + est(p) + '★' : '') + '</li>').join('') + '</ol>';
  abrirVentanaSimple("capsulaAno", "Cápsula " + ano, cuerpo);
}

/* ---------- Modo pareja: elegir de «Para ver con alguien» ---------- */
function modoPareja() {
  try { return localStorage.getItem("modo_pareja") === "1"; } catch (e) { return false; }
}

function alternarModoPareja() {
  const activo = !modoPareja();
  try { localStorage.setItem("modo_pareja", activo ? "1" : "0"); } catch (e) {}
  $("parejaBtn").textContent = activo ? "💑 Modo pareja: activo" : "💑 Modo pareja";
  $("parejaBtn").classList.toggle("destacado", activo);
  setEstado(activo ? "Modo pareja activo: el aleatorio elige entre «Para ver con alguien»." : "Modo pareja desactivado.");
}

function sugerirParaDos() {
  const pool = peliculas.filter(p => (marcas[p.titulo] || {}).conAlguien && !(marcas[p.titulo] || {}).vista);
  if (!pool.length) {
    setEstado("Aún no tienen películas para ver juntos. Marca «Para ver con alguien» en una pendiente.");
    return;
  }
  abrirDetalle(pool[Math.floor(Math.random() * pool.length)]);
}

/* ---------- Reto del mes ---------- */
const RETOS_MES = [
  { texto: "Ve 3 películas este mes", meta: 3, cuenta: vs => vs.length },
  { texto: "Ve una película de un país distinto a Estados Unidos", meta: 1,
    cuenta: vs => vs.filter(p => !/estados unidos|eeuu|ee\. ?uu|usa/i.test(String(p.pais || ""))).length },
  { texto: "Ve una película anterior a 1980", meta: 1,
    cuenta: vs => vs.filter(p => Number(p["año"]) < 1980).length },
  { texto: "Ve 2 películas que califiques con 4 o 5★", meta: 2,
    cuenta: vs => vs.filter(p => ((marcas[p.titulo] || {}).estrellas || 0) >= 4).length }
];

function renderRetoMes() {
  const sec = $("retoMes");
  const hoy = new Date();
  const mes = hoy.getFullYear() + "-" + String(hoy.getMonth() + 1).padStart(2, "0");
  const vistasMes = peliculas.filter(p => ((marcas[p.titulo] || {}).historial || [])
    .some(h => h.a === "vista" && String(h.f).startsWith(mes)));
  const reto = RETOS_MES[hoy.getMonth() % RETOS_MES.length];
  const hecho = Math.min(reto.cuenta(vistasMes), reto.meta);
  const listo = hecho >= reto.meta;
  sec.style.display = "block";
  sec.innerHTML = '<div class="reto-caja' + (listo ? ' listo' : '') + '">' +
    '<div class="reto-titulo">🏆 Reto del mes</div>' +
    '<div class="reto-texto">' + esc(reto.texto) + '</div>' +
    '<div class="reto-barra"><span style="width:' + Math.round(hecho / reto.meta * 100) + '%"></span></div>' +
    '<div class="meta">' + (listo ? '¡Reto cumplido este mes!' : hecho + " de " + reto.meta + " logrado") + '</div></div>';
}

/* ---------- Diario de cine ---------- */
function abrirDiario() {
  const entradas = [];
  peliculas.forEach(p => {
    const o = marcas[p.titulo] || {};
    if (!o.vista) return;
    const v = (o.historial || []).filter(h => h.a === "vista").slice(-1)[0];
    entradas.push({ p, o, f: v ? String(v.f) : "" });
  });
  entradas.sort((a, b) => (b.f || "0").localeCompare(a.f || "0"));
  if (!entradas.length) {
    abrirVentanaSimple("diarioCine", "Diario de cine",
      '<p class="meta">Tu diario se llena solo cuando marcas películas como vistas. Escribe una nota en cada una y aparecerá aquí.</p>');
    return;
  }
  let html = "", mesActual = "";
  entradas.slice(0, 200).forEach(e => {
    const mes = e.f ? e.f.slice(0, 7) : "Sin fecha";
    if (mes !== mesActual) { mesActual = mes; html += '<h4>' + esc(mes) + '</h4>'; }
    html += '<div class="diario-entrada"><b>' + esc(e.p.titulo) + '</b>' +
      (e.o.estrellas ? ' <span class="meta">' + e.o.estrellas + '★</span>' : '') +
      (e.f ? ' <span class="meta">· ' + esc(e.f) + '</span>' : '') +
      (e.o.nota ? '<p>' + esc(e.o.nota) + '</p>' : '') + '</div>';
  });
  abrirVentanaSimple("diarioCine", "Diario de cine", html);
}

/* ---------- Perfil de gustos para Estela (sale de tus marcas) ---------- */
function perfilGustos() {
  const gen = {}, dir = {}, neg = {};
  let pend = 0;
  peliculas.forEach(p => {
    const o = marcas[p.titulo] || {};
    const gs = String(p.genero || "").split(/[,\/]/).map(x => x.trim()).filter(Boolean);
    if (o.pendiente) pend++;
    if (o.vista && (o.estrellas || 0) >= 4) {
      gs.forEach(g => gen[g] = (gen[g] || 0) + 1);
      if (p.director) dir[p.director] = (dir[p.director] || 0) + 1;
    }
    if (o.descartada) gs.forEach(g => neg[g] = (neg[g] || 0) + 1);
  });
  const top = obj => Object.entries(obj).sort((a, b) => b[1] - a[1]).slice(0, 3).map(x => x[0]).join(", ") || "sin datos";
  return "le gustan los géneros " + top(gen) + "; directores " + top(dir) +
    "; descarta " + top(neg) + "; tiene " + pend + " pendientes";
}

/* ---------- Avisos visibles (aparecen sobre la barra inferior) ---------- */
let toastTimer = null;
function avisar(msg) {
  setEstado(msg);
  let t = document.getElementById("toastApp");
  if (!t) {
    t = document.createElement("div");
    t.id = "toastApp";
    t.className = "toast-app";
    t.setAttribute("role", "status");
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add("visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("visible"), 4200);
}

/* ---------- Etapa 1: selección inteligente ---------- */
const TEMAS_NOCHE = [
  { dia: "domingo", tema: "Ciencia ficción", genero: "ciencia ficci" },
  { dia: "lunes", tema: "Animación", genero: "animaci" },
  { dia: "martes", tema: "Comedia", genero: "comedia" },
  { dia: "miércoles", tema: "Drama", genero: "drama" },
  { dia: "jueves", tema: "Aventura", genero: "aventura" },
  { dia: "viernes", tema: "Terror o suspenso", genero: "terror|suspenso|thriller" },
  { dia: "sábado", tema: "Romance", genero: "romance" }
];

function pendientesNoVistas() {
  return peliculas.filter(p => (marcas[p.titulo] || {}).pendiente && !(marcas[p.titulo] || {}).vista);
}

function generoCoincide(p, patron) {
  return new RegExp(patron, "i").test(String(p.genero || ""));
}

function elegirAlAzar(lista) {
  return lista[Math.floor(Math.random() * lista.length)];
}

/* 1) Noche temática según el día */
function nocheTematica() {
  const hoy = TEMAS_NOCHE[new Date().getDay()];
  const pool = pendientesNoVistas();
  if (!pool.length) {
    avisar("No tienes pendientes sin ver. Agrega algunas para elegir.");
    return;
  }
  const del_tema = pool.filter(p => generoCoincide(p, hoy.genero));
  if (!del_tema.length) {
    avisar("Hoy es noche de " + hoy.tema + ", pero no tienes pendientes de ese género. Te muestro otra.");
    abrirDetalle(elegirAlAzar(pool));
    return;
  }
  avisar("Noche de " + hoy.tema + " (" + hoy.dia + ").");
  abrirDetalle(elegirAlAzar(del_tema));
}

/* 3) Maratón: arma hasta 3 películas que quepan en el tiempo indicado */
function abrirMaraton() {
  abrirVentanaSimple("maraton", "Maratón",
    '<p class="meta">¿Cuántos minutos tienes para ver películas?</p>' +
    '<div class="fila-form"><input id="maraMin" type="number" min="30" step="15" value="300" inputmode="numeric">' +
    '<button type="button" class="pildora destacado" id="maraGo">Armar</button></div>' +
    '<div id="maraRes"></div>');
  document.getElementById("maraGo").addEventListener("click", () => armarMaraton(Number(document.getElementById("maraMin").value)));
  armarMaraton(300);
}

function armarMaraton(minutosPedidos) {
  const res = document.getElementById("maraRes");
  if (!minutosPedidos || minutosPedidos <= 0) { res.innerHTML = '<p class="meta">Escribe un número de minutos.</p>'; return; }
  const pool = pendientesNoVistas().map(p => ({ p, m: minutos(p) })).filter(x => x.m > 0);
  if (!pool.length) {
    res.innerHTML = '<p class="meta">Ninguna pendiente tiene duración escrita. Revisa la columna «duracion» de la hoja, por ejemplo «1 h 45 min».</p>';
    return;
  }
  const orden = pool.slice().sort(() => Math.random() - 0.5);
  const elegidas = [];
  let total = 0;
  for (const x of orden) {
    if (elegidas.length >= 3) break;
    if (total + x.m <= minutosPedidos) { elegidas.push(x); total += x.m; }
  }
  if (!elegidas.length) {
    res.innerHTML = '<p class="meta">Ninguna pendiente cabe en ' + minutosPedidos + ' minutos. Prueba con más tiempo.</p>';
    return;
  }
  const h = Math.floor(total / 60), mm = total % 60;
  res.innerHTML = '<p class="meta">Total: ' + h + ' h ' + mm + ' min · ' + elegidas.length + ' películas</p><ol>' +
    elegidas.map(x => '<li><b>' + esc(x.p.titulo) + '</b> · ' + x.m + ' min</li>').join("") + '</ol>';
}

/* 8) Modo sorpresa con reglas */
function abrirSorpresa() {
  const generos = [...new Set(peliculas.flatMap(p => String(p.genero || "").split(/[,\/]/).map(x => x.trim()).filter(Boolean)))].sort();
  abrirVentanaSimple("sorpresa", "Sorpresa con reglas",
    '<label class="campo">Duración máxima<select id="sorpDur"><option value="0">Cualquiera</option><option value="90">Hasta 90 min</option><option value="120">Hasta 2 h</option></select></label>' +
    '<label class="campo">Género<select id="sorpGen"><option value="">Cualquiera</option>' +
    generos.map(g => '<option value="' + esc(g) + '">' + esc(g) + '</option>').join("") + '</select></label>' +
    '<label class="campo">Actor (opcional)<input id="sorpAct" type="text" placeholder="Ej. Scarlett Johansson"></label>' +
    '<p id="sorpRes" class="meta"></p>' +
    '<button type="button" class="pildora destacado" id="sorpOtra">🎲 Sorpréndeme</button>');
  const elegir = () => {
    const dur = Number($("sorpDur") ? document.getElementById("sorpDur").value : 0);
    const gen = document.getElementById("sorpGen").value;
    const act = document.getElementById("sorpAct").value.trim().toLowerCase();
    const pool = pendientesNoVistas().filter(p =>
      (!dur || (minutos(p) > 0 && minutos(p) <= dur)) &&
      (!gen || String(p.genero || "").toLowerCase().includes(gen.toLowerCase())) &&
      (!act || String(p.reparto || "").toLowerCase().includes(act)));
    const res = document.getElementById("sorpRes");
    if (!pool.length) {
      const soloGenero = pendientesNoVistas().filter(p => !gen || String(p.genero || "").toLowerCase().includes(gen.toLowerCase())).length;
      res.textContent = soloGenero
        ? "Hay " + soloGenero + " pendiente(s) de ese género, pero ninguna cumple también la duración o el actor. Relaja una regla."
        : "No tienes pendientes de ese género. Elige «Cualquiera» o agrega películas.";
      return;
    }
    const p = elegirAlAzar(pool);
    res.innerHTML = "Te toca: <b>" + esc(p.titulo) + "</b>";
    document.querySelector("#sorpresa [data-cerrar]").click();
    abrirDetalle(p);
  };
  document.getElementById("sorpOtra").addEventListener("click", elegir);
}

/* ---------- Etapa 2a: votación en pareja (en un mismo dispositivo) ---------- */
function leerVotos() {
  try { return JSON.parse(localStorage.getItem("votos_pareja") || "{}"); } catch (e) { return {}; }
}
function guardarVotos(v) {
  try { localStorage.setItem("votos_pareja", JSON.stringify(v)); } catch (e) {}
}

function abrirVotacionPareja() {
  const votos = leerVotos();
  let quien = "1";
  const candidatas = () => pendientesNoVistas().filter(p => !(votos[p.titulo] && votos[p.titulo][quien]));

  function pintarVotacion() {
    const cola = candidatas();
    const caja = document.querySelector("#votacionPareja .ventana-larga");
    const coincidencias = pendientesNoVistas().filter(p => votos[p.titulo] && votos[p.titulo]["1"] === 1 && votos[p.titulo]["2"] === 1);
    let html = '<p class="meta">Votando: <b>Persona ' + quien + '</b> · pendientes por votar: ' + cola.length + '</p>';
    if (cola.length) {
      const p = cola[0];
      html += '<div class="voto-tarjeta"><b>' + esc(p.titulo) + '</b><div class="meta">' +
        esc(p.genero || "") + (p.duracion ? " · " + esc(p.duracion) : "") + '</div>' +
        '<div class="voto-botones"><button type="button" class="pildora" data-voto="-1">👎 No</button>' +
        '<button type="button" class="pildora destacado" data-voto="1">👍 Sí</button></div></div>';
    } else {
      html += '<p class="meta">Ya votó esta persona por todas.</p>';
    }
    html += '<button type="button" class="pildora" id="cambiarPersona">Cambiar a Persona ' + (quien === "1" ? "2" : "1") + '</button>';
    html += '<h4>Coinciden los dos (' + coincidencias.length + ')</h4><ul>' +
      coincidencias.map(p => '<li>' + esc(p.titulo) + '</li>').join("") + '</ul>';
    caja.querySelector(".voto-cuerpo").innerHTML = html;
    caja.querySelectorAll("[data-voto]").forEach(b => b.addEventListener("click", () => {
      const t = cola[0].titulo;
      votos[t] = Object.assign({}, votos[t] || {}, { [quien]: Number(b.dataset.voto) });
      guardarVotos(votos);
      pintarVotacion();
    }));
    document.getElementById("cambiarPersona").addEventListener("click", () => {
      quien = quien === "1" ? "2" : "1";
      pintarVotacion();
    });
  }

  abrirVentanaSimple("votacionPareja", "Votación en pareja",
    '<div class="voto-cuerpo"></div>' +
    '<p class="meta">Se guarda en este navegador. Es para votar en un mismo dispositivo, turnándose.</p>' +
    '<button type="button" class="pildora" id="reiniciarVotos">Empezar de cero</button>');
  document.getElementById("reiniciarVotos").addEventListener("click", () => {
    guardarVotos({});
    Object.keys(votos).forEach(k => delete votos[k]);
    pintarVotacion();
  });
  pintarVotacion();
}

/* ---------- Etapa 2b: filtro por ánimo (ordena el catálogo) ---------- */
const ANIMOS = [
  { id: "tranquilo", texto: "😌 Tranquilo", generos: "animaci|documental|romance" },
  { id: "emocionado", texto: "🔥 Emocionado", generos: "acci|aventura|ciencia ficci|thriller" },
  { id: "reir", texto: "😂 Quiero reír", generos: "comedia" },
  { id: "melancolico", texto: "🌧 Melancólico", generos: "drama" },
  { id: "pensar", texto: "🧠 Para pensar", generos: "misterio|documental|historia|ciencia ficci" }
];

function animoActual() {
  try { return localStorage.getItem("animo") || ""; } catch (e) { return ""; }
}

function abrirAnimo() {
  const actual = animoActual();
  abrirVentanaSimple("animoVentana", "¿Cómo te sientes hoy?",
    ANIMOS.map(a => '<button type="button" class="pildora animo-op' + (a.id === actual ? ' destacado' : '') +
      '" data-animo="' + a.id + '">' + esc(a.texto) + '</button>').join(" ") +
    '<p class="meta">El catálogo pondrá primero las películas de ese ánimo.</p>' +
    '<button type="button" class="pildora" data-animo="">Quitar ánimo</button>');
  document.querySelectorAll("#animoVentana [data-animo]").forEach(b => b.addEventListener("click", () => {
    try { localStorage.setItem("animo", b.dataset.animo); } catch (e) {}
    document.querySelector("#animoVentana [data-cerrar]").click();
    pintar();
    const a = ANIMOS.find(x => x.id === b.dataset.animo);
    avisar(a ? "Catálogo en modo " + a.texto + "." : "Ánimo quitado.");
  }));
}

function ordenarPorAnimo(lista) {
  const a = ANIMOS.find(x => x.id === animoActual());
  if (!a) return lista;
  const re = new RegExp(a.generos, "i");
  return lista.slice().sort((x, y) => (re.test(String(y.genero || "")) ? 1 : 0) - (re.test(String(x.genero || "")) ? 1 : 0));
}

/* ---------- Etapa 2c: el ánimo cambia el color de las tarjetas ---------- */
const ANIMO_COLOR = { tranquilo: "#30b0c7", emocionado: "#ff6b35", reir: "#ffcc00", melancolico: "#5e5ce6", pensar: "#34c759" };

function marcarAnimo() {
  const lis = document.getElementById("lista");
  if (!lis) return;
  const a = ANIMOS.find(x => x.id === animoActual());
  lis.classList.toggle("animo-activo", !!a);
  if (!a) return;
  lis.style.setProperty("--animo", ANIMO_COLOR[a.id]);
  const re = new RegExp(a.generos, "i");
  lis.querySelectorAll("[data-i]").forEach(el => {
    const p = visibles[Number(el.dataset.i)];
    el.classList.toggle("animo-match", !!p && re.test(String(p.genero || "")));
  });
}

/* ---------- Etapa 3a: mapa de viaje cinematográfico ---------- */
const PAISES_MAPA = ["Estados Unidos", "México", "Francia", "Italia", "España", "Japón", "Corea del Sur", "India",
  "Brasil", "Reino Unido", "Alemania", "China", "Argentina", "Canadá", "Irán", "Australia", "Rusia", "Suecia"];

const PAIS_ALIAS = {
  "United States of America": "Estados Unidos", "United States": "Estados Unidos", "USA": "Estados Unidos", "EE. UU.": "Estados Unidos",
  "Mexico": "México", "Spain": "España", "France": "Francia", "Italy": "Italia", "Japan": "Japón",
  "South Korea": "Corea del Sur", "Korea": "Corea del Sur", "Germany": "Alemania", "United Kingdom": "Reino Unido",
  "Brazil": "Brasil", "Canada": "Canadá", "Iran": "Irán", "Russia": "Rusia", "Sweden": "Suecia"
};
function normPais(c) {
  const x = String(c || "").trim();
  return PAIS_ALIAS[x] || x;
}
function paisesDe(p) {
  return String(p.pais || "").split(/[,\/]/).map(x => normPais(x)).filter(Boolean);
}

function abrirMapaViaje() {
  const mapa = {};
  peliculas.forEach(p => {
    const o = marcas[p.titulo] || {};
    paisesDe(p).forEach(c => {
      mapa[c] = mapa[c] || { total: 0, vistas: 0, films: [] };
      mapa[c].total++;
      if (o.vista) mapa[c].vistas++;
      mapa[c].films.push(p);
    });
  });
  const paises = Object.keys(mapa).sort((x, y) => x.localeCompare(y, "es"));
  const visitados = paises.filter(c => mapa[c].vistas > 0).length;
  const sugerido = paises.filter(c => mapa[c].vistas === 0).sort((x, y) => mapa[y].total - mapa[x].total)[0];
  abrirVentanaSimple("mapaViaje", "Mapa de viaje",
    '<p class="meta">Has visto películas de ' + visitados + ' de ' + paises.length + ' países de tu catálogo. Toca un país para ver sus películas.</p>' +
    '<div class="paises-grid">' + paises.map(c =>
      '<button type="button" class="pais-chip' + (mapa[c].vistas ? ' visto' : '') + '" data-pais="' + esc(c) + '">' +
      esc(c) + ' · ' + mapa[c].total + '</button>').join("") + '</div>' +
    (sugerido ? '<p class="pais-sugerencia">Te sugiero <b>' + esc(sugerido) + '</b>, donde aún no has visto ninguna.</p>' : '') +
    '<div id="paisDetalle"></div>');
  const ventana = document.getElementById("mapaViaje");
  ventana.addEventListener("click", e => {
    const pais = e.target.closest("[data-pais]");
    const peli = e.target.closest("[data-titulo]");
    if (peli) {
      const p = peliculas.find(x => x.titulo === peli.dataset.titulo);
      ventana.remove();
      if (p) abrirDetalle(p);
      return;
    }
    if (!pais) return;
    const c = pais.dataset.pais;
    const films = mapa[c].films;
    document.getElementById("paisDetalle").innerHTML = '<h4>' + esc(c) + ' (' + films.length + ')</h4>' +
      films.map(p => {
        const o = marcas[p.titulo] || {};
        const estado = o.vista ? "✓ vista" : o.pendiente ? "⏳ pendiente" : "sin ver";
        return '<button type="button" class="explorar-item" data-titulo="' + esc(p.titulo) + '"><b>' + esc(p.titulo) +
          '</b><span class="meta">' + esc(p["año"] || "") + ' · ' + estado + '</span></button>';
      }).join("");
  });
}

/* ---------- Etapa 3b: rachas de gustos ---------- */
function detectarRachas() {
  const avisos = [];
  const vistas = peliculas.map(p => ({ p, o: marcas[p.titulo] || {} }))
    .filter(x => x.o.vista && x.o.estrellas)
    .map(x => {
      const ultima = (x.o.historial || []).filter(h => h.a === "vista").slice(-1)[0];
      return { p: x.p, o: x.o, f: ultima ? String(ultima.f) : "" };
    })
    .sort((a, b) => a.f.localeCompare(b.f));

  const dir = {};
  vistas.forEach(v => { if (v.o.estrellas >= 4 && v.p.director) dir[v.p.director] = (dir[v.p.director] || 0) + 1; });
  Object.entries(dir).filter(x => x[1] >= 3).forEach(([d, n]) =>
    avisos.push("Te gusta mucho " + d + ": " + n + " películas suyas con 4 o 5★."));

  if (vistas.length >= 16) {
    const topGenero = arr => {
      const c = {};
      arr.forEach(v => String(v.p.genero || "").split(/[,\/]/).map(x => x.trim()).filter(Boolean)
        .forEach(g => c[g] = (c[g] || 0) + 1));
      const e = Object.entries(c).sort((a, b) => b[1] - a[1])[0];
      return e ? e[0] : "";
    };
    const antes = topGenero(vistas.slice(-16, -8)), ahora = topGenero(vistas.slice(-8));
    if (antes && ahora && antes !== ahora)
      avisos.push("Últimamente te inclinas por " + ahora + " (antes era " + antes + ").");
  }
  return avisos;
}

/* ---------- Etapa 3c: buzón de cartas a tu yo futuro ---------- */
function fechaMasMeses(iso, meses) {
  const d = new Date(iso + "T12:00:00");
  d.setMonth(d.getMonth() + meses);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function cartasListas() {
  const hoy = hoyLocalISO();
  return peliculas.filter(p => {
    const c = (marcas[p.titulo] || {}).carta;
    return c && !c.leida && fechaMasMeses(c.fecha, c.meses) <= hoy;
  });
}

function abrirBuzon() {
  const listas = cartasListas();
  const vistas = peliculas.filter(p => (marcas[p.titulo] || {}).vista && !(marcas[p.titulo] || {}).carta);
  const cartaHtml = p => {
    const c = marcas[p.titulo].carta;
    return '<div class="carta-caja"><b>' + esc(p.titulo) + '</b> <span class="meta">escrita el ' + esc(c.fecha) + '</span>' +
      '<p>' + esc(c.texto) + '</p></div>';
  };
  const cuerpo =
    (listas.length
      ? '<h4>Cartas que ya puedes leer (' + listas.length + ')</h4>' + listas.map(cartaHtml).join("") +
        '<button type="button" class="pildora" id="marcarLeidas">Marcar como leídas</button>'
      : '<p class="meta">No hay cartas listas para leer.</p>') +
    '<h4>Escribir una carta</h4>' +
    (vistas.length
      ? '<label class="campo">Película vista<select id="cartaPeli">' +
        vistas.map(p => '<option>' + esc(p.titulo) + '</option>').join("") + '</select></label>' +
        '<label class="campo">Tu mensaje<textarea id="cartaTexto" rows="4" placeholder="¿Qué sentiste hoy? ¿Qué quieres recordar?"></textarea></label>' +
        '<label class="campo">Leer en<select id="cartaMeses"><option value="6">6 meses</option><option value="12">1 año</option></select></label>' +
        '<button type="button" class="pildora destacado" id="guardarCarta">Guardar carta</button>'
      : '<p class="meta">Marca una película como vista para escribirle una carta.</p>');
  abrirVentanaSimple("buzon", "Buzón de cartas", cuerpo);

  const marcarLeidas = document.getElementById("marcarLeidas");
  if (marcarLeidas) marcarLeidas.addEventListener("click", () => {
    listas.forEach(p => { marcas[p.titulo] = Object.assign({}, marcas[p.titulo], { carta: Object.assign({}, marcas[p.titulo].carta, { leida: true }) }); });
    programarGuardado();
    document.querySelector("#buzon [data-cerrar]").click();
    pintar();
    avisar("Cartas marcadas como leídas.");
  });

  const guardar = document.getElementById("guardarCarta");
  if (guardar) guardar.addEventListener("click", () => {
    const titulo = document.getElementById("cartaPeli").value;
    const texto = document.getElementById("cartaTexto").value.trim();
    if (!texto) { avisar("Escribe algo en la carta antes de guardarla."); return; }
    marcas[titulo] = Object.assign({}, marcas[titulo], {
      carta: { texto, fecha: hoyLocalISO(), meses: Number(document.getElementById("cartaMeses").value), leida: false }
    });
    programarGuardado();
    document.querySelector("#buzon [data-cerrar]").click();
    avisar("Carta guardada. Se abrirá dentro de " + document.getElementById("cartaMeses").selectedOptions[0].text + ".");
  });
}

/* ---------- Extras de Actividad: rachas y cartas listas ---------- */
function renderExtrasActividad() {
  const sec = $("retoMes");
  const avisos = detectarRachas();
  let html = avisos.map(a => '<p class="meta racha">· ' + esc(a) + '</p>').join("");
  const listas = cartasListas().length;
  if (listas) html += '<button type="button" class="pildora destacado" id="abrirBuzonBtn">📬 Tienes ' + listas + ' carta(s) lista(s)</button>';
  html += renderAlertasEstreno();
  sec.insertAdjacentHTML("beforeend", html);
  const b = document.getElementById("abrirBuzonBtn");
  if (b) b.addEventListener("click", abrirBuzon);
}

/* ---------- Etapa 4a: modo viaje (lista de pendientes guardada para usar sin internet) ---------- */
function prepararViaje() {
  const lista = pendientesNoVistas().map(p => ({
    titulo: p.titulo, genero: p.genero || "", duracion: p.duracion || "",
    año: p["año"] || "", sinopsis: String(p.sinopsis || "").slice(0, 300)
  }));
  if (!lista.length) {
    avisar("No tienes pendientes para llevar. Marca algunas como «Pendiente» primero.");
    return;
  }
  try {
    localStorage.setItem("paquete_viaje", JSON.stringify({ fecha: hoyLocalISO(), lista: lista }));
  } catch (e) {
    avisar("No pude guardar la lista de viaje en este navegador.");
    return;
  }
  avisar("Lista de viaje guardada: " + lista.length + " películas. Funciona sin internet.");
  abrirModoViaje();
}

function abrirModoViaje() {
  let paq = null;
  try { paq = JSON.parse(localStorage.getItem("paquete_viaje") || "null"); } catch (e) {}
  if (!paq || !paq.lista) {
    abrirVentanaSimple("modoViaje", "Modo viaje",
      '<p class="meta">Aún no tienes una lista de viaje. Usa «Preparar viaje» cuando tengas internet.</p>');
    return;
  }
  const pendientes = paq.lista.filter(x => !((marcas[x.titulo] || {}).vista));
  const cuerpo = '<p class="meta">Preparada el ' + esc(paq.fecha) + ' · ' + pendientes.length + ' por ver</p>' +
    (pendientes.length
      ? pendientes.map(x => '<div class="viaje-fila"><div><b>' + esc(x.titulo) + '</b>' +
          '<div class="meta">' + esc([x.genero, x.duracion, x["año"]].filter(Boolean).join(" · ")) + '</div></div>' +
          '<button type="button" class="pildora" data-vista="' + esc(x.titulo) + '">✓ Vista</button></div>').join("")
      : '<p class="meta">Ya viste todo lo de tu lista. ¡Buen viaje!</p>');
  abrirVentanaSimple("modoViaje", "Modo viaje", cuerpo);
  document.querySelectorAll("#modoViaje [data-vista]").forEach(b => b.addEventListener("click", () => {
    cambiarEstado(b.dataset.vista, { vista: true });
    avisar("Marcada como vista. Se sincronizará cuando vuelva la conexión.");
    document.querySelector("#modoViaje [data-cerrar]").click();
    abrirModoViaje();
  }));
}

/* ---------- Etapa 4b: alertas de estreno (columna «estreno» con fecha AAAA-MM-DD en la hoja) ---------- */
function sumarDiasEt(iso, dias) {
  const d = new Date(iso + "T12:00:00");
  d.setDate(d.getDate() + dias);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function alertasDeEstreno() {
  const hoy = hoyLocalISO();
  const limite = sumarDiasEt(hoy, 30);
  const fechaOk = f => /^\d{4}-\d{2}-\d{2}$/.test(String(f || ""));
  const todas = pendientesNoVistas().filter(p => fechaOk(p.estreno));
  return {
    hoy: todas.filter(p => p.estreno === hoy || p.estreno < hoy).sort((a, b) => a.estreno.localeCompare(b.estreno)),
    proximas: todas.filter(p => p.estreno > hoy && p.estreno <= limite).sort((a, b) => a.estreno.localeCompare(b.estreno))
  };
}

function renderAlertasEstreno() {
  const { hoy, proximas } = alertasDeEstreno();
  if (!hoy.length && !proximas.length) return "";
  return '<div class="alertas-estreno">' +
    hoy.map(p => '<p>🎬 Ya se estrenó y tienes pendiente: <b>' + esc(p.titulo) + '</b> (' + esc(p.estreno) + ')</p>').join("") +
    proximas.map(p => '<p>📅 Se estrena el ' + esc(p.estreno) + ': <b>' + esc(p.titulo) + '</b></p>').join("") +
    '</div>';
}

/* ---------- Explorar: herramientas visibles desde la pantalla de inicio ---------- */
function gruposHerramientas() {
  return [...document.querySelectorAll("#panelAvanzados .grupo-menu, #panelMas .grupo-menu")]
    .filter(g => !/^(Ver|Ayuda|Datos|Cuenta|Ajustes)$/.test((g.querySelector(".grupo-titulo") || {}).textContent || ""))
    .filter(g => [...g.querySelectorAll("button[id]")].some(b => DESC_HERRAMIENTAS[b.id]));
}

function abrirGrupoHerramientas(indice) {
  const g = gruposHerramientas()[indice];
  if (!g) return;
  const titulo = g.querySelector(".grupo-titulo").textContent;
  const botones = [...g.querySelectorAll("button[id]")];
  abrirVentanaSimple("explorarGrupo", titulo,
    '<div class="explorar-lista">' + botones.map(b =>
      '<button type="button" class="explorar-item" data-id="' + b.id + '">' + b.innerHTML + '</button>').join("") +
    '</div>');
  document.querySelectorAll("#explorarGrupo .explorar-item").forEach(b => b.addEventListener("click", () => {
    document.querySelector("#explorarGrupo [data-cerrar]").click();
    const destino = document.getElementById(b.dataset.id);
    if (destino) destino.click();
  }));
}

function herramientaDelDia() {
  const lista = todasHerramientas();
  if (!lista.length) return "";
  const hoy = new Date();
  const diaDelAno = Math.floor((hoy - new Date(hoy.getFullYear(), 0, 0)) / 86400000);
  const x = lista[diaDelAno % lista.length];
  return '<div class="hoy-dia"><span>✨ Prueba hoy: <b>' + esc(x.texto) + '</b></span>' +
    '<button type="button" class="pildora" data-run="' + x.id + '">Probar</button></div>';
}

function bloqueExplorar() {
  const grupos = gruposHerramientas();
  if (!grupos.length) return "";
  return '<div class="explorar-titulo">Explorar</div><div class="explorar-grid">' +
    grupos.map((g, i) => {
      const n = g.querySelectorAll("button[id]").length;
      return '<button type="button" class="explorar-tile" data-grupo="' + i + '">' +
        '<b>' + esc(g.querySelector(".grupo-titulo").textContent) + '</b>' +
        '<span class="meta">' + n + ' herramientas</span></button>';
    }).join("") + '</div>';
}

/* ---------- Explorar: buscador de herramientas (pestaña, Ctrl+K) ---------- */
function todasHerramientas() {
  const out = [];
  gruposHerramientas().forEach(g => {
    const grupo = g.querySelector(".grupo-titulo").textContent;
    g.querySelectorAll("button[id]").forEach(b => out.push({ id: b.id, html: b.innerHTML, texto: b.textContent.trim(), grupo: grupo }));
  });
  return out;
}

function ejecutarHerramienta(id) {
  const destino = document.getElementById(id);
  if (destino) destino.click();
}

const DESC_HERRAMIENTAS = {
  nocheTema: "Elige una pendiente del género que toca hoy.",
  maraton: "Arma hasta 3 pendientes que quepan en el tiempo que tienes.",
  sorpresa: "Una película según duración, género o actor.",
  animoBtn: "Ordena el catálogo según cómo te sientes hoy.",
  mapaViaje: "Qué países has visitado con tus películas.",
  parejaBtn: "Activa elegir solo entre las películas para ver con alguien.",
  votarPareja: "Cada quien vota sí o no, y ves en qué coinciden.",
  capsula: "Tu resumen del año: vistas, favoritas y géneros.",
  clasificar: "Clasifica rápido las películas que aún no tienes marcadas.",
  estadisticas: "Gráficas de tus calificaciones y tus hábitos.",
  diario: "Tus películas vistas con fecha y notas.",
  buzon: "Escribe cartas a tu yo futuro sobre una película.",
  prepararViaje: "Guarda tus pendientes para verlas sin internet.",
  verViaje: "Abre la lista guardada para llevarla.",
  guardarPaletas: "Calcula y guarda los colores de los pósters.",
  deshacer: "Regresa el último cambio en tus marcas.",
  atajos: "Muestra los atajos de teclado.",
  vista: "Cambia entre vista normal y compacta de la lista.",
  agrupar: "Agrupa las películas por tema.",
  limpiar: "Quita todos los filtros.",
  presetGuardar: "Guarda los filtros actuales para reusarlos.",
  presetBorrar: "Borra el filtro guardado seleccionado.",
  exportar: "Descarga tu catálogo en un archivo CSV.",
  respaldarMarcas: "Descarga una copia de tus marcas.",
  restaurarMarcas: "Carga una copia de tus marcas.",
  borrarMarcas: "Borra todas tus marcas (no se puede deshacer).",
  salirDispositivo: "Cierra tu sesión en este dispositivo.",
  toggleSalud: "Muestra el estado de los datos de la hoja.",
  aleatorio: "Sugiere una película al azar.",
  queVerNoche: "Te dice qué ver esta noche según el tiempo que tengas.",
  verGuia: "Abre esta guía."
};

function abrirExplorar() {
  const grupos = gruposHerramientas().map(g => ({
    titulo: g.querySelector(".grupo-titulo").textContent,
    items: [...g.querySelectorAll("button[id]")].map(b => ({
      id: b.id, html: b.innerHTML, texto: b.textContent.trim(), desc: DESC_HERRAMIENTAS[b.id] || ""
    }))
  }));
  const filtrar = q => {
    const t = q.trim().toLowerCase();
    return grupos.map(g => ({
      titulo: g.titulo,
      items: g.items.filter(x => !t || (x.texto + " " + x.desc + " " + g.titulo).toLowerCase().includes(t))
    })).filter(g => g.items.length);
  };
  const pintar = q => {
    const gs = filtrar(q);
    const plano = gs.flatMap(g => g.items);
    caja.innerHTML = gs.map(g =>
      '<h4 class="explorar-grupo">' + esc(g.titulo) + '</h4>' +
      g.items.map(x => '<button type="button" class="explorar-item" data-id="' + x.id + '">' +
        '<b>' + x.html + '</b><span class="meta">' + esc(x.desc) + '</span></button>').join("")
    ).join("") || '<p class="meta">Ninguna herramienta coincide. Prueba con otra palabra.</p>';
    return plano;
  };
  abrirVentanaSimple("explorarTodo", "Herramientas",
    '<input id="explorarBusca" class="campo-busca" type="search" placeholder="Busca por nombre o para qué sirve…" autocomplete="off">' +
    '<div id="explorarResultados" class="explorar-lista"></div>');
  const caja = document.getElementById("explorarResultados");
  const busca = document.getElementById("explorarBusca");
  pintar("");
  busca.addEventListener("input", () => pintar(busca.value));
  busca.addEventListener("keydown", e => {
    if (e.key !== "Enter") return;
    const primera = pintar(busca.value)[0];
    if (primera) { document.querySelector("#explorarTodo [data-cerrar]").click(); ejecutarHerramienta(primera.id); }
  });
  caja.addEventListener("click", e => {
    const b = e.target.closest(".explorar-item");
    if (!b) return;
    document.querySelector("#explorarTodo [data-cerrar]").click();
    ejecutarHerramienta(b.dataset.id);
  });
  busca.focus();
}

/* ---------- Pantalla de inicio: «Hoy» ---------- */
function saludoHoy() {
  const h = new Date().getHours();
  return h < 12 ? "Buenos días" : h < 19 ? "Buenas tardes" : "Buenas noches";
}

function retoActual() {
  const hoy = new Date();
  const mes = hoy.getFullYear() + "-" + String(hoy.getMonth() + 1).padStart(2, "0");
  const vistasMes = peliculas.filter(p => ((marcas[p.titulo] || {}).historial || [])
    .some(h => h.a === "vista" && String(h.f).startsWith(mes)));
  const reto = RETOS_MES[hoy.getMonth() % RETOS_MES.length];
  return { texto: reto.texto, hecho: Math.min(reto.cuenta(vistasMes), reto.meta), meta: reto.meta };
}

function renderHoy() {
  const sec = $("hoy");
  if (!sec) return;
  if (hayFiltros() || pestana !== "catalogo") {
    sec.style.display = "none";
    return;
  }
  const pend = pendientesNoVistas().length;
  const conAlguien = peliculas.filter(p => (marcas[p.titulo] || {}).conAlguien && !(marcas[p.titulo] || {}).vista).length;
  const r = retoActual();
  const sAhora = (typeof elegirParaAhora === "function") ? elegirParaAhora(null) : null;
  const resumenPend = pend ? pend + " pendiente" + (pend === 1 ? "" : "s") : "Aún no tienes pendientes";
  const extra = conAlguien ? " · " + conAlguien + " para ver con alguien" : "";
  sec.style.display = "block";
  sec.innerHTML =
    '<p class="hoy-saludo">' + saludoHoy() + '</p>' +
    '<h2 class="hoy-titulo">¿Qué vemos hoy?</h2>' +
    '<p class="hoy-sub">' + esc(resumenPend + extra) + '</p>' +
    (sAhora && sAhora.texto ? '<p class="hoy-ahora">Para esta hora: ' + esc(sAhora.texto) + '</p>' : '') +
    '<div class="hoy-acciones">' +
      '<button type="button" class="pildora destacado" id="hoyNoche">🎡 Noche temática</button>' +
      '<button type="button" class="pildora" id="hoyAzar">🎲 Al azar</button>' +
      '<button type="button" class="pildora" id="hoyAnimo">🎭 ¿Cómo te sientes?</button>' +
    '</div>' +
    '<div class="hoy-reto"><span>🏆 ' + esc(r.texto) + '</span>' +
      '<div class="reto-barra"><span style="width:' + Math.round(r.hecho / r.meta * 100) + '%"></span></div></div>' +
    herramientaDelDia() + bloqueExplorar() + renderAlertasEstreno();
  $("hoyNoche").addEventListener("click", nocheTematica);
  $("hoyAzar").addEventListener("click", sugerirAleatoria);
  $("hoyAnimo").addEventListener("click", abrirAnimo);
  sec.querySelectorAll("[data-run]").forEach(b => b.addEventListener("click", () => ejecutarHerramienta(b.dataset.run)));
  sec.querySelectorAll("[data-grupo]").forEach(b => b.addEventListener("click", () => abrirGrupoHerramientas(Number(b.dataset.grupo))));
}

/* ---------- Deshacer general (Ctrl/Cmd+Z o botón) ---------- */
let pilaDeshacer = [];
let ultimaCopiaMarcas = null;
let deshaciendo = false;

function registrarDeshacer() {
  if (deshaciendo) return;
  const actual = JSON.stringify(marcas);
  if (ultimaCopiaMarcas !== null && ultimaCopiaMarcas !== actual && ultimaCopiaMarcas !== "{}") {
    pilaDeshacer.push(ultimaCopiaMarcas);
    if (pilaDeshacer.length > 30) pilaDeshacer.shift();
  }
  ultimaCopiaMarcas = actual;
}

function deshacerUltimo() {
  if (!pilaDeshacer.length) {
    avisar("No hay cambios recientes que deshacer.");
    return;
  }
  const previa = pilaDeshacer.pop();
  deshaciendo = true;
  try {
    marcas = JSON.parse(previa);
    programarGuardado();
  } finally {
    deshaciendo = false;
  }
  ultimaCopiaMarcas = previa;
  pintar();
  avisar("Cambio deshecho. Puedes deshacer " + pilaDeshacer.length + " más.");
}

/* ---------- Atajos de teclado (computadora) ---------- */
function enCampoDeTexto(t) {
  return !!t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
}

function ventanaAbierta() {
  const m = document.getElementById("modal");
  const c = document.getElementById("chatPanel");
  const a = document.getElementById("ayudaAtajos");
  return (m && m.classList.contains("abierto")) || (c && c.classList.contains("abierto")) || !!a;
}

function toggleAyudaAtajos() {
  const previa = document.getElementById("ayudaAtajos");
  if (previa) { previa.remove(); return; }
  const div = document.createElement("div");
  div.id = "ayudaAtajos";
  div.className = "ayuda-atajos";
  div.innerHTML = '<div class="ayuda-caja" role="dialog" aria-label="Atajos de teclado">' +
    '<h3>Atajos de teclado</h3>' +
    '<dl><dt>/</dt><dd>Ir a la búsqueda</dd>' +
    '<dt>A</dt><dd>Sugerir una película al azar</dd>' +
    '<dt>N</dt><dd>Qué ver esta noche</dd>' +
    '<dt>Ctrl/Cmd + Z</dt><dd>Deshacer el último cambio</dd>' +
    '<dt>Esc</dt><dd>Cerrar la ventana abierta</dd>' +
    '<dt>?</dt><dd>Mostrar u ocultar esta ayuda</dd></dl>' +
    '<button type="button" class="pildora" id="cerrarAyudaAtajos">Entendido</button></div>';
  div.addEventListener("click", e => { if (e.target === div) div.remove(); });
  document.body.appendChild(div);
  document.getElementById("cerrarAyudaAtajos").addEventListener("click", () => div.remove());
}

document.addEventListener("keydown", e => {
  const ctrl = e.ctrlKey || e.metaKey;
  if (ctrl && !e.shiftKey && !e.altKey && e.key.toLowerCase() === "k") {
    e.preventDefault();
    abrirExplorar();
    return;
  }
  if (ctrl && !e.shiftKey && !e.altKey && e.key.toLowerCase() === "z" && !enCampoDeTexto(e.target)) {
    e.preventDefault();
    deshacerUltimo();
    return;
  }
  if (e.key === "Escape" && document.getElementById("ayudaAtajos")) {
    document.getElementById("ayudaAtajos").remove();
    return;
  }
  if (ctrl || e.altKey || enCampoDeTexto(e.target) || ventanaAbierta()) return;
  if (e.key === "/") {
    e.preventDefault();
    const b = document.getElementById("buscar");
    if (b) b.focus();
  } else if (e.key === "a" || e.key === "A") {
    document.getElementById("aleatorio").click();
  } else if (e.key === "n" || e.key === "N") {
    document.getElementById("queVerNoche").click();
  } else if (e.key === "?") {
    toggleAyudaAtajos();
  }
});

function programarGuardado() {
  registrarDeshacer();
  syncPendiente = true;
  syncGuardarLocal();
  clearTimeout(guardadoTimer);
  guardadoTimer = setTimeout(syncTodo, 600);
}

function guardarMarcasDrive() { return syncTodo(); }

async function cargarMarcas() {
  try { await syncCargarUid(); } catch (e) { syncUid = null; }
  const local = syncLeerLocal();
  marcas = envolverMarcas(local && local.marcas ? local.marcas : {});
  syncBase = local && local.base ? local.base : {};
  syncPendiente = !!(local && local.pendiente);
  if (!syncUid) setEstado("No pude confirmar tu cuenta; no se guarda copia local en este dispositivo.");
  await syncTodo();
  mostrarGuiaSiEsNueva();
}

// Borra todos los marcas.json y los respaldos semanales de tu Drive
async function syncBorrarTodoDrive() {
  const q = encodeURIComponent("name='marcas.json' or name contains 'respaldo-marcas-'");
  const r = await driveFetch(`https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=${q}&fields=files(id)`);
  const j = await r.json();
  for (const f of (j.files || [])) {
    await driveFetch(`https://www.googleapis.com/drive/v3/files/${f.id}`, { method: "DELETE" });
  }
}

// Al volver a la app (con límite de 30 s), al recuperar la conexión y cada 5 minutos
function syncAlVolver() {
  if (document.visibilityState !== "visible") return;
  if (Date.now() - syncUltimaVuelta < 30000) return;
  syncUltimaVuelta = Date.now();
  if (peliculas.length) syncTodo();
}
document.addEventListener("visibilitychange", syncAlVolver);
window.addEventListener("focus", syncAlVolver);
window.addEventListener("online", () => { setEstado("Conexión recuperada. Sincronizando…"); syncTodo(); });
window.addEventListener("offline", () => setEstado(mensajeSinConexion()));
// Sincronización periódica: solo con la app visible y con señal (no gasta datos en segundo plano)
setInterval(() => {
  if (peliculas.length && !document.hidden && navigator.onLine !== false) syncTodo();
}, 300000);

// Cuando la hoja ya cargó: reconcilia las marcas por id y sincroniza una vez
const esperaSync = setInterval(() => {
  if (!peliculas.length || !accessToken) return;
  clearInterval(esperaSync);
  construirMapaTitulos();
  if (migrarClaves()) refrescarTodo();
  syncTodo();
}, 500);

// Sale de la cuenta en este navegador y borra la copia local (no revoca el acceso de Google)
function salirDeEsteDispositivo() {
  if (syncPendiente && !confirm("Tienes cambios que aún no se subieron a tu Drive. Si sales ahora, se perderán en este dispositivo. ¿Continuar?")) return;
  syncBorrarLocal();
  marcas = envolverMarcas({});
  location.reload();
}
document.getElementById("salirDispositivo").addEventListener("click", salirDeEsteDispositivo);

/* --- bloque 12 --- */
(function () {
  const guia = document.getElementById("guia");

  const DESC_ZONAS = {
    lista: "Todas las películas, con búsqueda y filtros.",
    estrenos: "Recién estrenadas y próximas, según su fecha real.",
    sagas: "Sagas en orden, con tu progreso.",
    actores: "Actores con foto y biografía.",
    duelo: "Enfrenta dos películas y elige cuál ver.",
    resumen: "Tu resumen de la semana.",
    actividad: "Tu actividad y tus retos del mes.",
    mapa: "Tu mapa de gustos y de países.",
    descartadas: "Las películas que descartaste."
  };
  // Se arma leyendo el menú y las pestañas en el momento: lo que agregues aparece solo.
  function llenarGuiaAuto() {
    const cont = document.getElementById("guiaAuto");
    if (!cont) return;
    const esc2 = t => String(t).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    const zonas = (lista, titulo) => '<div class="seccion"><h3>' + titulo + '</h3><ul>' +
      lista.map(([k, n]) => '<li><b>' + esc2(n) + '</b>' + (DESC_ZONAS[k] ? ' — ' + esc2(DESC_ZONAS[k]) : '') + '</li>').join("") +
      '</ul></div>';
    let html = zonas(ZONAS_PELICULAS, "🎬 Pestañas de Películas") + zonas(ZONAS_VISTAS, "✓ Pestañas de Vistas");
    document.querySelectorAll("#panelAvanzados .grupo-menu, #panelMas .grupo-menu").forEach(g => {
      const titulo = (g.querySelector(".grupo-titulo") || {}).textContent || "";
      if (!titulo || /^Ayuda$/.test(titulo)) return;
      const botones = [...g.querySelectorAll("button[id]")];
      if (!botones.length) return;
      html += '<div class="seccion"><h3>' + esc2(titulo) + '</h3><ul>' + botones.map(b => {
        const texto = b.textContent.replace(/\s+/g, " ").trim();
        const desc = (typeof DESC_HERRAMIENTAS !== "undefined" && DESC_HERRAMIENTAS[b.id]) || "";
        return '<li><b>' + esc2(texto) + '</b>' + (desc ? ' — ' + esc2(desc) : '') + '</li>';
      }).join("") + '</ul></div>';
    });
    cont.innerHTML = html;
  }

  function abrirGuia() { llenarGuiaAuto(); guia.classList.add("abierta"); }
  function cerrarGuia() {
    guia.classList.remove("abierta");
    if (marcas.__guia !== 1) {
      marcas.__guia = 1;   // se guarda en las marcas de la cuenta, así vale en todos sus dispositivos
      programarGuardado();
    }
  }

  // Se llama cuando las marcas de la cuenta ya cargaron
  window.mostrarGuiaSiEsNueva = function () {
    if (marcas.__guia !== 1) abrirGuia();
  };

  document.getElementById("guiaCerrar").addEventListener("click", cerrarGuia);
  document.getElementById("guiaEntendido").addEventListener("click", cerrarGuia);
  guia.addEventListener("click", e => { if (e.target === guia) cerrarGuia(); });
  document.getElementById("verGuia").addEventListener("click", abrirGuia);
})();

/* --- bloque 13 --- */
(function () {
const CHAT_URL = "https://catalogo-chat.240300696.workers.dev";  const panel = document.getElementById("chatPanel");
  const lista = document.getElementById("chatMensajes");
  const form = document.getElementById("chatForm");
  const input = document.getElementById("chatInput");
  const enviar = document.getElementById("chatEnviar");
  let historial = [];
  let saludado = false;

  // Escribe el texto poco a poco, como si lo estuviera diciendo
  function escribirPoco(el, texto) {
    el.textContent = "";
    const paso = Math.max(2, Math.ceil(texto.length / 90));
    let i = 0;
    const tick = () => {
      i += paso;
      el.textContent = texto.slice(0, i);
      lista.scrollTop = lista.scrollHeight;
      if (i < texto.length) setTimeout(tick, 16); else el.textContent = texto;
    };
    tick();
  }

  function burbuja(texto, tipo) {
    const d = document.createElement("div");
    d.className = "chat-burbuja " + tipo;
    const visible = tipo === "ia" ? limpiarMarkdown(texto) : texto;
    lista.appendChild(d);
    if (tipo === "ia" && visible.length <= 600) {
      escribirPoco(d, visible);
    } else {
      d.textContent = visible;
    }
    lista.scrollTop = lista.scrollHeight;
    if (tipo === "ia") hablar(visible);
    return d;
  }

  /* ---------- Voz del asistente (síntesis del navegador, sin costo) ---------- */
  const vozSoportada = "speechSynthesis" in window && typeof SpeechSynthesisUtterance !== "undefined";
  const vozActiva = () => { try { return localStorage.getItem("chat_voz") !== "0"; } catch (e) { return true; } };

  // Quita el formato de Markdown que a veces devuelve la IA (**negritas**, *cursivas*, # títulos, viñetas)
  function limpiarMarkdown(texto) {
    return String(texto || "")
      .replace(/\*\*(.+?)\*\*/g, "$1")
      .replace(/__(.+?)__/g, "$1")
      .replace(/\*(.+?)\*/g, "$1")
      .replace(/`+/g, "")
      .replace(/^#+\s*/gm, "")
      .replace(/^\s*[-•*]\s+/gm, "• ")
      .replace(/\*/g, "")
      .trim();
  }

  function limpiarParaVoz(texto) {
    let t = String(texto || "")
      .replace(/\p{Extended_Pictographic}/gu, " ")
      .replace(/★/g, " estrellas")
      .replace(/[•«»"]/g, " ")
      .replace(/\((\d{4})\)/g, ", $1, ")
      .replace(/\b(\d+)\s*min\b\.?/g, "$1 minutos")
      .replace(/\s[—–-]\s/g, ", ")
      .replace(/…/g, ". ")
      .replace(/\s+([,.;:!?])/g, "$1")
      .replace(/\n+/g, ". ")
      .replace(/\s+/g, " ")
      .replace(/\.\s*\./g, ".")
      .trim();
    if (t.length > 450) {
      const corte = t.slice(0, 450);
      const punto = Math.max(corte.lastIndexOf(". "), corte.lastIndexOf("? "), corte.lastIndexOf("! "));
      t = punto > 150 ? corte.slice(0, punto + 1) : corte;
    }
    return t;
  }

  const NOMBRES_MUJER = /paulina|sabina|dalia|monica|mónica|helena|marisol|paloma|luciana|sofia|sofía|valeria|camila|female|mujer/i;
  const NOMBRES_HOMBRE = /jorge|diego|juan|carlos|pablo|raul|raúl|enrique|alonso|andres|andrés|male|hombre/i;
  const CALIDAD_VOZ = /natural|neural|premium|enhanced|google|mejorad|plus/i;

  const VELOCIDADES = { lento: 0.94, normal: 1.0, rapido: 1.12 };
  const velocidadVoz = () => {
    try { return VELOCIDADES[localStorage.getItem("chat_velocidad")] || VELOCIDADES.normal; } catch (e) { return VELOCIDADES.normal; }
  };

  const generoVoz = () => { try { return localStorage.getItem("chat_genero") || "mujer"; } catch (e) { return "mujer"; } };

  function puntuarVoz(v, genero) {
    let s = 0;
    if (/^es[-_]MX/i.test(v.lang)) s += 4; else if (/^es/i.test(v.lang)) s += 2;
    if (CALIDAD_VOZ.test(v.name)) s += 3;
    const esMujer = NOMBRES_MUJER.test(v.name), esHombre = NOMBRES_HOMBRE.test(v.name);
    if (genero === "mujer") { if (esMujer) s += 5; if (esHombre) s -= 5; }
    if (genero === "hombre") { if (esHombre) s += 5; if (esMujer) s -= 5; }
    return s;
  }

  function elegirVoz() {
    const vs = speechSynthesis.getVoices().filter(v => /^es/i.test(v.lang));
    if (!vs.length) return null;
    const g = generoVoz();
    const puntos = v => puntuarVoz(v, g) + (v.localService ? 0 : 2);
    return vs.slice().sort((a, b) => puntos(b) - puntos(a))[0];
  }

  // Las voces llegan con retraso: si aún no están, espera (máximo ~2 s) para no leer con la voz genérica
  function esperarVoces(ms = 2000) {
    return new Promise(resolver => {
      if (speechSynthesis.getVoices().length) return resolver();
      const t = setTimeout(resolver, ms);
      speechSynthesis.addEventListener("voiceschanged", () => { clearTimeout(t); resolver(); }, { once: true });
    });
  }

  // Agrupa frases en trozos de tamaño natural: sin pausas cortadas ni frases sueltas
  function trocearParaVoz(texto, max = 200) {
    const frases = (texto.match(/[^.!?;:]+[.!?;:]*/g) || [texto]).map(f => f.trim()).filter(Boolean);
    const trozos = [];
    let cur = "";
    frases.forEach(f => {
      if (cur && (cur + " " + f).length > max) { trozos.push(cur); cur = f; }
      else cur = cur ? cur + " " + f : f;
    });
    if (cur) trozos.push(cur);
    return trozos;
  }

  // Chrome deja de hablar después de ~15 s; un «resume» periódico lo evita
  let vozVigilante = null;
  function mantenerVoz() {
    clearInterval(vozVigilante);
    vozVigilante = setInterval(() => {
      if (!speechSynthesis.speaking) { clearInterval(vozVigilante); return; }
      speechSynthesis.resume();
    }, 10000);
  }

  // Expuestos para el saludo (que está fuera de este bloque)
  window.mantenerVoz = mantenerVoz;
  window.trocearParaVoz = trocearParaVoz;
  window.esperarVoces = esperarVoces;

  function hablar(texto, intento = 0) {
    if (!vozSoportada || !vozActiva()) return;
    const limpio = limpiarParaVoz(texto);
    if (!limpio) return;
    if (!speechSynthesis.getVoices().length && intento === 0) {
      esperarVoces().then(() => hablar(texto, 1));
      return;
    }
    if (escuchandoConv && recConv) { try { recConv.abort(); } catch (e) {} escuchandoConv = false; }
    speechSynthesis.cancel();
    hablarTrozos(trocearParaVoz(limpio), {
      velocidad: velocidadVoz(),
      alInicio: mantenerVoz,
      alFinal: () => {
        if (typeof conversacionActiva !== "undefined" && conversacionActiva && typeof escucharConv === "function") {
          setTimeout(() => escucharConv(), 350);
        }
      }
    });
  }

  if (vozSoportada) {
    speechSynthesis.addEventListener("voiceschanged", () => {});
  }

  const selectGenero = document.getElementById("chatGenero");
  const selectVelocidad = document.getElementById("chatVelocidad");
  if (selectVelocidad) {
    try { selectVelocidad.value = localStorage.getItem("chat_velocidad") || "normal"; } catch (e) { selectVelocidad.value = "normal"; }
    selectVelocidad.addEventListener("change", () => {
      try { localStorage.setItem("chat_velocidad", selectVelocidad.value); } catch (e) {}
      if (vozSoportada) speechSynthesis.cancel();
      hablar("Así es la velocidad que elegiste.");
    });
  }

  if (selectGenero) {
    selectGenero.value = generoVoz();
    selectGenero.addEventListener("change", () => {
      try { localStorage.setItem("chat_genero", selectGenero.value); } catch (e) {}
      if (vozSoportada) speechSynthesis.cancel();
      hablar("Así suena mi voz ahora.");
    });
  }

  function actualizarIconoVoz() {
    const b = document.getElementById("chatVozOn");
    if (!b) return;
    b.textContent = vozActiva() ? "🔊" : "🔇";
    b.setAttribute("aria-label", vozActiva() ? "Silenciar voz" : "Activar voz");
  }

  if (!vozSoportada) {
    const b = document.getElementById("chatVozOn");
    if (b) b.hidden = true;
  } else {
    speechSynthesis.getVoices();
    speechSynthesis.addEventListener("voiceschanged", () => {});
    actualizarIconoVoz();
  }

  document.getElementById("chatVozOn").addEventListener("click", () => {
    const nuevo = vozActiva() ? "0" : "1";
    try { localStorage.setItem("chat_voz", nuevo); } catch (e) {}
    if (nuevo === "0" && vozSoportada) speechSynthesis.cancel();
    actualizarIconoVoz();
  });

  // Presentación completa: solo la primera vez que se usa el asistente en este navegador
  function presentacionCompleta() {
    burbuja("Hola" + (nombreUsuario() ? ", " + nombreUsuario() : "") + ". Soy " + NOMBRE_COMPA + ", y me encanta platicar de cine contigo. Puedo ayudarte a elegir qué ver, recordar qué tienes pendiente o contarte cómo va tu semana. Pregúntame lo que quieras.", "ia");
    burbuja("Tus marcas, notas y preferencias son solo tuyas. Las preguntas, tus preferencias y los datos de tu lista se envían a Gemini a través del script del administrador. Si aparece «código 429», se agotó la cuota diaria compartida; vuelve mañana.", "ia");
  }

  // Preguntas por momento del día; no repite la última
  const PREGUNTAS_SALUDO = {
    manana: ["¿Qué te apetece ver hoy?", "¿Quieres algo corto para empezar el día?", "¿Revisamos tus pendientes para hoy?"],
    tarde: ["¿Te antoja algo para la tarde?", "¿Vemos algo nuevo o retomamos un pendiente?", "¿Te recomiendo algo según tu ánimo?"],
    noche: ["¿Qué vemos esta noche?", "¿Te armo una maratón según el tiempo que tengas?", "¿Empezamos algo de tu lista hoy?"],
    general: ["¿Qué tal si elegimos algo de tus pendientes?", "¿Te cuento qué tienes por ver esta semana?"]
  };

  function franjaDelDia() {
    const h = new Date().getHours();
    return h < 12 ? "manana" : h < 19 ? "tarde" : "noche";
  }

  function saludoBreve() {
    const h = new Date().getHours();
    const franja = h < 12 ? "manana" : h < 19 ? "tarde" : "noche";
    const saludo = h < 12 ? "Buenos días" : h < 19 ? "Buenas tardes" : "Buenas noches";
    const pool = PREGUNTAS_SALUDO[franja].concat(PREGUNTAS_SALUDO.general);
    let ultima = null;
    try { ultima = localStorage.getItem("chat_pregunta_ultima"); } catch (e) {}
    const candidatas = pool.filter(q => q !== ultima);
    const pregunta = candidatas[Math.floor(Math.random() * candidatas.length)];
    try { localStorage.setItem("chat_pregunta_ultima", pregunta); } catch (e) {}
    const nombre = nombreUsuario();
    return saludo + (nombre ? ", " + nombre : "") + ". " + pregunta;
  }

  function saludar() {
    if (saludado) return;
    saludado = true;
    let primera = false;
    try { primera = localStorage.getItem("chat_presentado") !== "1"; } catch (e) {}
    if (primera) {
      presentacionCompleta();
      try { localStorage.setItem("chat_presentado", "1"); } catch (e) {}
      return;
    }
    burbuja(saludoBreve(), "ia");
  }
  function catalogoParaIA(textoPregunta = "") {
    const base = seleccionParaIA(textoPregunta).map(p => {
      const e = estadoDe(p);
      return {
        titulo: p.titulo, año: p["año"], tipo: p.tipo,
        genero: p.genero, director: p.director, duracion: p.duracion,
        reparto: String(p.reparto || "").split(",").slice(0, 3).map(x => x.trim()).filter(Boolean).join(", "),
        vista: e.vista, pendiente: e.pendiente, estrellas: e.estrellas, conAlguien: e.conAlguien
      };
    });
    if (notas.length) base.unshift({ preferencias_del_usuario: notas });
    if (memoriaGustosActiva()) base.unshift({ gustos_del_usuario: resumenGustos() });
    if (window.seriesApi) {
      const S = window.seriesApi;
      const resumen = S.lista().slice(0, 40).map(s => {
        const pr = S.progreso(s);
        return { titulo: s.titulo, genero: s.genero_principal, año: s.año,
          capitulos_vistos: pr.vistos + "/" + pr.total,
          siguiente: pr.siguiente ? "T" + pr.siguiente.temporada + "E" + pr.siguiente.episodio : "ninguno" };
      });
      if (resumen.length) base.unshift({ series_del_usuario: resumen });
    }
    return base;
  }

  // ----- Memoria de gustos: se deriva de tus calificaciones y marcas, sin guardar nada extra -----
  function memoriaGustosActiva() {
    try { return localStorage.getItem("gustos_memoria") !== "no"; } catch (e) { return true; }
  }

  function resumenGustos() {
    const perfil = perfilGustos();
    const top = obj => Object.entries(obj).sort((a, b) => b[1] - a[1]).slice(0, 3).map(x => x[0]);
    const gustaron = peliculas.filter(p => { const e = estadoDe(p); return e.vista && e.estrellas >= 4; }).slice(0, 8).map(p => p.titulo);
    const noGustaron = peliculas.filter(p => { const e = estadoDe(p); return e.vista && e.estrellas && e.estrellas <= 2; }).slice(0, 8).map(p => p.titulo);
    const descartadas = peliculas.filter(p => (marcas[p.titulo] || {}).descartada).slice(0, 8).map(p => p.titulo);
    return {
      generos_que_mas_disfruta: top(perfil.genero),
      directores_que_mas_disfruta: top(perfil.director),
      peliculas_que_le_gustaron: gustaron,
      peliculas_que_no_le_gustaron: noGustaron,
      descartadas: descartadas,
      instruccion: "Usa estos gustos para elegir y explica en una frase por qué recomiendas cada título. No recomiendes lo que no le gustó ni lo descartado."
    };
  }

  function listaCampo(p, campo) {
    return String(p[campo] || "").split(",").map(x => x.trim()).filter(Boolean);
  }

  function recomendarSinIA(n = 3) {
    if (!peliculas.length) return "Primero necesito que tu catálogo cargue.";
    const perfil = { genero: {}, director: {}, reparto: {} };
    const sumar = (mapa, claves, peso) => claves.forEach(c => { mapa[c] = (mapa[c] || 0) + peso; });

    // Lo que ya viste pesa según tus estrellas (sin calificar cuenta como 1)
    peliculas.forEach(p => {
      const e = estadoDe(p);
      if (!e.vista) return;
      const peso = e.estrellas || 1;
      sumar(perfil.genero, listaCampo(p, "genero"), peso);
      sumar(perfil.director, listaCampo(p, "director"), peso);
      sumar(perfil.reparto, listaCampo(p, "reparto").slice(0, 5), peso);
    });

    const candidatos = peliculas.filter(p => {
      const m = marcas[p.titulo] || {};
      return !estadoDe(p).vista && !m.descartada;
    }).map(p => {
      const e = estadoDe(p);
      const porGenero = listaCampo(p, "genero").filter(g => perfil.genero[g]);
      const porDirector = listaCampo(p, "director").filter(d => perfil.director[d]);
      const porReparto = listaCampo(p, "reparto").slice(0, 5).filter(r => perfil.reparto[r]);
      let score = 0;
      porGenero.forEach(g => score += perfil.genero[g]);
      porDirector.forEach(d => score += perfil.director[d] * 2);
      porReparto.forEach(r => score += perfil.reparto[r]);
      if (e.pendiente) score += 1;
      return { p, score, porGenero, porDirector, porReparto };
    }).sort((a, b) => b.score - a.score);

    const elegidos = candidatos.filter(c => c.score > 0).slice(0, n);
    if (!elegidos.length) return "Aún no tengo suficientes datos de tus gustos. Marca algunas películas como vistas y vuelve a intentar.";

    const lineas = elegidos.map(c => {
      const motivos = [];
      if (c.porDirector.length) motivos.push("dirigida por " + c.porDirector[0]);
      if (c.porGenero.length) motivos.push("del género " + c.porGenero.slice(0, 2).join(" y ").toLowerCase());
      if (c.porReparto.length) motivos.push("con " + c.porReparto[0]);
      const año = c.p["año"] ? " (" + c.p["año"] + ")" : "";
      return "• " + c.p.titulo + año + (motivos.length ? ": " + motivos.join(", ") : "");
    });
    return "Según tus gustos, sin usar IA:\n\n" + lineas.join("\n");
  }

  function titulosEnTexto(texto) {
    const t = String(texto || "").toLowerCase();
    const hallados = [];
    peliculas.forEach(p => {
      const titulo = String(p.titulo || "").toLowerCase();
      if (titulo.length < 2) return;
      const pos = t.indexOf(titulo);
      if (pos !== -1) hallados.push({ p, pos });
    });
    hallados.sort((a, b) => a.pos - b.pos);
    const unicos = [];
    hallados.forEach(h => { if (!unicos.includes(h.p)) unicos.push(h.p); });
    return unicos.slice(0, 4);
  }

  function mostrarPosters(texto) {
    const lista_ = titulosEnTexto(texto);
    if (!lista_.length) return;
    const fila = document.createElement("div");
    fila.className = "chat-posters";
    const sinDatos = typeof datosLimitados === "function" && datosLimitados();
    lista_.forEach(p => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "chat-poster";
      b.title = p.titulo;
      const img = (p.portada && !sinDatos)
        ? (() => { const i = document.createElement("img"); i.src = p.portada; i.alt = ""; i.loading = "lazy"; return i; })()
        : (() => { const d = document.createElement("div"); d.className = "chat-sinposter"; d.textContent = "🎬"; return d; })();
      const etiqueta = document.createElement("span");
      etiqueta.textContent = p.titulo + (p["año"] ? " (" + p["año"] + ")" : "");
      b.append(img, etiqueta);
      b.addEventListener("click", () => { if (typeof abrirDetalle === "function") abrirDetalle(p); });

      // Botones rápidos: marcar sin escribir comandos
      const acciones = document.createElement("div");
      acciones.className = "chat-marcar";
      const btnVista = document.createElement("button");
      btnVista.type = "button";
      const btnPend = document.createElement("button");
      btnPend.type = "button";
      const pintarEstado = () => {
        const e = estadoDe(p);
        btnVista.textContent = e.vista ? "✓ Vista" : "Vista";
        btnVista.classList.toggle("activo", e.vista);
        btnVista.disabled = e.vista;
        btnPend.textContent = e.pendiente ? "✓ Pendiente" : "Pendiente";
        btnPend.classList.toggle("activo", e.pendiente);
        btnPend.disabled = e.pendiente;
      };
      btnVista.addEventListener("click", () => {
        cambiarEstado(p.titulo, { vista: true });
        if (typeof refrescarTodo === "function") refrescarTodo();
        burbuja("Listo: «" + p.titulo + "» marcada como vista.", "ia");
        pintarEstado();
      });
      btnPend.addEventListener("click", () => {
        cambiarEstado(p.titulo, { pendiente: true, vista: false });
        if (typeof refrescarTodo === "function") refrescarTodo();
        burbuja("Listo: «" + p.titulo + "» quedó en pendientes.", "ia");
        pintarEstado();
      });
      pintarEstado();
      acciones.append(btnVista, btnPend);

      const col = document.createElement("div");
      col.className = "chat-poster-col";
      col.append(b, acciones);
      fila.appendChild(col);
    });
    lista.appendChild(fila);
    lista.scrollTop = lista.scrollHeight;
  }

  // Dictado: llena el campo para que revises antes de enviar. Siempre visible, con aviso de lo que pasa.
  (function () {
    const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
    const vozBtn = document.getElementById("chatVoz");
    if (!vozBtn) return;
    vozBtn.hidden = false;
    if (!Rec) {
      vozBtn.addEventListener("click", () => avisar("Tu navegador no tiene dictado. Prueba con Chrome o Edge."));
      return;
    }
    const rec = new Rec();
    rec.lang = "es-MX";
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    let llegoTexto = false;
    rec.onstart = () => { vozBtn.classList.add("escuchando"); input.placeholder = "Escuchando… habla ahora"; };
    rec.onresult = e => {
      const t = (e.results[0] && e.results[0][0] && e.results[0][0].transcript || "").trim();
      if (t) { llegoTexto = true; input.value = t; input.focus(); avisar("Revisa el texto y pulsa enviar."); }
    };
    const limpiar = () => { vozBtn.classList.remove("escuchando"); input.placeholder = "Pregúntame sobre tu catálogo…"; };
    rec.onend = () => {
      limpiar();
      if (!llegoTexto) avisar("No entendí. Intenta de nuevo, hablando cerca del micrófono.");
      llegoTexto = false;
    };
    rec.onerror = e => {
      limpiar();
      const msg = {
        "not-allowed": "Permite el micrófono en el navegador (toca el candado de la barra de direcciones).",
        "service-not-allowed": "Permite el micrófono en el navegador para usar el dictado.",
        "no-speech": "No escuché nada. Intenta de nuevo.",
        "network": "El dictado necesita conexión a internet.",
        "audio-capture": "No encuentro un micrófono conectado."
      }[e.error] || "No pude usar el dictado. Intenta de nuevo.";
      avisar(msg);
    };
    vozBtn.addEventListener("click", () => {
      if (vozBtn.classList.contains("escuchando")) { rec.stop(); return; }
      llegoTexto = false;
      vozBtn.classList.add("escuchando");
      avisar("Escuchando… habla ahora.");
      try { rec.start(); }
      catch (e) { avisar("Espera un segundo y vuelve a pulsar el micrófono."); }
    });
  })();

  // Consultas con IA por persona al día. Al llegar al límite, el chat pasa solo a modo sin IA.
  const fondoChat = document.createElement("div");
  fondoChat.id = "chatFondo";
  document.body.appendChild(fondoChat);
  // Panel y botón se llevan a la raíz de la página: así siempre quedan encima del fondo y reciben los toques
  document.body.appendChild(panel);
  const tableroChat = document.createElement("div");
  tableroChat.id = "chatTablero";
  tableroChat.className = "chat-tablero";
  const usoChat = document.getElementById("chatUso");
  if (usoChat) usoChat.insertAdjacentElement("afterend", tableroChat);
  const botonAbrirChat = document.getElementById("chatAbrir");
  if (botonAbrirChat) document.body.appendChild(botonAbrirChat);
  fondoChat.addEventListener("click", () => {
    panel.classList.remove("abierto");
    fondoChat.classList.remove("visible");
    if (vozSoportada) speechSynthesis.cancel();
    detenerEscuchaConv();
  });

  const LIMITE_IA_PERSONAL_DIA = 20;
  let avisoOffline = false;
  let usoGrupo = null;

  function pintarUso(u) {
    if (!u || !u.limite) return;
    usoGrupo = u;
    const el = document.getElementById("chatUso");
    if (!el) return;
    const pct = Math.min(100, Math.round(u.hoy / u.limite * 100));
    el.textContent = "Uso del grupo hoy: " + pct + "% (" + u.hoy + " de " + u.limite + " consultas con IA). Se reinicia en " + tiempoParaReinicio() + ".";
    el.classList.toggle("alerta", pct >= 80);
    el.hidden = false;
  }

  async function consultarUso() {
    if (!accessToken) return;
    try {
      const r = await fetch(CHAT_URL, {
        method: "POST",
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify({ token: accessToken, accion: "uso" })
      });
      const j = await r.json();
      if (j.uso) pintarUso(j.uso);
    } catch (e) {}
  }

  // Cambio automático a modo sin IA, avisando una sola vez en el chat
  function caeASinIA(motivo, pregunta) {
    if (pregunta) {
      burbuja(motivo + "\n\nTe ayudo igual, sin IA:", "ia");
      responderLocal(pregunta);
      return;
    }
    burbuja(motivo + "\n\nSeguimos en modo sin IA. Pregúntame lo que quieras.", "ia");
  }

  // Identidad del compañero: cámbialo aquí y en SISTEMA_CHAT del Apps Script
  const NOMBRE_COMPA = "Estela";
  // Nombre del usuario, si lo guardó con «recuerda que me llamo …»
  function nombreUsuario() {
    const guardado = nombreGuardado();
    if (guardado) return guardado;
    for (const n of notas) {
      const m = String(n).match(/me llamo\s+([A-Za-zÁÉÍÓÚáéíóúÑñ]+)/i);
      if (m) return m[1].charAt(0).toUpperCase() + m[1].slice(1).toLowerCase();
    }
    return null;
  }

  const normalizarChat = t => String(t || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
  // Sinónimos del habla cotidiana (México): se traducen a las frases que el asistente ya entiende
  const expandirChat = s => s
    .replace(/\b(pelis?|filmes?|cintas?|movies?)\b/g, "pelicula")
    .replace(/\b(dame algo|recomiendame|recomiendame algo|que me recomiendas|que me sugieres|me sugieres|sugierem|sugiereme)\b/g, "sugiereme algo")
    .replace(/\b(quiero reir|tengo ganas de reir|me quiero reir|morir de risa|reirme un rato)\b/g, "para reirme")
    .replace(/\b(quiero llorar|para llorar|llorar un rato)\b/g, "triste")
    .replace(/\b(no se que ver|no se que pongo|que pongo|que me pongo)\b/g, "que veo")
    .replace(/\b(sin pensar|sin complicarme|algo ligero|algo light)\b/g, "relajado")
    .replace(/\b(hay algo bueno|algo bueno)\b/g, "algo bueno");
  const elegir = arr => arr[Math.floor(Math.random() * arr.length)];
  const listaTitulos = arr => arr.slice(0, 5).map(p => "• " + p.titulo + (p["año"] ? " (" + p["año"] + ")" : "")).join("\n");
  const pendientesDe = () => peliculas.filter(p => estadoDe(p).pendiente && !(marcas[p.titulo] || {}).descartada);
  const vistasDe = () => peliculas.filter(p => estadoDe(p).vista);

  // ----- Recomendador local con memoria de la sesión -----
  const sesionSugeridas = new Set();
  // ----- Estela: calidez, empatía y memoria de la charla -----
  let ultimaEmocion = null;
  const CRISIS_RE = /suicid|quitarme la vida|quitarme la existencia|matarme|no quiero (seguir )?vivir|ya no quiero vivir|hacerme dano|lastimarme|autolesi|acabar con mi vida|terminar con mi vida/;
  const ANIMO_PIDE = /quiero algo|algo que|dame algo|recomiend|sugier|propon|necesito algo|algo para|que veo|pon algo/;
  const ANIMO_SIENTE = /\b(estoy|me siento|siento|ando|me encuentro|me pone|me pongo|me acuerdo|me recuerdo|extrano|me da)\b/;
  const EMOCIONES = [
    { tipo: "triste", razon: "para acompañarte con algo amable", re: /triste|tristeza|bajon|melancol|deprim|llorar|mala racha|dia gris/, gen: ["comedia", "animacion", "familia", "drama"],
      intros: ["Ay, lo siento. Cuando el ánimo anda bajito, conviene algo que abrace un poco.", "Lamento que estés así. Vamos a buscarte algo amable, sin prisa."],
      charla: "Lamento que estés así. ¿Quieres que te proponga algo para acompañarte un rato, o prefieres contarme qué pasó?" },
    { tipo: "cansado", razon: "para desconectarte sin pensar mucho", re: /cansad|agotad|estresad|estres|rendid|dia pesado|muy pesado/, gen: ["comedia", "animacion", "familia"],
      intros: ["Qué día tan pesado. Lo mejor es algo que te deje descansar la cabeza.", "Te entiendo: a veces solo toca desconectarse un rato."],
      charla: "Qué cansancio. ¿Te propongo algo ligero para desconectarte, o prefieres platicar un poco?" },
    { tipo: "aburrido", razon: "para sacudirte el aburrimiento", re: /aburrid|aburrir|sin ganas|nada que hacer/, gen: ["accion", "aventura", "suspenso", "ciencia"],
      intros: ["Ese aburrimiento se quita rápido. Mira qué te propongo:", "Vamos a sacudir ese aburrimiento:"],
      charla: "Ese aburrimiento tiene cura. ¿Quieres algo intenso o algo divertido?" },
    { tipo: "solo", razon: "para hacerte compañía", re: /me siento solo|me siento sola|estoy solo|estoy sola|soledad/, gen: ["comedia", "romance", "familia", "animacion"],
      intros: ["Una buena película también puede hacer compañía. Te propongo algo para sentirte acompañado:"],
      charla: "Me alegra que me lo cuentes. ¿Quieres que te proponga algo para acompañarte un rato?" },
    { tipo: "feliz", razon: "para mantener esa buena vibra", re: /estoy feliz|me siento feliz|contento|contenta|emocionad|de buen humor|de buen animo/, gen: ["comedia", "aventura", "musical", "animacion"],
      intros: ["¡Qué buena vibra! Vamos a mantenerla:"],
      charla: "¡Qué gusto leer eso! ¿Quieres que la celebremos con una peli?" },
    { tipo: "nervioso", razon: "para distraerte sin asustarte", re: /nervios|ansios|ansiedad|preocupad|angustia|alterad/, gen: ["comedia", "animacion", "familia"],
      intros: ["Respira un poco. Vamos con algo que te distraiga sin asustarte:"],
      charla: "Respira un poco. ¿Quieres algo tranquilo para distraerte?" },
    { tipo: "nostalgia", razon: "por su sabor a recuerdos", re: /nostalg|extrano a|extrano mi|recuerdos|de nino|de nina|de chico|de chica|cuando era/, gen: ["drama", "romance", "familia", "comedia"], anioMax: 2005,
      intros: ["La nostalgia tiene su encanto. Te propongo algo con sabor a recuerdos:"],
      charla: "La nostalgia puede ser muy bonita. ¿Quieres que te proponga algo de esos recuerdos?" },
    { tipo: "consuelo", razon: "para arroparte un rato", re: /abrace|abrazo|abrazar|consol|arrop|reconfort|algo tierno|me cuide|cuidarme/, gen: ["comedia", "animacion", "familia", "drama"],
      intros: ["Claro, algo que abrace un poco:", "Va, algo tierno para arroparte:"],
      charla: "Claro, te acompaño. ¿Quieres que te proponga algo tierno para arroparte un rato?" },
    { tipo: "dolor", razon: "porque a veces una historia ayuda a desahogarse", re: /corazon roto|me dejo|termine con|termino conmigo|desamor|ruptura|me engano/, gen: ["drama", "romance", "comedia"],
      intros: ["Lamento que estés pasando por eso. A veces una historia ayuda a sacar lo que duele:"],
      charla: "Lamento que te sientas así. ¿Quieres que te proponga algo para desahogarte viendo una historia?" }
  ];
  const ESTILO_IA = "cálido y natural, como una amiga cinéfila que platica en español de México; frases cortas y fluidas; sin listas robóticas salvo que pida una lista; si cuenta cómo se siente, responde primero con empatía; máximo cuatro frases salvo que pida más; nunca inventes títulos";

  function textoCrisis() {
    return "Gracias por contarme esto. Lo que sientes importa, y no tienes que cargarlo solo.\n\n" +
      "Si estás en peligro o sientes que podrías hacerte daño, llama al 911 ahorita mismo, o a la Línea de la Vida al 800 911 2000, que atiende las 24 horas.\n\n" +
      "Si puedes, háblale ya a alguien de tu confianza y dile que no quieres estar solo con esto. Yo soy una app de cine: no puedo acompañarte como lo haría una persona, pero quiero que estés bien. ¿Hay alguien cerca de ti ahorita?";
  }

  function momentoDia() {
    const h = new Date().getHours();
    return h < 12 ? "mañana" : h < 19 ? "tarde" : "noche";
  }

  // Artículo correcto para cada género: «la animación», «el drama»
  function articuloGenero(g) {
    const fem = /^(comedia|accion|animacion|aventura|ciencia|familia|fantasia|historia|musica|romantica|guerra|biografia|epica|intriga)/.test(normalizarChat(g));
    return (fem ? "la " : "el ") + String(g).toLowerCase();
  }

  // Perfil de gustos como texto legible para la IA (antes se enviaba «[object Object]»)
  function perfilTexto() {
    const perfil = perfilGustos();
    const top = obj => Object.entries(obj).sort((a, b) => b[1] - a[1]).slice(0, 3).map(x => x[0]);
    const g = top(perfil.genero), d = top(perfil.director);
    const partes = [];
    if (g.length) partes.push("géneros que más le gustan: " + g.join(", "));
    if (d.length) partes.push("directores que más le gustan: " + d.join(", "));
    return partes.length ? partes.join("; ") : "aún sin gustos claros";
  }

  function emocionEncaja(p, e) {
    const gens = generosDe(p).map(g => normalizarChat(g));
    const genOk = gens.some(g => e.gen.some(x => g.includes(x)));
    const anioOk = !e.anioMax || (Number(p["año"]) && Number(p["año"]) <= e.anioMax);
    return genOk && anioOk;
  }

  function sugerenciaEmocional(e) {
    const filtro = p => emocionEncaja(p, e);
    const texto = sugerirLocal(filtro, 2, e.razon) || sugerirLocal(p => emocionEncaja(p, Object.assign({}, e, { anioMax: null })), 2, e.razon) || sugerirLocal(null, 2, e.razon);
    ultimoFiltro = filtro;
    if (!texto) return "Ya te propuse todo lo que encaja con tu lista. Marca algunas más como vistas y afino las sugerencias.";
    return elegir(e.intros) + "\n\n" + texto + "\n\n¿Cuál te late?";
  }

  // Respuesta cálida a cómo se siente la persona (sin internet)
  function respuestaEmocional(n) {
    // Un «sí» corto después de una charla emocional trae la propuesta
    const afirma = /^(si|sip|sí|claro|dale|va|ok|orale|simon|por favor)\b/.test(n) && n.split(" ").length <= 3;
    if (ultimaEmocion && afirma) { const e = ultimaEmocion; ultimaEmocion = null; return sugerenciaEmocional(e); }
    if (ultimaEmocion && !ANIMO_SIENTE.test(n)) ultimaEmocion = null; // cambió de tema
    if (n.length > 160 || /pelicula|peli|filme|cinta|serie|director|actor|dirigi|reparto/.test(n)) return null;
    // Si pide un género concreto de su catálogo, manda la búsqueda normal
    if (generosCatalogo().some(g => n.includes(normalizarChat(g)))) return null;
    const e = EMOCIONES.find(x => x.re.test(n));
    if (!e || !(ANIMO_SIENTE.test(n) || ANIMO_PIDE.test(n))) return null;
    if (ANIMO_PIDE.test(n)) { ultimaEmocion = null; return sugerenciaEmocional(e); }
    ultimaEmocion = e;
    return e.charla;
  }

  function seleccionParaIA(texto) {
    // Solo se envían las películas que sirven para responder: el catálogo completo pesa mucho y vuelve lenta la respuesta
    const LIMITE = 320;
    if (peliculas.length <= LIMITE) return peliculas;
    const e = p => estadoDe(p);
    const pend = peliculas.filter(p => e(p).pendiente && !e(p).vista);
    const vistas = peliculas.filter(p => e(p).vista).slice(-40);
    const sinMarcar = peliculas.filter(p => !e(p).vista && !e(p).pendiente);
    const palabras = normalizarChat(texto).split(/\s+/).filter(w => w.length > 3);
    const coincide = p => { const txt = normalizarChat([p.titulo, p.genero, p.director, p.reparto].join(" ")); return palabras.some(w => txt.includes(w)); };
    const perfil = perfilGustos();
    const porGusto = sinMarcar.map(p => ({ p, s: puntuar(p, perfil) })).sort((a, b) => b.s - a.s).slice(0, 100).map(x => x.p);
    const porPregunta = palabras.length ? sinMarcar.filter(coincide).slice(0, 80) : [];
    const mezcla = [...pend.slice(0, 140), ...vistas, ...porPregunta, ...porGusto];
    const vistos = new Set();
    return mezcla.filter(p => { if (vistos.has(p.titulo)) return false; vistos.add(p.titulo); return true; }).slice(0, LIMITE);
  }

  let ultimoFiltro = null;
  let ultimasSugeridas = [];

  function perfilGustos() {
    const perfil = { genero: {}, director: {} };
    vistasDe().forEach(p => {
      const peso = estadoDe(p).estrellas || 1;
      generosDe(p).forEach(g => { perfil.genero[g] = (perfil.genero[g] || 0) + peso; });
      directoresDe(p).forEach(d => { perfil.director[d] = (perfil.director[d] || 0) + peso; });
    });
    // Tus votos A/B también cuentan: la película elegida suma a sus géneros y director
    leerVotos().forEach(t => {
      const p = peliculas.find(x => x.titulo === t);
      if (!p) return;
      generosDe(p).forEach(g => { perfil.genero[g] = (perfil.genero[g] || 0) + 1.5; });
      directoresDe(p).forEach(d => { perfil.director[d] = (perfil.director[d] || 0) + 1; });
    });
    return perfil;
  }

  // ----- Votos A/B -----
  function leerVotos() {
    try { return JSON.parse(localStorage.getItem("votos_gustos") || "[]"); } catch (e) { return []; }
  }
  function guardarVoto(titulo) {
    const v = leerVotos();
    v.push(titulo);
    try { localStorage.setItem("votos_gustos", JSON.stringify(v.slice(-60))); } catch (e) {}
  }

  function votacionAB() {
    const pool = peliculas.filter(p => !estadoDe(p).vista && !(marcas[p.titulo] || {}).descartada);
    if (pool.length < 2) { burbuja("Necesito al menos dos películas sin ver para votar.", "ia"); return; }
    const a = pool[Math.floor(Math.random() * pool.length)];
    let b = a;
    while (b === a) b = pool[Math.floor(Math.random() * pool.length)];
    burbuja("Te doy dos al azar. ¿Cuál te late más?", "ia");
    const fila = document.createElement("div");
    fila.className = "chat-acciones chat-votos";
    const elegirA = crearBoton("A · " + a.titulo, true, () => { fila.remove(); guardarVoto(a.titulo); burbuja("Anotado: " + a.titulo + ". Ya cuenta para tus gustos.", "ia"); });
    const elegirB = crearBoton("B · " + b.titulo, true, () => { fila.remove(); guardarVoto(b.titulo); burbuja("Anotado: " + b.titulo + ". Ya cuenta para tus gustos.", "ia"); });
    const ninguna = crearBoton("Ninguna", false, () => { fila.remove(); burbuja("Va, otra vez cuando quieras.", "ia"); });
    fila.append(elegirA, elegirB, ninguna);
    lista.appendChild(fila);
    lista.scrollTop = lista.scrollHeight;
  }

  // ----- Racha de semanas con al menos una película vista -----
  function lunesDe(d) {
    const dia = (d.getDay() + 6) % 7;
    const m = new Date(d);
    m.setDate(d.getDate() - dia);
    return isoLocal(m);
  }
  function rachaSemanas() {
    const semanas = new Set();
    let vistasSemana = 0;
    const lunesEsta = lunesDe(new Date());
    peliculas.forEach(p => ((marcas[p.titulo] || {}).historial || []).forEach(h => {
      if (h.a !== "vista") return;
      semanas.add(lunesDe(new Date(h.f + "T12:00:00")));
      if (String(h.f) >= lunesEsta) vistasSemana++;
    }));
    let cursor = new Date(lunesEsta + "T12:00:00");
    if (!semanas.has(lunesEsta)) cursor = new Date(cursor.getTime() - 7 * 86400000);
    let racha = 0;
    while (semanas.has(lunesDe(cursor))) { racha++; cursor = new Date(cursor.getTime() - 7 * 86400000); }
    return { racha: racha, vistasSemana: vistasSemana };
  }

  // ----- Tablero del asistente: modo, racha y vistas de la semana -----
  function pintarTablero() {
    const t = document.getElementById("chatTablero");
    const orbe = document.getElementById("chatAbrir");
    const local = modoSinIAActivo();
    if (orbe) { orbe.classList.toggle("modo-ia", !local); orbe.classList.toggle("modo-local", local); }
    if (!t) return;
    const r = rachaSemanas();
    t.innerHTML = "";
    [
      [local ? "Sin IA" : "Con IA", local ? "local" : "ia"],
      ["🔥 " + r.racha + (r.racha === 1 ? " semana" : " semanas") + " de racha", ""],
      ["✓ " + r.vistasSemana + " esta semana", ""]
    ].forEach(function (par) {
      const pill = document.createElement("span");
      pill.className = "tablero-pill " + par[1];
      pill.textContent = par[0];
      t.appendChild(pill);
    });
  }


  function puntuar(p, perfil) {
    let s = 0;
    generosDe(p).forEach(g => { s += perfil.genero[g] || 0; });
    directoresDe(p).forEach(d => { s += (perfil.director[d] || 0) * 2; });
    if (estadoDe(p).pendiente) s += 1;
    return s;
  }

  function razonDe(p, perfil) {
    const dir = directoresDe(p).find(d => perfil.director[d]);
    if (dir) return elegir(["porque ya te gustó algo de " + dir, "porque " + dir + " te ha gustado antes"]);
    const gen = generosDe(p).find(g => perfil.genero[g]);
    if (gen) return elegir(["porque te gusta " + articuloGenero(gen), "porque " + articuloGenero(gen) + " está entre tus géneros favoritos"]);
    return elegir(["porque está en tu lista y todavía no la has visto", "porque quedó pendiente y tiene buena pinta para ti"]);
  }

  // Razón para una recomendación de género: concreta, y no la misma frase en toda la lista
  function razonGenero(p, g, perfil) {
    const dir = directoresDe(p).find(d => perfil.director[d]);
    if (dir) return elegir(["porque es de " + g + " y ya te gustó algo de " + dir, "porque es de " + g + " y va por la línea de " + dir]);
    return elegir(["porque es justo de " + g + ", como pediste", "porque es de " + g + " y todavía no la has visto"]);
  }

  // Reparte razones distintas dentro de una misma lista (si sale repetida, vuelve a intentar)
  function razonUnica(p, perfil, razonFija, usadas) {
    const dar = () => typeof razonFija === "function" ? razonFija(p, perfil) : (razonFija || razonDe(p, perfil));
    let r = dar();
    for (let k = 0; k < 6 && usadas.has(r); k++) r = dar();
    usadas.add(r);
    return r;
  }

  function sugerirLocal(filtro, n = 2, razonFija = null) {
    const perfil = perfilGustos();
    const candidatos = peliculas
      .filter(p => !estadoDe(p).vista && !(marcas[p.titulo] || {}).descartada && !sesionSugeridas.has(p.titulo) && (!filtro || filtro(p)))
      .map(p => ({ p, s: puntuar(p, perfil) }))
      .sort((a, b) => b.s - a.s);
    if (!candidatos.length) return null;
    const elegidos = candidatos.slice(0, n).map(c => c.p);
    elegidos.forEach(p => sesionSugeridas.add(p.titulo));
    ultimasSugeridas = elegidos;
    const usadas = new Set();
    return elegidos.map(p => "• " + p.titulo + (p["año"] ? " (" + p["año"] + ")" : "") + ": " + razonUnica(p, perfil, razonFija, usadas)).join("\n");
  }

  const animosLocal = [
    { re: /triste|melancolic|deprim|bajon|llorar/, gen: ["animacion", "comedia", "familia", "drama"], intro: "Para ese ánimo, algo que abrace un poco:" },
    { re: /aburrid|flojo|sin ganas/, gen: ["accion", "aventura", "ciencia ficcion", "suspenso"], intro: "Para sacudirte el aburrimiento:" },
    { re: /miedo|susto|escalof/, gen: ["terror", "suspenso"], intro: "Si buscas que se te pare el corazón:" },
    { re: /romant|enamorad|pareja|cita/, gen: ["romance", "comedia romantica", "drama"], intro: "Para una noche romántica:" },
    { re: /relaj|tranquil|cansad|estresad/, gen: ["comedia", "animacion", "familia"], intro: "Para desconectar sin pensar mucho:" },
    { re: /feliz|contento|emocionad|alegr/, gen: ["comedia", "aventura", "musical"], intro: "Para mantener esa energía:" }
  ];

  function respuestaSugerencia(intro, filtro, razon = null) {
    ultimoFiltro = filtro;
    ultimasSeriesSugeridas = [];
    const texto = sugerirLocal(filtro, 2, razon);
    if (!texto) {
      const hayAlgo = peliculas.some(p => !estadoDe(p).vista && !(marcas[p.titulo] || {}).descartada && (!filtro || filtro(p)));
      return hayAlgo
        ? "Ya te propuse todo lo que encaja con tu lista. Marca algunas películas más como vistas y afino las sugerencias."
        : "Con ese criterio no me sale nada en tu lista ahorita. ¿Probamos con más tiempo, quitando el año o con otro género?";
    }
    return intro + "\n\n" + texto;
  }

  function compararLocal(a, b) {
    const estadoTxt = p => {
      const e = estadoDe(p);
      return e.vista ? "ya la viste" + (e.estrellas ? " y le diste " + e.estrellas + " estrellas" : "") : (e.pendiente ? "está en tus pendientes" : "todavía no la has marcado");
    };
    const comunes = (x, y) => x.filter(v => y.includes(v));
    const genComun = comunes(generosDe(a), generosDe(b));
    const repComun = comunes(listaCampo(a, "reparto"), listaCampo(b, "reparto"));
    const perfil = perfilGustos();
    const sA = puntuar(a, perfil), sB = puntuar(b, perfil);
    const dirA = directoresDe(a).join(" y ") || "un director sin dato", dirB = directoresDe(b).join(" y ") || "un director sin dato";
    let t = "Te cuento las dos. «" + a.titulo + "» es de " + (a["año"] || "año sin dato") + " y dura " + (a.duracion ? String(a.duracion).replace(/\bmin\b\.?/i, "minutos") : "tiempo sin dato") + "; la dirigió " + dirA + ". ";
    t += "«" + b.titulo + "» es de " + (b["año"] || "año sin dato") + " y dura " + (b.duracion ? String(b.duracion).replace(/\bmin\b\.?/i, "minutos") : "tiempo sin dato") + "; la dirigió " + dirB + ".\n\n";
    t += genComun.length ? "En común tienen el género " + genComun.join(" y ").toLowerCase() + ". " : "No comparten género. ";
    t += repComun.length ? "Y en el reparto coinciden " + repComun.slice(0, 3).join(", ") + ".\n\n" : "Tampoco comparten reparto.\n\n";
    t += "En tu caso, «" + a.titulo + "» " + estadoTxt(a) + " y «" + b.titulo + "» " + estadoTxt(b) + ".\n\n";
    t += sA === sB
      ? "Según lo que ya te gusta, las dos te pueden encajar igual."
      : "Según lo que ya te gusta, yo me iría con «" + (sA > sB ? a.titulo : b.titulo) + "».";
    return t;
  }

  let ultimoTitulo = null;

  // Opinión basada en tus gustos, no en una lista genérica
  function opinionLocal(p) {
    const perfil = perfilGustos();
    const ranking = peliculas.map(x => puntuar(x, perfil)).sort((a, b) => a - b);
    const mediana = ranking[Math.floor(ranking.length / 2)] || 0;
    const mi = puntuar(p, perfil);
    const dirs = directoresDe(p).filter(d => perfil.director[d]);
    const gens = generosDe(p).filter(g => perfil.genero[g]);
    if (estadoDe(p).vista && estadoDe(p).estrellas) {
      return "Ya la viste y le diste " + estadoDe(p).estrellas + " estrellas, así que esa es tu opinión. ¿Quieres que te diga algo parecido?";
    }
    if (mi > mediana && (dirs.length || gens.length)) {
      return "Según tus gustos, sí te la recomendaría: " + (dirs.length ? "tiene a " + dirs[0] + ", que ya te gusta" : "es de " + gens[0].toLowerCase() + ", un género que te llena") + ".";
    }
    return "Según lo que has calificado, no me jugaría por ella: encaja menos con tus gustos que otras de tu lista. Si aun así te da curiosidad, adelante.";
  }

  function respuestaLocal(t) {
    const n = expandirChat(normalizarChat(t));
    const refin = refinarUltimo(n);
    if (refin) return refin;
    const pend = pendientesDe();
    const vistas = vistasDe();

    // Conversación: "otra", "no me gustó", ánimo, género
    if (/^(otra|otras|dame otra|y otra|otra mas|mas|siguiente|y de esas)\b/.test(n)) {
      const texto = sugerirLocal(ultimoFiltro);
      if (!texto) return "Esas son todas las que encajan ahorita. ¿Probamos con otro género o un ánimo distinto?";
      return elegir(["Va otra:", "Esta también podría gustarte:", "Otra que encaja:"]) + "\n\n" + texto;
    }
    // Recomendaciones por ocasión
    if (/para ver con (mi|mis|un|una|la|el)|en familia|con ninos|con mis ninos|con mi mama|con mi papa/.test(n)) {
      return respuestaSugerencia("Para ver en familia, te propongo:", p => generosDe(p).some(g => /familia|animacion|comedia|aventura/.test(normalizarChat(g))), "para verla en familia");
    }
    if (/noche de (terror|miedo|sustos)|peli de miedo|algo de miedo/.test(n)) {
      return respuestaSugerencia("Noche de sustos, va:", p => generosDe(p).some(g => /terror|suspenso/.test(normalizarChat(g))), "para pasar miedo");
    }
    if (/noche de (risas|reir|reirme)|para reirme|para reir|algo gracioso/.test(n)) {
      return respuestaSugerencia("Para reírte un rato:", p => generosDe(p).some(g => /comedia/.test(normalizarChat(g))), "para reírte un rato");
    }

    // Estadísticas: género favorito, general o de este año
    if (/genero favorito|mi genero|que genero veo mas|genero que mas/.test(n)) {
      const year = String(new Date().getFullYear());
      const conteo = {};
      const esteAno = /este ano|este año|de este ano|del ano/.test(n);
      const base = esteAno
        ? vistasDe().filter(p => ((marcas[p.titulo] || {}).historial || []).some(h => h.a === "vista" && String(h.f).startsWith(year)))
        : vistasDe();
      base.forEach(p => generosDe(p).forEach(g => { conteo[g] = (conteo[g] || 0) + 1; }));
      const top = Object.entries(conteo).sort((a, b) => b[1] - a[1]).slice(0, 2);
      if (!top.length) return esteAno ? "Este año todavía no marcas películas como vistas, así que no tengo base para decirte tu género de este año." : "Todavía no tengo suficientes películas vistas para decir cuál es tu género favorito.";
      return "Tu género favorito es " + top[0][0].toLowerCase() + (top[1] ? ", seguido de " + top[1][0].toLowerCase() : "") + ", con " + top[0][1] + (top[0][1] === 1 ? " película" : " películas") + (esteAno ? " este año." : " en total.");
    }

    // Seguimiento: por qué, decide por mí
    if (/por que|porque|y eso|razon/.test(n) && ultimasSugeridas.length) {
      return "Te la sugerí " + razonDe(ultimasSugeridas[0], perfilGustos()) + ". ¿Te late esa línea o prefieres otra?";
    }
    if (/decide tu|decides tu|no se|sorprendeme|elige tu|tu eliges/.test(n)) {
      const texto = sugerirLocal(null, 1);
      if (!texto) return "Ya no tengo qué elegir por ti. Marca algunas vistas y lo intento de nuevo.";
      return elegir(["Me arriesgo con esta:", "Mi elección va por aquí:"]) + "\n\n" + texto + "\n\nSi no te convence, dime «otra».";
    }

    // Tiempo disponible: "tengo una hora", "tengo 90 minutos", "poco tiempo", "mucho tiempo"
    let minutosDisponibles = 0;
    const horas = n.match(/(\d+)\s*(horas?|h)\b/);
    const mins = n.match(/(\d+)\s*(minutos?|min)\b/);
    if (/media hora/.test(n)) minutosDisponibles = 30;
    if (/una hora/.test(n)) minutosDisponibles = 60;
    if (horas) minutosDisponibles = Number(horas[1]) * 60;
    if (mins) minutosDisponibles += Number(mins[1]);
    if (minutosDisponibles > 0 && /tengo|tiempo|quedan|disponible|hora|minutos/.test(n)) {
      const etiqueta = minutosDisponibles % 60 === 0
        ? (minutosDisponibles / 60) + (minutosDisponibles === 60 ? " hora" : " horas")
        : minutosDisponibles + " minutos";
      return respuestaSugerencia("Con " + etiqueta + ", te cabe:", p => minutos(p) > 0 && minutos(p) <= minutosDisponibles + 10);
    }
    if (/poco tiempo|rapid[ao]|algo corto/.test(n)) {
      return respuestaSugerencia("Algo corto, de menos de hora y media:", p => minutos(p) > 0 && minutos(p) < 90);
    }
    if (/mucho tiempo|toda la tarde|noche larga|tengo tiempo/.test(n)) {
      return respuestaSugerencia("Tienes tiempo, así que algo para disfrutar sin prisa:", p => minutos(p) > 120);
    }

    // Seguimiento: "y su director", "quién la dirigió" sobre la última película mencionada
    if (ultimoTitulo && /director|quien la dirigio|quien la hizo|quien la dirige/.test(n)) {
      const dirs = directoresDe(ultimoTitulo);
      if (!dirs.length) return "No tengo el director de «" + ultimoTitulo.titulo + "» en tu catálogo.";
      const otras = peliculas.filter(p => p !== ultimoTitulo && directoresDe(p).some(d => dirs.includes(d)));
      return "«" + ultimoTitulo.titulo + "» es de " + dirs.join(" y ") + "." + (otras.length ? " Otras de él en tu catálogo: " + otras.map(p => p.titulo).slice(0, 4).join(", ") + "." : " No tengo más de él en tu catálogo.");
    }

    // Comparar dos películas de tu catálogo
    const encontradas = peliculas
      .filter(p => String(p.titulo).length > 3 && n.includes(normalizarChat(p.titulo)))
      .map(p => ({ p, i: n.indexOf(normalizarChat(p.titulo)) }))
      .sort((x, y) => x.i - y.i)
      .map(x => x.p);
    if (/compar|\bvs\b|versus|cual es mejor/.test(n) && encontradas.length >= 2) {
      return compararLocal(encontradas[0], encontradas[1]);
    }

    // Conversación natural: películas que menciona, despedidas, clima, planes, respuestas cortas
    const titulo = peliculas.filter(p => String(p.titulo).length > 3).find(p => n.includes(normalizarChat(p.titulo)));
    // Algo parecido a una película de tu catálogo
    if (titulo && /parecid|como la |como el |similar|algo como/.test(n)) {
      const gensT = generosDe(titulo);
      const dirT = directoresDe(titulo), perT = personasDe(titulo);
      return respuestaSugerencia("Si te gustó «" + titulo.titulo + "», va algo en esa línea:", p => p !== titulo && (
        generosDe(p).some(g => gensT.includes(g)) ||
        directoresDe(p).some(d => dirT.includes(d)) ||
        personasDe(p).some(x => perT.includes(x))
      ));
    }
    if (titulo) {
      const est = estadoDe(titulo);
      const gens = generosDe(titulo);
      if (/me gusto|me encanto|me encanta|buenisim|excelente|la ame|me fascin/.test(n)) {
        return respuestaSugerencia("¡Qué bueno que te gustó «" + titulo.titulo + "»! Si quieres más en esa línea:", p => generosDe(p).some(g => gens.includes(g)));
      }
      if (/no me gusto|aburri|no me convenc|mala/.test(n)) {
        return elegir(["Gracias por decírmelo, no todas pegan con todos. ¿Seguimos con algo distinto?", "Va, anotado que no te convenció «" + titulo.titulo + "». ¿Qué te late ahora?"]);
      }
      const estado = est.vista
        ? "la tienes como vista" + (est.estrellas ? " y le diste " + est.estrellas + " estrellas" : "")
        : (est.pendiente ? "la tienes en pendientes" : "todavía no la has marcado");
      ultimoTitulo = titulo;
      if (/opinas|te gusta|vale la pena|buena|recomiendas|me conviene/.test(n)) return opinionLocal(titulo);
      if (/dime mas|cuentame|hablame|platicame|dime de|de que trata|como es|de que va|que tal/.test(n)) {
        const datos = [];
        if (titulo["año"]) datos.push("salió en " + titulo["año"]);
        const gensUnicos = [...new Set(gens)];
        if (gensUnicos.length) datos.push("es de " + gensUnicos.slice(0, 2).join(" y ").toLowerCase());
        if (directoresDe(titulo).length) datos.push("la dirigió " + directoresDe(titulo).join(" y "));
        if (titulo.duracion) datos.push("dura " + titulo.duracion);
        const rep = [...new Set(listaCampo(titulo, "reparto"))].slice(0, 2);
        if (rep.length) datos.push("actúan " + rep.join(" y "));
        return "«" + titulo.titulo + "» " + (datos.length ? datos.join(", ") : "no tengo más datos de ella") + ". Y " + estado + ". ¿La quieres ver o ya la viste?";
      }
      return "«" + titulo.titulo + "»: " + estado + ". ¿Qué quieres saber de ella?";
    }
    if (/adios|bye|nos vemos|hasta luego|me voy|chao/.test(n)) {
      const nom = nombreUsuario();
      return elegir(["¡Nos vemos" + (nom ? ", " + nom : "") + "! Que disfrutes la peli.", "¡Hasta luego" + (nom ? ", " + nom : "") + "! Aquí estaré cuando vuelvas."]);
    }
    if (/llueve|lluvia|frio|fresco/.test(n)) {
      return respuestaSugerencia("Con la lluvia, algo acogedor:", p => generosDe(p).some(g => /comedia|drama|animacion|romance/i.test(g)));
    }
    if (/fin de semana|sabado|domingo|viernes/.test(n)) {
      return respuestaSugerencia("Para el fin de semana, algo que se disfrute con calma:", null);
    }
    if (/palomitas|hambre|comer|antojo/.test(n)) {
      return elegir(["Palomitas listas. ¿Qué tal algo de comedia para acompañarlas?", "Yo la acompaño con palomitas. ¿Qué te antojas ver?"]);
    }
    if (/que opinas|tu opinion|tu favorita|cual es tu favorita/.test(n)) {
      return "Mi favorita cambia según el día, pero me encanta cuando alguien descubre una película que lo sorprende. ¿Cuál es la tuya?";
    }
    if (/^(si|sí|claro|dale|va|ok|orale|simon)\b/.test(n) && ultimasSugeridas.length) {
      return "¡Buena! Cuando la veas, dime y la marco como vista con tu calificación.";
    }
    if (/^(no|nel|nop)\b/.test(n)) {
      return elegir(["Va, sin problema. ¿Buscamos otra cosa?", "Ok, no pasa nada. ¿Qué te late ahora?"]);
    }
    if (/no me (gusto|late|convence|interesa|va)|no quiero esa|otra cosa|paso de esa/.test(n)) {
      if (!ultimasSugeridas.length) return "¿Cuál no te gustó? Dime el título y no la vuelvo a sugerir en esta sesión.";
      const genero0 = generosDe(ultimasSugeridas[0])[0];
      ultimasSugeridas.forEach(p => sesionSugeridas.add(p.titulo));
      if (genero0 && !/^(no me gusta|no quiero)/.test(n)) {
        setTimeout(() => proponerNota("no me gusta el género " + genero0.toLowerCase()), 600);
      }
      const texto = sugerirLocal(ultimoFiltro);
      return "Anotado, no la repito. " + (texto ? "Pruebo con otras:\n\n" + texto : "Ya no tengo más que encajen con eso.");
    }
    const animo = animosLocal.find(a => a.re.test(n));
    if (animo) {
      return respuestaSugerencia(animo.intro, p => generosDe(p).some(g => animo.gen.some(x => normalizarChat(g).includes(x))), "para este momento");
    }
    const generoTexto = [...new Set(peliculas.flatMap(p => generosDe(p)))].find(g => n.includes(normalizarChat(g)));
    if (generoTexto) {
      return respuestaSugerencia(elegir(["Buena elección. De " + generoTexto.toLowerCase() + " te propongo:", "¡Me gusta tu gusto! Va de " + generoTexto.toLowerCase() + ":"]), p => generosDe(p).includes(generoTexto), (p, perfil) => razonGenero(p, generoTexto.toLowerCase(), perfil));
    }
    if (/que veo|sugier|recomie|algo para ver|que pongo|sorprend|algo bueno/.test(n)) {
      const hora = new Date().getHours();
      if (hora >= 6 && hora < 12) return respuestaSugerencia("Para la mañana, algo ligerito:", p => minutos(p) > 0 && minutos(p) <= 100);
      if (hora >= 21 || hora < 5) return respuestaSugerencia("Ya es noche cerrada, algo para disfrutar con calma:", p => minutos(p) >= 100);
      return respuestaSugerencia(elegir(["Te propongo esta:", "Esta me late para ti:", "Va una, según tus gustos:"]), null);
    }

    if (/^buenas noches\b/.test(n)) {
      return elegir(["¡Buenas noches! ¿Buscamos algo para esta noche?", "Buenas noches. ¿Qué te apetece ver antes de dormir?"]);
    }
    if (/^buenas tardes\b/.test(n)) {
      return elegir(["¡Buenas tardes! ¿Qué vemos hoy?", "Buenas tardes. ¿Buscamos algo para esta tarde?"]);
    }
    if (/^buenos dias\b/.test(n)) {
      return elegir(["¡Buenos días! ¿Qué tal si empezamos el día con una peli?", "¡Buenos días! ¿Te propongo algo para esta mañana?"]);
    }
    if (/^(hola|hey|hi|hello|buenas|que onda|que tal)\b/.test(n)) {
      const nom = nombreUsuario();
      const saludo = nom ? "¡Hola, " + nom + "!" : "¡Hola!";
      return elegir([
        saludo + " ¿Qué vemos hoy? Puedo sugerirte algo o revisar tus pendientes.",
        saludo + " Qué gusto verte. " + elegir(PREGUNTAS_SALUDO[franjaDelDia()]),
        saludo + " Aquí estoy. ¿Qué te apetece ver?",
        saludo + " Dime si quieres algo nuevo, algo de tu lista o una sorpresa.",
        saludo + " ¿Ya tienes en mente algo o te ayudo a elegir?"
      ]);
    }
    if (/estoy bien|todo bien|bien gracias|muy bien gracias/.test(n)) {
      return elegir(["¡Qué gusto leer eso! ¿Buscamos algo para acompañar ese buen ánimo?", "Me alegra mucho. ¿Qué te apetece ver para seguir así?"]);
    }
    if (/gracias|thank/.test(n)) {
      return elegir(["¡Con gusto! Me alegra que te sirva.", "¡De nada! Para eso estamos.", "Qué bueno que te sirvió. ¿Seguimos con otra?"]);
    }
    if (/como estas|como vas|que tal tu dia/.test(n)) {
      return elegir(["Muy bien, gracias por preguntar. Me pongo contento cuando hay películas de por medio. ¿Y tú qué tal?", "Bien por aquí. ¿Tú cómo vas? Si quieres, te propongo algo para lo que te quede del día."]);
    }
    if (/eres (humano|una persona|real|de carne)|eres (un )?robot/.test(n)) {
      return "Jaja, algo así: soy una IA, no una persona. Pero lo del cine me encanta, y eso sí lo comparto contigo.";
    }
    if (/como te llamas|cual es tu nombre|tu nombre/.test(n)) {
      return "Me llamo " + NOMBRE_COMPA + ". ¿Y tú? Si me dices tu nombre, lo guardo: escribe «recuerda que me llamo…».";
    }
    if (/quien eres|que eres|de donde eres|que haces|sobre ti/.test(n)) {
      return "Soy " + NOMBRE_COMPA + ", tu compa peliculero. Soy una IA y me encanta platicar de cine. Conozco tu catálogo, tus marcas y tus gustos, y aunque no haya internet, sigo aquí contigo.";
    }
    if (/ayuda|que puedes hacer|que haces|como funciona/.test(n)) {
      return "Puedo hacer varias cosas: sugerirte algo («sugiéreme algo»), mostrarte tus pendientes («qué tengo pendiente»), lo que ya viste («qué he visto»), tus favoritas («mis favoritas»), buscar por género o director («algo de terror», «películas de Nolan») darte números («cuántas tengo»), recomendarte para una ocasión («para ver con mi mamá», «noche de terror») o contarte tu semana («resumen de mi semana»).";
    }
    if (/que veo|sugier|recomie|algo para ver|que pongo|sorprend|algo bueno/.test(n)) {
      if (!vistas.length && !pend.length) return "Todavía no tengo suficientes datos de tus gustos. Marca algunas películas como vistas y te sugiero con gusto.";
      const linea = recomendarSinIA(3).split("\n").filter(l => l.startsWith("•"));
      if (!linea.length) return "Aún no tengo una buena sugerencia. Marca algunas vistas con calificación y lo intento de nuevo.";
      return elegir(["Te propongo esta:", "Esta me late para ti:", "Va una, según tus gustos:"]) + "\n\n" + linea.slice(0, 2).join("\n");
    }
    if (/pendiente|por ver|me falta/.test(n)) {
      if (!pend.length) return "No tienes pendientes. ¿Agregamos alguna a tu lista?";
      return elegir(["Tienes " + pend.length + " en tu lista de pendientes:", "Esto es lo que tienes pendiente (" + pend.length + " en total):"]) + "\n\n" + listaTitulos(pend);
    }
    if (/mejor|favorit|mas me gust|top/.test(n)) {
      const top = vistas.filter(p => estadoDe(p).estrellas).sort((a, b) => estadoDe(b).estrellas - estadoDe(a).estrellas);
      if (!top.length) return "Aún no has calificado películas. Dales estrellas y te cuento cuáles son tus favoritas.";
      return "Tus favoritas hasta ahora:\n\n" + top.slice(0, 4).map(p => "• " + p.titulo + " (" + estadoDe(p).estrellas + "★)").join("\n");
    }
    if (/he visto|ya vi|que vi|vistas/.test(n)) {
      if (!vistas.length) return "Todavía no marcas ninguna como vista. Cuando lo hagas, te puedo decir qué tanto te ha gustado.";
      return "Has visto " + vistas.length + " películas. Las más recientes:\n\n" + listaTitulos(vistas.slice(-5).reverse());
    }
    if (/cuantas|cuantos|total|tengo en total/.test(n)) {
      return "¡Tienes " + peliculas.length + " películas en tu colección! " + vistas.length + " ya vistas y " + pend.length + " esperando por ti.";
    }

    // Género o director mencionados en la pregunta
    const generos = [...new Set(peliculas.flatMap(p => generosDe(p)))];
    const genero = generos.find(g => n.includes(normalizarChat(g)));
    if (genero) {
      const de = peliculas.filter(p => generosDe(p).includes(genero) && !estadoDe(p).vista);
      if (!de.length) return "No tengo películas pendientes de " + genero.toLowerCase() + ". ¿Quieres que busque en lo que ya viste?";
      return elegir(["Buena elección. De " + genero.toLowerCase() + " tienes:", "¡Me gusta tu gusto! Estas son de " + genero.toLowerCase() + ":"]) + "\n\n" + listaTitulos(de);
    }
    const directores = [...new Set(peliculas.flatMap(p => directoresDe(p)))];
    const director = directores.filter(d => d.length > 3).find(d => n.includes(normalizarChat(d)));
    if (director) {
      const de = peliculas.filter(p => directoresDe(p).includes(director));
      return "De " + director + " tienes " + de.length + ":\n\n" + listaTitulos(de);
    }

    return elegir([
      "Eso se me escapa en modo sin IA, pero con tus marcas sí te ayudo. Prueba con «sugiéreme algo», «qué tengo pendiente» o «algo de comedia».",
      "Esa no la capté del todo en modo sin IA. Intenta con «qué he visto», «cuántas tengo» o «algo de terror»."
    ]);
  }

  function ponerChips(opciones) {
    document.querySelectorAll(".chat-chips").forEach(e => e.remove());
    const fila = document.createElement("div");
    fila.className = "chat-acciones chat-chips";
    opciones.forEach(txt => {
      fila.appendChild(crearBoton(txt, true, () => {
        fila.remove();
        burbuja(txt, "yo");
        procesarEntrada(txt);
      }));
    });
    lista.appendChild(fila);
    lista.scrollTop = lista.scrollHeight;
  }

  // ---------- Comprensión flexible (sin internet): entiende frases libres con datos del catálogo ----------
  const SINONIMOS_GENERO = {
    terror: ["terror", "miedo", "susto", "sustos", "horror", "de miedo", "espeluznante"],
    comedia: ["comedia", "risa", "risas", "reir", "reirme", "gracioso", "graciosa", "chistosa", "divertida"],
    romance: ["romance", "romantica", "romantico", "amor", "cita", "enamorar"],
    accion: ["accion", "pelea", "peleas", "explosiones", "adrenalina"],
    animacion: ["animacion", "animada", "animadas", "animado", "infantil", "dibujos"],
    drama: ["drama", "triste", "llorar", "emotiva", "emotivo"],
    suspenso: ["suspenso", "tension", "thriller", "intrigante"],
    ciencia: ["ciencia ficcion", "sci fi", "espacio", "futurista"]
  };

  function generosCatalogo() {
    const set = new Set();
    peliculas.forEach(p => generosDe(p).forEach(g => set.add(g)));
    return [...set];
  }

  function generoPedido(n) {
    const catalogo = generosCatalogo();
    const directo = catalogo.find(g => n.includes(normalizarChat(g)));
    if (directo) return directo;
    for (const clave of Object.keys(SINONIMOS_GENERO)) {
      if (SINONIMOS_GENERO[clave].some(s => n.includes(normalizarChat(s)))) {
        const hallado = catalogo.find(g => normalizarChat(g).includes(clave));
        if (hallado) return hallado;
      }
    }
    return null;
  }

  function anioPedido(n) {
    const a = n.match(/\b(19\d{2}|20\d{2})\b/);
    if (a) return { desde: +a[1], hasta: +a[1] };
    const d = n.match(/\b(?:de los |de )?(\d0)s\b/) || n.match(/\bde los (\d0)\b/);
    if (d) {
      const base = +d[1];
      const siglo = base < 30 ? 2000 : 1900;
      return { desde: siglo + base, hasta: siglo + base + 9 };
    }
    return null;
  }

  function minutosPedidos(n) {
    if (/hora y media/.test(n)) return 90;
    const m = n.match(/(\d+)\s*(?:min|minutos|mins)\b/);
    if (m) return +m[1];
    const h = n.match(/(\d+)\s*(?:h|horas?)\b/);
    if (h) return +h[1] * 60;
    if (/\b(corta|corto|rapida|rapido|ligera|ligero)\b/.test(n)) return 100;
    return null;
  }

  function personaPedida(n) {
    let mejor = null;
    peliculas.forEach(p => personasDe(p).forEach(nombre => {
      const nn = normalizarChat(nombre);
      if (nn.length >= 5 && n.includes(nn) && (!mejor || nn.length > normalizarChat(mejor).length)) mejor = nombre;
    }));
    return mejor;
  }

  function tituloPedido(n) {
    let mejor = null;
    peliculas.forEach(p => {
      const tn = normalizarChat(p.titulo);
      if (tn.length >= 4 && n.includes(tn) && (!mejor || tn.length > normalizarChat(mejor.titulo).length)) mejor = p;
    });
    return mejor;
  }

  // Devuelve una respuesta cuando la frase trae datos concretos (género, año, minutos, persona o título).
  // Si no encuentra nada útil, devuelve null y responde el motor de siempre.
  function respuestaFlexible(t) {
    const n = normalizarChat(t);
    const titulo = tituloPedido(n);
    if (titulo && /(de que trata|sinopsis|de que va|cuentame|que es|quien dirigio|quien actua|quien sale)/.test(n)) {
      const dirige = directoresDe(titulo).join(", ") || "sin dato";
      const sin = String(titulo.sinopsis || "").slice(0, 240);
      return "«" + titulo.titulo + "»" + (titulo["año"] ? " (" + titulo["año"] + ")" : "") +
        "\n\nDirige: " + dirige + ". Duración: " + (titulo.duracion || "sin dato") + ". Géneros: " + (generosDe(titulo).join(", ") || "sin dato") + "." +
        (sin ? "\n\n" + sin + (sin.length >= 240 ? "…" : "") : "");
    }

    const genero = generoPedido(n);
    const anio = anioPedido(n);
    const mins = minutosPedidos(n);
    const persona = personaPedida(n);
    if (!genero && !anio && !mins && !persona) return null;

    const partes = [];
    const filtros = [];
    if (genero) {
      partes.push("de " + genero.toLowerCase());
      filtros.push(p => generosDe(p).includes(genero));
    }
    if (anio) {
      partes.push(anio.desde === anio.hasta ? "de " + anio.desde : "de los " + (anio.desde % 100) + "s");
      filtros.push(p => { const y = Number(p["año"]); return y >= anio.desde && y <= anio.hasta; });
    }
    if (mins) {
      partes.push("de hasta " + mins + " min");
      filtros.push(p => { const m = minutos(p); return m > 0 && m <= mins + 15; });
    }
    if (persona) {
      partes.push("con " + persona);
      filtros.push(p => personasDe(p).includes(persona));
    }
    const intro = elegir(["Va, algo " + partes.join(" ") + ":", "Mira lo que encontré " + partes.join(" ") + ":", "Esto encaja con lo que buscas, " + partes.join(" ") + ":"]);
    const texto = respuestaSugerencia(intro, p => filtros.every(fn => fn(p)), genero ? (p, perfil) => razonGenero(p, genero.toLowerCase(), perfil) : null);
    if (texto.startsWith("Ya te propuse")) {
      return "No encuentro nada " + partes.join(", ") + " que te falte ver. ¿Probamos con algo más amplio? Por ejemplo, quita el año o sube los minutos.";
    }
    return texto;
  }

  // Recuerda la última búsqueda y la refina: «más corta», «más larga», «sin drama»
  function refinarUltimo(n) {
    const previo = ultimoFiltro || (() => true);
    if (/^(mas corto|mas cortas?|algo mas corto|mas cortita|mas corta)\b/.test(n)) {
      return respuestaSugerencia("Con ese mismo gusto, pero más corta:", p => previo(p) && minutos(p) > 0 && minutos(p) <= 100);
    }
    if (/^(mas larg[oa]|algo mas largo|mas larga)\b/.test(n)) {
      return respuestaSugerencia("Con ese mismo gusto, pero más larga:", p => previo(p) && minutos(p) >= 110);
    }
    const sin = n.match(/^(?:sin|nada de|menos)\s+(terror|drama|violencia|sangre|miedo|romance|comedia|animacion|accion)\b/);
    if (sin) {
      const g = sin[1];
      return respuestaSugerencia("Lo que te propongo, sin " + g + ":", p => previo(p) && !generosDe(p).some(x => normalizarChat(x).includes(g)));
    }
    return null;
  }

  async function responderLocal(t) {
    const escribiendo = document.createElement("div");
    escribiendo.className = "chat-pensando";
    escribiendo.textContent = "Escribiendo…";
    lista.appendChild(escribiendo);
    lista.scrollTop = lista.scrollHeight;
    await new Promise(r => setTimeout(r, 450 + Math.random() * 500));
    escribiendo.remove();
    const nEst = expandirChat(normalizarChat(t));
    const texto = refinarUltimo(nEst) || respuestaEmocional(nEst) || respuestaFlexible(t) || (await respuestaConModelo(t, historial)) || respuestaLocal(t);
    burbuja(texto, "ia");
    if (/•/.test(texto)) ponerChips(["Otra", "¿Por qué?", "Decide tú"]);
    else if (/Prueba con «sugiéreme algo»|Intenta con «qué he visto»/.test(texto)) ponerChips(["Sugiéreme algo", "Qué tengo pendiente", "Algo de comedia"]);
    mostrarPosters(texto);
  }

  function modoSinIAActivo() {
    if (!navigator.onLine) return true;
    if (consultasPersonalesHoy() >= LIMITE_IA_PERSONAL_DIA) return true;
    if (usoGrupo && usoGrupo.hoy >= usoGrupo.limite) return true;
    try { return localStorage.getItem("cuota_agotada_" + fechaPacifico()) === "1"; } catch (e) { return false; }
  }

  const respuestasCache = new Map();

  function hashTexto(t) {
    let h = 5381;
    for (let i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  }

  function fechaPacifico() {
    return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" });
  }

  function tiempoParaReinicio() {
    const ahora = new Date(new Date().toLocaleString("en-US", { timeZone: "America/Los_Angeles" }));
    const medianoche = new Date(ahora);
    medianoche.setHours(24, 0, 0, 0);
    const min = Math.max(0, Math.round((medianoche - ahora) / 60000));
    return Math.floor(min / 60) + " h " + (min % 60) + " min";
  }

  function contarConsultaPersonal() {
    const clave = "chat_consultas_" + fechaPacifico();
    try {
      const n = Number(localStorage.getItem(clave) || 0) + 1;
      localStorage.setItem(clave, String(n));
      return n;
    } catch (e) { return null; }
  }

  function consultasPersonalesHoy() {
    try { return Number(localStorage.getItem("chat_consultas_" + fechaPacifico()) || 0); } catch (e) { return null; }
  }

  function mensajeCuota() {
    const n = consultasPersonalesHoy();
    let t = "Por hoy ya se agotaron las consultas gratuitas de la IA (las comparten todas las cuentas).\n\n";
    if (n !== null) t += "Tus consultas de hoy: " + n + ".\n";
    t += "Se reinicia en " + tiempoParaReinicio() + " (medianoche, hora del Pacífico).\nMientras tanto sigo aquí en modo sin IA: te puedo sugerir, comparar y contarte tus números.";
    return t;
  }

  async function preguntar(texto, oculta = false, yaMostrada = false) {
    if (!accessToken || !peliculas.length) {
      burbuja("Primero necesito que tu catálogo cargue. Intenta en unos segundos.", "error");
      return;
    }
    if (!oculta && !yaMostrada) burbuja(texto, "yo");
    if (!oculta && !yaMostrada && intentoAbrirSugerida(texto)) return;
    if (!oculta && consultasPersonalesHoy() >= LIMITE_IA_PERSONAL_DIA) {
      burbuja("Hoy ya usaste tus " + LIMITE_IA_PERSONAL_DIA + " consultas con IA. Sigo contigo en modo sin IA; la IA vuelve a medianoche (hora del Pacífico).", "ia");
      responderLocal(texto);
      return;
    }
    const pensando = document.createElement("div");
    pensando.className = "chat-pensando";
    pensando.textContent = "Pensando…";
    lista.appendChild(pensando);
    lista.scrollTop = lista.scrollHeight;
    enviar.disabled = true;

    try {
      const catalogo = catalogoParaIA(texto);
      const clave = hashTexto(JSON.stringify({ p: texto, h: historial, c: catalogo }));
      if (respuestasCache.has(clave)) {
        pensando.remove();
        const previa = respuestasCache.get(clave);
        if (!oculta) {
          burbuja(previa, "ia");
          mostrarPosters(previa);
          historial.push({ role: "user", content: texto });
          historial.push({ role: "assistant", content: previa });
          historial = historial.slice(-16);
        }
        return previa;
      }
      const control = new AbortController();
      const tiempo = setTimeout(() => control.abort(), 25000);
      let r;
      try {
        r = await fetch(CHAT_URL, {
          method: "POST",
          signal: control.signal,
          headers: { "Content-Type": "text/plain;charset=utf-8" },
          body: JSON.stringify({ token: accessToken, pregunta: texto + "\n\n[Perfil de gustos del usuario: " + perfilTexto() + ".]\n[Estilo: " + ESTILO_IA + ". Momento del día: " + momentoDia() + ".]", historial: historial, catalogo: catalogo, gustos: perfilGustos() })
        });
      } finally { clearTimeout(tiempo); }
      const j = await r.json();
      pensando.remove();
      if (j.uso) pintarUso(j.uso);
      if (j.error) {
        const cuota = String(j.error).includes("429") || j.codigo === "limite_grupo";
        if (cuota) { try { localStorage.setItem("cuota_agotada_" + fechaPacifico(), "1"); } catch (e) {} }
        const motivo = cuota ? mensajeCuota() : "Ahorita la IA no está disponible.";
        if (oculta) burbuja(motivo, "error");
        else caeASinIA(motivo, texto);
      } else {
        contarConsultaPersonal();
        if (!j.accion) {
          respuestasCache.set(clave, j.respuesta);
          if (respuestasCache.size > 60) respuestasCache.delete(respuestasCache.keys().next().value);
        }
        if (!oculta) {
          burbuja(j.respuesta, "ia");
          const nombradas = titulosEnTexto(j.respuesta);
          if (nombradas.length) ultimasSugeridas = nombradas;
          mostrarPosters(j.respuesta);
          if (j.accion) proponerAccionIA(j.accion);
          historial.push({ role: "user", content: texto });
          historial.push({ role: "assistant", content: j.respuesta });
          historial = historial.slice(-16);
        }
        return j.respuesta;
      }
    } catch (e) {
      pensando.remove();
      const lento = e && e.name === "AbortError";
      if (oculta) burbuja(lento ? "La IA tardó demasiado. Intenta de nuevo." : "No pude conectar con el asistente. Revisa tu conexión.", "error");
      else caeASinIA(lento ? "La IA tardó demasiado en responder." : "No pude conectar con la IA.", texto);
    } finally {
      enviar.disabled = false;
    }
  }

  /* ---------- Preferencias (Drive, carpeta privada de la app) ---------- */
  let notas = [];
  let notasId = null;
  let notasCargadas = false;

  async function notasCargar() {
    if (!accessToken) return;
    try {
      const q = encodeURIComponent("name='chat_notas.json'");
      const r = await driveFetch("https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=" + q + "&fields=files(id)");
      const j = await r.json();
      notasId = (j.files && j.files[0] && j.files[0].id) || null;
      if (notasId) {
        const c = await driveFetch("https://www.googleapis.com/drive/v3/files/" + notasId + "?alt=media");
        const d = await c.json();
        notas = Array.isArray(d) ? d.filter(x => typeof x === "string").slice(0, 20) : [];
      }
      notasCargadas = true;
    } catch (e) { notasCargadas = false; }
  }

  async function notasGuardar() {
    const cuerpo = JSON.stringify(notas);
    if (notasId) {
      await driveFetch("https://www.googleapis.com/upload/drive/v3/files/" + notasId + "?uploadType=media", {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: cuerpo
      });
      return;
    }
    const f = "chat_notas_frontera";
    const meta = JSON.stringify({ name: "chat_notas.json", parents: ["appDataFolder"] });
    const partes = "--" + f + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + meta + "\r\n" +
      "--" + f + "\r\nContent-Type: application/json\r\n\r\n" + cuerpo + "\r\n--" + f + "--";
    const r = await driveFetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", {
      method: "POST", headers: { "Content-Type": "multipart/related; boundary=" + f }, body: partes
    });
    const j = await r.json();
    notasId = j.id;
  }

  /* ---------- Acciones con confirmación ---------- */
  // Pregunta de sí o no que espera respuesta: escribir «sí» o «no» equivale a tocar el botón
  let confirmacionPendiente = null;
  function preguntarConfirmacion(texto, textoSi, alSi) {
    burbuja(texto, "ia");
    const fila = document.createElement("div");
    fila.className = "chat-acciones";
    const si = document.createElement("button");
    si.type = "button";
    si.textContent = textoSi;
    const no = document.createElement("button");
    no.type = "button";
    no.className = "secundario";
    no.textContent = "Cancelar";
    const pendiente = { fila, alSi };
    confirmacionPendiente = pendiente;
    si.addEventListener("click", () => { if (confirmacionPendiente === pendiente) confirmacionPendiente = null; fila.remove(); alSi(); });
    no.addEventListener("click", () => { if (confirmacionPendiente === pendiente) confirmacionPendiente = null; fila.remove(); burbuja("Cancelado. No cambié nada.", "ia"); });
    fila.append(si, no);
    lista.appendChild(fila);
    lista.scrollTop = lista.scrollHeight;
  }

  function proponerNota(texto) {
    if (!texto || texto.length > 200) {
      burbuja("Escríbelo en menos de 200 caracteres, por favor.", "error");
      return;
    }
    preguntarConfirmacion("¿Lo guardo para tenerlo presente en tus próximas recomendaciones?\n\n«" + texto + "»", "Guardar", async () => {
      notas.push(texto);
      try {
        await notasGuardar();
        burbuja("Listo, quedó guardado. Lo tendré presente en tus recomendaciones.", "ia");
      } catch (e) {
        notas.pop();
        burbuja("No pude guardarlo en tu Drive. Intenta de nuevo más tarde.", "error");
      }
    });
  }

  function crearBoton(texto, secundario, alClick) {
    const b = document.createElement("button");
    b.type = "button";
    if (secundario) b.className = "secundario";
    b.textContent = texto;
    b.addEventListener("click", alClick);
    return b;
  }

  async function guardarMemoria() {
    if (!notasId && !notas.length) return;
    await notasGuardar();
  }

  function mostrarMemoria() {
    const nombre = nombreUsuario();
    if (!nombre && !notas.length) {
      burbuja("Por ahora no tengo nada guardado de ti. Si me dices tu nombre con «recuerda que me llamo…», lo tengo presente.", "ia");
      return;
    }
    let t = nombre ? "Claro, " + nombre + ". Esto es lo que recuerdo de ti." : "Esto es lo que recuerdo de ti. Todavía no me has dicho tu nombre.";
    t += notas.length
      ? (notas.length === 1 ? " Tengo una preferencia guardada:" : " Tengo " + notas.length + " preferencias guardadas:") + "\n\n" + notas.map((n, i) => (i + 1) + ". " + n).join("\n")
      : " Todavía no tienes preferencias guardadas.";
    t += "\n\nTus notas viven en cada ficha de tu catálogo, no aquí.";
    burbuja(t, "ia");

    const fila = document.createElement("div");
    fila.className = "chat-acciones";
    notas.forEach((n, i) => {
      fila.appendChild(crearBoton("Borrar " + (i + 1), true, async () => {
        notas.splice(i, 1);
        fila.remove();
        try { await guardarMemoria(); burbuja("Listo, esa ya no la recuerdo.", "ia"); }
        catch (e) { burbuja("No pude actualizar tu Drive. Intenta más tarde.", "error"); }
      }));
    });
    if (nombre) {
      fila.appendChild(crearBoton("Olvidar mi nombre", true, () => {
        fila.remove();
        preguntarConfirmacion("¿Olvido tu nombre? Ya no te saludaré por él.", "Sí, olvidarlo", async () => {
          notas = notas.filter(x => !/me llamo/i.test(String(x)));
          try { await guardarMemoria(); burbuja("Listo, ya no sé cómo te llamas.", "ia"); }
          catch (e) { burbuja("No pude actualizar tu Drive. Intenta más tarde.", "error"); }
        });
      }));
    }
    if (notas.length) {
      fila.appendChild(crearBoton("Borrar todo", false, () => {
        fila.remove();
        preguntarConfirmacion("¿Borro todo lo que recuerdo de ti? Incluye tu nombre y tus preferencias. Tus marcas y notas de películas no se tocan.", "Sí, borrar todo", async () => {
          notas = [];
          try { await guardarMemoria(); burbuja("Listo, empezamos de cero. Tus marcas siguen como estaban.", "ia"); }
          catch (e) { burbuja("No pude actualizar tu Drive. Intenta más tarde.", "error"); }
        });
      }));
    }
    if (fila.children.length) lista.appendChild(fila);
    lista.scrollTop = lista.scrollHeight;
  }

  // Acción propuesta por la IA: siempre pasa por la confirmación de siempre
  function proponerAccionIA(a) {
    if (!a) return;
    if (a.tipo === "marcar") return proponerMarca(a.titulo, a.estado);
    if (a.tipo === "nota") return proponerNotaPelicula(a.titulo, a.nota);
    if (a.tipo === "maraton") return proponerMaratonIA(a.titulos);
  }

  // La IA arma la noche: se confirma antes de abrir el modo cine
  function proponerMaratonIA(titulos) {
    const films = (titulos || []).map(t => peliculas.find(p => p.titulo === t)).filter(Boolean).slice(0, 5);
    if (!films.length) { burbuja("No encontré esas películas en tu catálogo.", "error"); return; }
    const lista = films.map(f => "• " + f.titulo + " (" + minutos(f) + " min)").join("\n");
    preguntarConfirmacion("Te armé esta noche:\n\n" + lista + "\n\n¿La empezamos en modo cine?", "Empezar", () => {
      if (typeof window.abrirModoCine === "function") window.abrirModoCine(films[0], films);
    });
  }

  function proponerMarca(titulo, estado) {
    const p = peliculas.find(x => String(x.titulo).toLowerCase() === titulo.toLowerCase());
    if (!p) {
      burbuja("No encontré «" + titulo + "» en tu catálogo. Revisa que el título esté escrito igual.", "error");
      return;
    }
    preguntarConfirmacion("¿Marco «" + p.titulo + "» como " + estado + "?", "Sí, marcar", () => {
      if (estado === "vista") cambiarEstado(p.titulo, { vista: true });
      else cambiarEstado(p.titulo, { pendiente: true, vista: false });
      if (typeof refrescarTodo === "function") refrescarTodo();
      burbuja("Listo: «" + p.titulo + "» quedó como " + estado + ".", "ia");
    });
  }

  function proponerNotaPelicula(titulo, texto) {
    const p = peliculas.find(x => String(x.titulo).toLowerCase() === titulo.toLowerCase());
    if (!p) {
      burbuja("No encontré «" + titulo + "» en tu catálogo. Revisa que el título esté escrito igual.", "error");
      return;
    }
    const t = String(texto || "").trim();
    if (!t || t.length > 1000) {
      burbuja("La nota debe tener entre 1 y 1000 caracteres.", "error");
      return;
    }
    const previa = (marcas[p.titulo] || {}).nota || "";
    const aviso = previa ? "\n\nSe agregará debajo de tu nota actual, sin borrarla." : "";
    preguntarConfirmacion("¿Guardo esta nota en «" + p.titulo + "»?\n\n«" + t + "»" + aviso, "Guardar nota", () => {
      guardarNota(p.titulo, previa ? previa + "\n" + t : t);
      if (typeof refrescarTodo === "function") refrescarTodo();
      burbuja("Nota guardada en «" + p.titulo + "».", "ia");
    });
  }

  async function redactarNotaIA(titulo) {
    const p = peliculas.find(x => String(x.titulo).toLowerCase() === titulo.toLowerCase());
    if (!p) {
      burbuja("No encontré «" + titulo + "» en tu catálogo. Revisa que el título esté escrito igual.", "error");
      return;
    }
    burbuja("Redacta una nota para «" + p.titulo + "»", "yo");
    const instruccion = "Redacta una nota personal breve (máximo 300 caracteres, en español) sobre la película «" + p.titulo +
      "», usando solo los datos de su ficha del catálogo. Responde únicamente con el texto de la nota, sin comillas ni introducción.";
    const texto = await preguntar(instruccion, true);
    if (!texto) return;
    const limpio = texto.replace(/^["«»]+|["«»]+$/g, "").trim().slice(0, 1000);
    burbuja(limpio, "ia");
    preguntarConfirmacion("¿Guardo esta nota en «" + p.titulo + "»?", "Guardar nota", () => {
      const previa = (marcas[p.titulo] || {}).nota || "";
      guardarNota(p.titulo, previa ? previa + "\n" + limpio : limpio);
      if (typeof refrescarTodo === "function") refrescarTodo();
      burbuja("Nota guardada en «" + p.titulo + "».", "ia");
    });
  }

  // ----- Estadísticas compartibles del año -----
  function estadisticasDeCine() {
    const vistas = vistasDe();
    const year = String(new Date().getFullYear());
    const esteAno = vistas.filter(p => ((marcas[p.titulo] || {}).historial || []).some(h => h.a === "vista" && String(h.f).startsWith(year)));
    const conteoGeneros = {};
    vistas.forEach(p => generosDe(p).forEach(g => { conteoGeneros[g] = (conteoGeneros[g] || 0) + 1; }));
    const generoFavorito = Object.entries(conteoGeneros).sort((a, b) => b[1] - a[1])[0];
    const calificadas = vistas.filter(p => estadoDe(p).estrellas);
    const promedio = calificadas.length ? calificadas.reduce((acc, p) => acc + estadoDe(p).estrellas, 0) / calificadas.length : null;
    const mejor = calificadas.slice().sort((a, b) => estadoDe(b).estrellas - estadoDe(a).estrellas)[0] || null;
    return {
      year,
      nombre: nombreUsuario(),
      vistas: vistas.length,
      esteAno: esteAno.length,
      generoFavorito: generoFavorito ? generoFavorito[0] : null,
      promedio: promedio === null ? null : Math.round(promedio * 10) / 10,
      mejor: mejor ? mejor.titulo + " (" + estadoDe(mejor).estrellas + "★)" : null
    };
  }

  function textoEstadisticas(e) {
    const lineas = ["Mi cine de " + e.year + (e.nombre ? " · " + e.nombre : "") + " 🎬"];
    lineas.push("• Vistas: " + e.vistas + (e.esteAno ? " (este año: " + e.esteAno + ")" : ""));
    if (e.generoFavorito) lineas.push("• Género favorito: " + e.generoFavorito);
    if (e.promedio !== null) lineas.push("• Calificación promedio: " + e.promedio + "★");
    if (e.mejor) lineas.push("• Mejor calificada: " + e.mejor);
    lineas.push("— " + NOMBRE_COMPA);
    return lineas.join("\n");
  }

  function dibujarImagenEstadisticas(e) {
    const c = document.createElement("canvas");
    c.width = 900; c.height = 500;
    const g = c.getContext("2d");
    const fondo = g.createLinearGradient(0, 0, 900, 500);
    fondo.addColorStop(0, "#0a84ff");
    fondo.addColorStop(1, "#5e5ce6");
    g.fillStyle = fondo;
    g.fillRect(0, 0, 900, 500);
    g.fillStyle = "#ffffff";
    g.font = "bold 46px system-ui, sans-serif";
    g.fillText("Mi cine de " + e.year, 60, 100);
    if (e.nombre) { g.font = "28px system-ui, sans-serif"; g.fillText(e.nombre, 60, 145); }
    const filas = [
      ["Vistas", e.vistas + (e.esteAno ? "  ·  este año: " + e.esteAno : "")],
      ["Género favorito", e.generoFavorito || "—"],
      ["Calificación promedio", e.promedio !== null ? e.promedio + "★" : "—"],
      ["Mejor calificada", e.mejor || "—"]
    ];
    let y = 215;
    filas.forEach(([etq, val]) => {
      g.font = "22px system-ui, sans-serif"; g.globalAlpha = 0.8; g.fillText(etq, 60, y);
      g.globalAlpha = 1; g.font = "bold 30px system-ui, sans-serif"; g.fillText(String(val).slice(0, 48), 60, y + 36);
      y += 80;
    });
    g.globalAlpha = 0.7; g.font = "20px system-ui, sans-serif"; g.fillText("— " + NOMBRE_COMPA, 60, 470); g.globalAlpha = 1;
    return c;
  }

  function mostrarEstadisticas() {
    const e = estadisticasDeCine();
    if (!e.vistas) {
      burbuja("Todavía no tienes películas vistas. Cuando marques algunas, te armo tu resumen del año.", "ia");
      return;
    }
    burbuja("Aquí tienes tu resumen de cine de " + e.year + ". Puedes copiarlo o guardarlo como imagen para compartirlo.", "ia");
    const tarjeta = document.createElement("div");
    tarjeta.className = "chat-stats";
    const titulo = document.createElement("h4");
    titulo.textContent = "Mi cine de " + e.year;
    tarjeta.appendChild(titulo);
    const texto = textoEstadisticas(e);
    texto.split("\n").slice(1, -1).forEach(linea => {
      const p = document.createElement("p");
      p.textContent = linea;
      tarjeta.appendChild(p);
    });
    const fila = document.createElement("div");
    fila.className = "chat-acciones";
    fila.appendChild(crearBoton("Copiar texto", true, async () => {
      try { await navigator.clipboard.writeText(texto); burbuja("Copiado. Ya lo puedes pegar en el grupo.", "ia"); }
      catch (err) { burbuja("No pude copiarlo. Selecciónalo y cópialo a mano.", "error"); }
    }));
    fila.appendChild(crearBoton("Guardar imagen", true, () => {
      dibujarImagenEstadisticas(e).toBlob(blob => {
        if (!blob) { burbuja("No pude crear la imagen en este navegador.", "error"); return; }
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "mi-cine-" + e.year + ".png";
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      }, "image/png");
    }));
    if (navigator.share) {
      fila.appendChild(crearBoton("Compartir", true, () => {
        navigator.share({ text: texto }).catch(() => {});
      }));
    }
    tarjeta.appendChild(fila);
    lista.appendChild(tarjeta);
    lista.scrollTop = lista.scrollHeight;
  }

  function isoLocal(d) {
    const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    return z.toISOString().slice(0, 10);
  }

  // Resumen de la semana: lo que viste, tu mejor calificación y tus pendientes
  function resumenSemana() {
    const hace7 = isoLocal(new Date(Date.now() - 7 * 86400000));
    const vistasSem = peliculas.filter(p => ((marcas[p.titulo] || {}).historial || []).some(h => h.a === "vista" && String(h.f) >= hace7));
    const pend = pendientesDe();
    const calificadas = vistasSem.filter(p => estadoDe(p).estrellas);
    let t = "Así va tu semana en cine.\n\n";
    if (vistasSem.length) {
      t += "Esta semana viste " + vistasSem.length + (vistasSem.length === 1 ? " película" : " películas") + ": " + vistasSem.slice(0, 4).map(p => p.titulo).join(", ") + (vistasSem.length > 4 ? " y algunas más" : "") + ". ¡Buen ritmo!\n";
    } else {
      t += "Esta semana todavía no marcas ninguna como vista. Sin presión.\n";
    }
    if (calificadas.length) {
      const mejor = calificadas.slice().sort((a, b) => estadoDe(b).estrellas - estadoDe(a).estrellas)[0];
      t += "La que más te gustó fue «" + mejor.titulo + "», con " + estadoDe(mejor).estrellas + " estrellas.\n";
    }
    t += pend.length ? "Tienes " + pend.length + (pend.length === 1 ? " por ver" : " por ver") + ". ¿Te propongo una para el fin de semana?" : "No tienes pendientes. ¿Agregamos alguna a tu lista?";
    return t.trim();
  }

  // Explica en qué se basan las recomendaciones, con los datos que usa
  function explicarPerfil() {
    const vistas = vistasDe();
    if (!vistas.length) return "Todavía no tengo nada en que basarme. Marca algunas películas como vistas y califícalas, y te cuento cómo te recomiendo.";
    const perfil = perfilGustos();
    const top = obj => Object.entries(obj).sort((a, b) => b[1] - a[1]).slice(0, 3).map(x => x[0]);
    const generos = top(perfil.genero).map(g => g.toLowerCase()), directores = top(perfil.director);
    const calificadas = vistas.filter(p => estadoDe(p).estrellas);
    const enLista = arr => arr.length <= 1 ? arr.join("") : arr.slice(0, -1).join(", ") + " y " + arr[arr.length - 1];
    let t = generos.length ? "Lo que más disfrutas es " + enLista(generos) + "." : "Todavía no tengo suficientes datos de géneros.";
    if (directores.length) t += " Los directores que más te llenan son " + enLista(directores) + ".";
    if (calificadas.length) {
      const prom = Math.round(calificadas.reduce((a, p) => a + estadoDe(p).estrellas, 0) / calificadas.length * 10) / 10;
      t += " Tus calificaciones promedian " + prom + " estrellas, en " + calificadas.length + (calificadas.length === 1 ? " película" : " películas") + ".";
    }
    t += "\n\nCada película que viste suma según sus estrellas: un director pesa el doble que un género, y las pendientes reciben un pequeño empujón. Con eso elijo lo que te propongo.";
    return t;
  }

  // ---------- Abrir la película de la que estamos hablando ("veamos esa") ----------
  let ultimasSeriesSugeridas = [];

  function generoSerieDe(n) {
    const S = window.seriesApi;
    if (!S) return null;
    const generos = [...new Set(S.lista().map(s => s.genero_principal).filter(Boolean))];
    const sinon = {
      terror: "terror", miedo: "terror", comedia: "comedia", risa: "comedia", romance: "romance", romantica: "romance",
      drama: "drama", animacion: "animacion", animada: "animacion", documental: "documental", historia: "historica",
      historica: "historica", accion: "accion", aventura: "accion", suspenso: "crimen", crimen: "crimen", misterio: "crimen",
      ciencia: "ciencia", fantasia: "ciencia"
    };
    const directo = generos.find(g => n.includes(normalizarChat(g)));
    if (directo) return directo;
    for (const palabra of Object.keys(sinon)) {
      if (n.includes(palabra)) {
        const g = generos.find(x => normalizarChat(x).includes(sinon[palabra]));
        if (g) return g;
      }
    }
    return null;
  }

  // Respuestas sobre series: capítulo siguiente, una serie concreta o recomendaciones de series
  function respuestaSeriesChat(t) {
    const S = window.seriesApi;
    if (!S) return false;
    const lista = S.lista();
    if (!lista.length) return false;
    const n = normalizarChat(t);

    if (/(que capitulo sigo|capitulo siguiente|siguiente capitulo|que serie sigo|por donde voy|que sigo viendo de series)/.test(n)) {
      const enCurso = lista.map(s => ({ s: s, pr: S.progreso(s) })).filter(x => x.pr.siguiente && x.pr.vistos > 0);
      if (!enCurso.length) {
        burbuja("Aún no tienes series en curso. Marca un capítulo en 📺 Series y te digo por dónde vas.", "ia");
      } else {
        burbuja("Estas son tus series en curso:\n\n" + enCurso.slice(0, 6).map(x =>
          "• " + x.s.titulo + ": T" + x.pr.siguiente.temporada + " · E" + x.pr.siguiente.episodio +
          " (" + x.pr.vistos + "/" + x.pr.total + ")").join("\n"), "ia");
        ponerChips(enCurso.slice(0, 3).map(x => x.s.titulo));
      }
      return true;
    }

    const serie = lista.find(s => { const tn = normalizarChat(s.titulo); return tn.length >= 4 && n.includes(tn); });
    if (serie && !tituloPedido(n)) {
      const pr = S.progreso(serie);
      ultimasSugeridas = [];
      ultimasSeriesSugeridas = [serie];
      burbuja(serie.titulo + (serie.año ? " (" + serie.año + ")" : "") + ". " + (serie.genero || "") +
        ".\n\n" + (serie.sinopsis || "Sin sinopsis.") +
        "\n\nVas " + pr.vistos + " de " + pr.total + " capítulos." +
        (pr.siguiente ? " Sigue T" + pr.siguiente.temporada + " · E" + pr.siguiente.episodio + "." : ""), "ia");
      ponerChips(["Abrir en Series"]);
      return true;
    }

    if (/\bseries?\b/.test(n)) {
      const genero = generoSerieDe(n);
      let pool = lista.filter(s => { const pr = S.progreso(s); return !(pr.total && pr.vistos === pr.total); });
      if (genero) pool = pool.filter(s => normalizarChat(s.genero_principal) === normalizarChat(genero));
      if (!pool.length) {
        burbuja("No encuentro series" + (genero ? " de " + genero.toLowerCase() : "") + " pendientes. ¿Probamos otro género?", "ia");
        return true;
      }
      const elegidas = pool.sort(() => Math.random() - 0.5).slice(0, 3);
      ultimasSugeridas = [];
      ultimasSeriesSugeridas = elegidas;
      burbuja("Te propongo estas series" + (genero ? " de " + genero.toLowerCase() : "") + ":\n\n" +
        elegidas.map(s => "• " + s.titulo + (s.año ? " (" + s.año + ")" : "")).join("\n") +
        "\n\nDime «veamos esa» o «la primera» y la abro en Series.", "ia");
      ponerChips(elegidas.map(s => s.titulo));
      return true;
    }
    return false;
  }

  function titulosDeUltimaRespuesta() {
    const bs = lista.querySelectorAll(".chat-burbuja.ia");
    const ultima = bs.length ? bs[bs.length - 1].textContent : "";
    const txt = normalizarChat(ultima);
    if (!txt) return [];
    return peliculas.filter(p => {
      const tn = normalizarChat(p.titulo);
      return tn.length >= 4 && txt.includes(tn);
    });
  }

  function intentoAbrirSugerida(t) {
    const n = normalizarChat(t);
    if (ultimaEmocion) return false; // un «sí» aquí responde a la charla, no abre una película
    if (!n || n.length > 60) return false;
    const confirma = /^(si|sip|ok|okey|va|dale|claro|veamos|vamos|ver|esa|esa mera|esa misma|la de|abrela|abre la|abrir|muestrame|muestra|quiero verla|quiero ver esa|quiero ver la|vamos con esa|veamos esa|esa peli|esa pelicula)\b/;
    const ordinal = /(primera|primer|segunda|segundo|tercera|tercero)/;
    const S = window.seriesApi;
    const serieExacta = S ? S.lista().find(s => normalizarChat(s.titulo) === n) : null;
    if (serieExacta) {
      burbuja("Abriendo la serie «" + serieExacta.titulo + "» en Series.", "ia");
      S.abrir(serieExacta.titulo);
      return true;
    }
    if (ultimasSeriesSugeridas.length && (confirma.test(n) || ordinal.test(n))) {
      const orden = { primera: 0, primer: 0, segunda: 1, segundo: 1, tercera: 2, tercero: 2 };
      const m = n.match(/(primera|primer|segunda|segundo|tercera|tercero)/);
      let s = ultimasSeriesSugeridas.length === 1 ? ultimasSeriesSugeridas[0] : (m ? ultimasSeriesSugeridas[orden[m[1]]] : null);
      if (!s) {
        burbuja("¿Cuál serie quieres abrir?", "ia");
        ponerChips(ultimasSeriesSugeridas.map(x => x.titulo));
        return true;
      }
      burbuja("Va, abriendo la serie «" + s.titulo + "».", "ia");
      S.abrir(s.titulo);
      return true;
    }
    const quiereVer = n.length <= 30 && !/\b(algo|alguna|algun|una|un|para|que|recomie|sugier|de)\b/.test(n) &&
      /(quiero ver|la quiero ver|lo quiero ver|me late|reproduc|abre|ponla|ponlo|pon la|verla|verlo|dale play|ver esa)/.test(n);
    if (!confirma.test(n) && !quiereVer && !ordinal.test(n)) {
      // Si escriben solo el título (o tocan una opción con el título), también se abre
      const solo = tituloPedido(n);
      if (!(solo && normalizarChat(solo.titulo) === n)) return false;
    }

    const cand = (ultimasSugeridas && ultimasSugeridas.length) ? ultimasSugeridas : titulosDeUltimaRespuesta();
    // 1) Si el mensaje trae el título, esa gana
    let p = tituloPedido(n);
    // 2) Si no, usa lo que acaba de sugerir la IA
    if (!p && cand.length) {
      if (cand.length === 1) p = cand[0];
      else {
        const orden = { primera: 0, primer: 0, segunda: 1, segundo: 1, tercera: 2, tercero: 2 };
        const m = n.match(/(primera|primer|segunda|segundo|tercera|tercero)/);
        if (m && cand[orden[m[1]]]) p = cand[orden[m[1]]];
      }
    }
    if (!p) {
      if (cand.length > 1) {
        burbuja("¿Cuál quieres abrir?", "ia");
        ponerChips(cand.map(x => x.titulo).slice(0, 4));
        return true;
      }
      return false;
    }
    const quiereFicha = /(ficha|detalle|informacion|cuentame|de que trata|sinopsis)/.test(n);
    const tieneTrailer = [p.trailer_es, p.trailer_en].some(x => x && String(x).trim() && String(x).trim() !== "sin tráiler");
    const abrirFicha = () => { try { abrirDetalle(p); } catch (e) { burbuja("No pude abrir la ficha. Intenta tocar el póster.", "error"); } };
    if (quiereFicha || (!urlReproducible(p.link) && !tieneTrailer)) {
      burbuja(quiereFicha ? "Va, abriendo la ficha de «" + p.titulo + "»." : "Esta no tiene tráiler guardado, así que te abro su ficha para que la veas con calma.", "ia");
      abrirFicha();
      return true;
    }
    burbuja("Va, la pongo aquí mismo: «" + p.titulo + "».", "ia");
    try { abrirVerPelicula(p.titulo, p.trailer_es, p.trailer_en, p.link, true); }
    catch (e) { burbuja("No pude abrir el reproductor. Te abro la ficha.", "error"); abrirFicha(); }
    return true;
  }

  function procesarEntrada(t) {
    // Se muestra tu mensaje siempre (también sin IA); preguntar() no lo repite
    burbuja(t, "yo");
    if (CRISIS_RE.test(normalizarChat(t))) { burbuja(textoCrisis(), "ia"); return; }
    // Si hay una pregunta de sí o no en pausa, «sí» la confirma y «no» la cancela (igual que los botones)
    if (confirmacionPendiente) {
      const pend = confirmacionPendiente;
      const cn = normalizarChat(t).replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
      if (/^(si|si porfa|si por favor|dale|va|claro|ok|okey|de acuerdo|adelante|hazlo|guardalo|guardala|olvidalo|olvidala|borralo|borrala)$/.test(cn)) {
        confirmacionPendiente = null;
        pend.fila.remove();
        pend.alSi();
        return;
      }
      if (/^(no|no gracias|cancela|cancelar|mejor no|nel)$/.test(cn)) {
        confirmacionPendiente = null;
        pend.fila.remove();
        burbuja("Cancelado. No cambié nada.", "ia");
        return;
      }
      confirmacionPendiente = null;
    }
    // Saludos, gracias y despedidas se responden al instante, sin gastar una consulta de IA
    if (/^(hola|hola estela|hey|hi|hello|buenas|buenos dias|buenas tardes|buenas noches|que onda|que tal|gracias|muchas gracias|gracias estela|adios|chao|hasta luego|nos vemos|bye)$/.test(normalizarChat(t).replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim())) {
      responderLocal(t);
      return;
    }
    if (intentoAbrirSugerida(t)) return;
    if (respuestaSeriesChat(t)) return;
    const nt = normalizarChat(t);
    if (/curiosidad|dato curioso|algo curioso|sabias que|dato interesante|dime un dato/.test(nt)) {
      if (/otra|mas/.test(nt)) curioOffset++;
      const lista = todasLasCuriosidades();
      const c = lista.length ? lista[(Math.floor(Math.random() * lista.length))] : null;
      burbuja(c ? "¿Sabías esto de «" + c.peli.titulo + "»? " + c.texto : "Todavía no tengo curiosidades cargadas. Puedes agregarlas en la pestaña «curiosidades» de tu hoja.", "ia");
      if (c) { ultimasSugeridas = [c.peli]; ponerChips(["Otra curiosidad", "Ábrela"]); }
      return;
    }
    if (/^(vota|votemos|dos opciones|a o b|cual prefieres|cual te late)/.test(nt)) { votacionAB(); return; }
    if (/^(mi racha|racha|cuantas semanas)/.test(nt)) {
      const r = rachaSemanas();
      burbuja(r.racha ? "Llevas " + r.racha + (r.racha === 1 ? " semana" : " semanas") + " seguidas viendo al menos una película. Esta semana ya llevas " + r.vistasSemana + "." : "Todavía no empiezas la racha. Marca una película como vista esta semana y arrancamos.", "ia");
      return;
    }
    if (/^(resumen|resumen de (mi|la) semana|mi semana|como va mi semana)/.test(nt)) { burbuja(resumenSemana(), "ia"); return; }
    if (/(que sabes de mi|como me conoces|por que me recomiendas|por que me sugieres|en que te basas)/.test(nt)) { burbuja(explicarPerfil(), "ia"); return; }
    if (/maraton/.test(nt)) {
      const h = nt.match(/(\d+)\s*(horas?|h)\b/), mi = nt.match(/(\d+)\s*(minutos?|min)\b/);
      let mins = 0;
      if (h) mins += Number(h[1]) * 60;
      if (mi) mins += Number(mi[1]);
      if (!mins) mins = 180;
      const tema = /terror|miedo|suspenso/.test(nt) ? "terror" : /animacion|animada/.test(nt) ? "animacion" : /comedia|reir|risas/.test(nt) ? "comedia" : "libre";
      const plan = planearNoche(mins, tema, "");
      if (plan.error) { burbuja(plan.error, "ia"); return; }
      const ahora = new Date();
      ahora.setMinutes(Math.ceil(ahora.getMinutes() / 5) * 5, 0, 0);
      const cursor = new Date(ahora.getTime());
      const lineas = plan.secuencia.map(x => {
        const ini = new Date(cursor.getTime());
        cursor.setMinutes(cursor.getMinutes() + x.m + plan.GAP);
        return horaTexto(ini) + " · " + x.p.titulo + " (" + x.m + " min)";
      });
      burbuja("Te armé una noche de " + plan.secuencia.length + (plan.secuencia.length === 1 ? " película" : " películas") +
        (tema !== "libre" ? " de " + tema : "") + ", empezando a las " + horaTexto(ahora) + ":\n\n" + lineas.join("\n") +
        "\n\nPara verla con pantalla completa, abre Maratón y toca Empezar.", "ia");
      return;
    }
    if (/como me llamo|cual es mi nombre|sabes mi nombre|sabes como me llamo/.test(nt)) {
      const nom = nombreUsuario();
      burbuja(nom ? "Te llamas " + nom + ", ¿verdad? Lo tengo presente." : "Todavía no me has dicho tu nombre. Si quieres, escribe «recuerda que me llamo…» y lo guardo.", "ia");
      return;
    }
    if (/registro de errores|mis errores|ver errores/.test(nt)) {
      const reg = window.obtenerRegistro ? window.obtenerRegistro() : [];
      burbuja(reg.length
        ? "Estos son los últimos errores que registré:\n\n" + reg.slice(-5).map(x => "• " + x.f.slice(0, 16).replace("T", " ") + " · " + x.msg).join("\n") + "\n\nPuedes verlo completo en Datos → Registro de errores."
        : "No hay errores registrados. Todo va bien por aquí.", "ia");
      return;
    }
    if (/^(mis estadisticas|mi ano|mis numeros|resumen de mi ano|estadisticas)\b/.test(normalizarChat(t))) return mostrarEstadisticas();
    let m;
    if ((m = t.match(/^recuerda que\s+(.+)$/i))) return proponerNota(m[1].trim());
    if (/^(mi memoria|mis preferencias|que recuerdas|qué recuerdas|lo que recuerdas)\??$/i.test(t)) return mostrarMemoria();
    if ((m = t.match(/^marca\s+(.+?)\s+como\s+(vista|pendiente)\.?$/i))) return proponerMarca(m[1].trim(), m[2].toLowerCase());
    if ((m = t.match(/^(?:agrega|añade|pon)?\s*(?:una\s+)?nota\s+(?:a|en|para|sobre|de)\s+(.+?)\s*:\s*([\s\S]+)$/i))) return proponerNotaPelicula(m[1].trim(), m[2]);
    if ((m = t.match(/^(?:redacta|escribe|sugiere)\s+(?:una\s+)?nota\s+(?:sobre|para|de|en)\s+(.+?)\.?$/i))) return redactarNotaIA(m[1].trim());
    if (modoSinIAActivo()) {
      if (!navigator.onLine && !avisoOffline) {
        avisoOffline = true;
        burbuja("Sin conexión: sigo contigo en modo sin IA. Puedo sugerirte, comparar, contarte tus números y más.", "ia");
      }
      responderLocal(t);
      return;
    }
    return preguntar(t, false, true);
  }

  document.getElementById("chatAbrir").addEventListener("click", () => {
    // Tocar el mismo botón con el panel abierto lo cierra
    if (panel.classList.contains("abierto")) {
      document.getElementById("chatCerrar").click();
      return;
    }
    panel.classList.add("abierto");
    fondoChat.classList.add("visible");
    pintarTablero();
    if (!notasCargadas) notasCargar();
    consultarUso();
    saludar();
    input.focus();
    reiniciarCierreAuto();
  });
  document.getElementById("chatCerrar").addEventListener("click", () => {
    panel.classList.remove("abierto");
    fondoChat.classList.remove("visible");
    if (vozSoportada) speechSynthesis.cancel();
    detenerEscuchaConv();
    clearTimeout(temporizadorCierre);
  });

  /* ---------- Cierre automático por inactividad ---------- */
  // Se cierra solo si el usuario no interactúa durante CIERRE_AUTO_MS, sin conversación continua,
  // sin que el asistente esté hablando o escuchando y sin texto escrito a medias.
  const CIERRE_AUTO_MS = 60000;
  let temporizadorCierre = null;
  function reiniciarCierreAuto() {
    clearTimeout(temporizadorCierre);
    if (!panel.classList.contains("abierto")) return;
    temporizadorCierre = setTimeout(() => {
      if (!panel.classList.contains("abierto")) return;
      const ocupado = conversacionActiva || escuchandoConv || asistenteHablando() || input.value.trim() !== "";
      if (ocupado) { reiniciarCierreAuto(); return; }
      document.getElementById("chatCerrar").click();
    }, CIERRE_AUTO_MS);
  }
  ["pointerdown", "keydown", "input", "submit"].forEach(ev => panel.addEventListener(ev, reiniciarCierreAuto));

  /* ---------- Estela dentro del buscador principal ---------- */
  // Enter busca en el catálogo; si lo escrito es una pregunta (¿…? o termina en ?), o se toca 🍿, se envía a Estela.
  const buscarPrincipal = document.getElementById("buscar");
  function preguntarAEstela(texto) {
    const t = String(texto || "").trim();
    if (!t) {
      if (!panel.classList.contains("abierto")) document.getElementById("chatAbrir").click();
      input.focus();
      return;
    }
    buscarPrincipal.value = "";
    buscarPrincipal.dispatchEvent(new Event("input", { bubbles: true }));
    if (!panel.classList.contains("abierto")) document.getElementById("chatAbrir").click();
    input.value = t;
    form.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
  }
  buscarPrincipal.addEventListener("keydown", e => {
    if (e.key !== "Enter") return;
    const t = buscarPrincipal.value.trim();
    if (t.startsWith("¿") || t.endsWith("?")) {
      e.preventDefault();
      preguntarAEstela(t);
    }
  });

  form.addEventListener("submit", e => {
    e.preventDefault();
    const t = input.value.trim();
    if (!t || enviar.disabled) return;
    input.value = "";
    procesarEntrada(t);
  });

  document.querySelectorAll("#chatSugerencias button[data-q]").forEach(b => {
    b.addEventListener("click", () => preguntar(b.dataset.q));
  });
  /* ---------- Conversación continua: escucha, responde y vuelve a escuchar ---------- */
  const RecConv = window.SpeechRecognition || window.webkitSpeechRecognition;
  const botonContinuo = document.getElementById("chatContinuo");
  let conversacionActiva = false;
  let escuchandoConv = false;
  let recConv = null;

  function conversacionGuardada() {
    try { return localStorage.getItem("chat_conversacion") === "1"; } catch (e) { return false; }
  }
  function pintarContinuo() {
    const orbe = document.getElementById("chatAbrir");
    if (orbe) orbe.classList.toggle("escuchando", escuchandoConv);
    if (!botonContinuo) return;
    botonContinuo.classList.toggle("activo", conversacionActiva);
    botonContinuo.classList.toggle("escuchando", escuchandoConv);
    botonContinuo.setAttribute("aria-pressed", conversacionActiva ? "true" : "false");
  }
  function asistenteHablando() {
    return vozSoportada && (speechSynthesis.speaking || speechSynthesis.pending);
  }
  function crearRecConv() {
    const r = new RecConv();
    r.lang = "es-MX";
    r.interimResults = false;
    r.continuous = false;
    r.maxAlternatives = 1;
    r.onresult = e => {
      const t = ((e.results[0] && e.results[0][0] && e.results[0][0].transcript) || "").trim();
      escuchandoConv = false;
      pintarContinuo();
      if (t) {
        input.value = t;
        form.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
      }
    };
    r.onerror = e => {
      escuchandoConv = false;
      pintarContinuo();
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        conversacionActiva = false;
        pintarContinuo();
        burbuja("No tengo permiso para usar el micrófono. Revisa el permiso del navegador y vuelve a activar la conversación.", "error");
      }
    };
    r.onend = () => {
      escuchandoConv = false;
      pintarContinuo();
      // Vuelve a escuchar si la conversación sigue activa y el asistente ya no está hablando
      setTimeout(() => {
        if (conversacionActiva && panel.classList.contains("abierto") && !asistenteHablando()) escucharConv();
      }, 500);
    };
    return r;
  }
  function escucharConv() {
    if (!RecConv || !conversacionActiva || escuchandoConv || asistenteHablando()) return;
    if (!recConv) recConv = crearRecConv();
    try {
      recConv.start();
      escuchandoConv = true;
      pintarContinuo();
    } catch (e) { /* ya estaba escuchando */ }
  }
  function detenerEscuchaConv() {
    escuchandoConv = false;
    pintarContinuo();
    if (recConv) { try { recConv.abort(); } catch (e) {} }
  }

  if (botonContinuo) {
    if (RecConv && vozSoportada) botonContinuo.hidden = false;
    conversacionActiva = RecConv && conversacionGuardada();
    pintarContinuo();
    botonContinuo.addEventListener("click", () => {
      if (conversacionActiva) {
        conversacionActiva = false;
        try { localStorage.setItem("chat_conversacion", "0"); } catch (e) {}
        detenerEscuchaConv();
        return;
      }
      conversacionActiva = true;
      try { localStorage.setItem("chat_conversacion", "1"); } catch (e) {}
      // La conversación continua necesita la voz encendida para no escucharse a sí misma
      if (!vozActiva()) { try { localStorage.setItem("chat_voz", "1"); } catch (e) {} actualizarIconoVoz(); }
      escucharConv();
      pintarContinuo();
    });
  }

  document.getElementById("chatNumeros").addEventListener("click", () => {
    burbuja("Mis números", "yo");
    mostrarEstadisticas();
  });
  document.getElementById("chatMemoria").addEventListener("click", () => {
    burbuja("Mi memoria", "yo");
    mostrarMemoria();
  });
  document.getElementById("chatSinIA").addEventListener("click", () => {
    burbuja("Recomiéndame (sin IA)", "yo");
    responderLocal("sugiéreme algo");
  });
})();

/* --- bloque 14 --- */
/* Pinta la parte llena de cada deslizador */
document.querySelectorAll("input[type=range]").forEach(r => {
  const pintar = () => r.style.setProperty("--pct", ((r.value - r.min) / (r.max - r.min) * 100) + "%");
  r.addEventListener("input", pintar);
  pintar();
});

/* --- bloque 15 --- */
/* El menú ⋯ se saca del encabezado para que flote sobre la barra inferior */
(function () {
  const menu = document.getElementById("panelMas");
  if (menu) document.body.appendChild(menu);
  const tab = document.getElementById("tabMas");
  if (tab) tab.addEventListener("click", () => {
    if (typeof alternarPanel === "function") alternarPanel("panelMas");
  });
})();

/* --- bloque 16 --- */
/* El orbe se coloca justo en el centro de la barra, encima de su hueco */
(function () {
  const slot = document.getElementById("tabEstela");
  const orbe = document.getElementById("chatAbrir");
  if (!slot || !orbe) return;
  const colocar = () => {
    const r = slot.getBoundingClientRect();
    if (!r.width) return;
    const t = 58;
    orbe.style.left = (r.left + (r.width - t) / 2) + "px"; orbe.style.setProperty("left", (r.left + (r.width - t) / 2) + "px", "important");
    orbe.style.top = (r.top + (r.height - t) / 2) + "px"; orbe.style.setProperty("top", (r.top + (r.height - t) / 2) + "px", "important");
  };
  colocar();
  window.addEventListener("resize", colocar);
  if (window.ResizeObserver) new ResizeObserver(colocar).observe(slot);
  new MutationObserver(colocar).observe(document.body, { subtree: true, attributes: true, attributeFilter: ["class"] });
  window.addEventListener("resize", colocar);
})();

/* --- bloque 17 --- */
(function(){
  const mas = document.getElementById("panelMas");
  const av = document.getElementById("panelAvanzados");
  if (mas && av) { while (mas.firstChild) av.appendChild(mas.firstChild); }
})();

/* --- bloque 18 --- */
document.addEventListener("DOMContentLoaded", () => {
  const re = /^(\p{Extended_Pictographic}\uFE0F?)\s*/u;
  document.querySelectorAll("#panelMas button.pildora, #panelMas .pildora").forEach(b => {
    if (b.querySelector(".ico")) return;
    const m = b.textContent.match(re);
    if (!m) return;
    const resto = b.textContent.slice(m[0].length);
    b.textContent = "";
    const ico = document.createElement("span");
    ico.className = "ico"; ico.setAttribute("aria-hidden", "true"); ico.textContent = m[1];
    b.appendChild(ico);
    b.appendChild(document.createTextNode(resto));
  });
});

/* --- bloque 19 --- */
(function () {
  // Brillo que sigue al dedo o al cursor
  document.addEventListener("pointermove", e => {
    const el = e.target.closest && e.target.closest(".pildora, #tabbar button, .explorar-item, .explorar-tile, .actor-card, .tarjeta");
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty("--mx", (e.clientX - r.left) + "px");
    el.style.setProperty("--my", (e.clientY - r.top) + "px");
  }, { passive: true });
  document.addEventListener("pointerdown", e => {
    const el = e.target.closest && e.target.closest(".pildora, #tabbar button, .explorar-item, .explorar-tile, .actor-card, .tarjeta");
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty("--mx", (e.clientX - r.left) + "px");
    el.style.setProperty("--my", (e.clientY - r.top) + "px");
  }, { passive: true });

  // Indicador deslizante de la barra inferior: se estira como una gota al ir a otra pestaña y al regresar
  const barra = document.getElementById("tabbar");
  if (!barra) return;
  const ind = document.createElement("span");
  ind.className = "lg-indicador";
  barra.insertBefore(ind, barra.firstChild);
  let ultimo = null;
  const medir = b => ({ x: b.offsetLeft, w: b.offsetWidth });
  const colocar = (animar) => {
    const act = barra.querySelector("button.activa");
    if (!act || !act.offsetWidth) { ind.style.width = "0px"; ultimo = null; return; }
    const a = medir(act);
    ind.style.left = a.x + "px";
    ind.style.width = a.w + "px";
    if (false && animar && ultimo && (ultimo.x !== a.x || ultimo.w !== a.w) && ind.animate) {
      const de = ultimo;
      const izq = Math.min(de.x, a.x);
      const ancho = Math.abs(a.x - de.x) + Math.min(de.w, a.w);
      ind.animate([
        { left: de.x + "px", width: de.w + "px", offset: 0 },
        { left: izq + "px", width: ancho + "px", offset: 0.55 },
        { left: a.x + "px", width: a.w + "px", offset: 1 }
      ], { duration: 560, easing: "cubic-bezier(.22,.9,.3,1)" });
    }
    ultimo = a;
  };
  new MutationObserver(() => colocar(true)).observe(barra, { attributes: true, subtree: true, attributeFilter: ["class"] });
  if (window.ResizeObserver) new ResizeObserver(() => colocar(false)).observe(barra);
  window.addEventListener("resize", () => colocar(false));
  // Cuando la barra aparece (al entrar), se coloca sin animar
  new MutationObserver(() => { if (document.body.classList.contains("con-sesion")) setTimeout(() => colocar(false), 60); })
    .observe(document.body, { attributes: true, attributeFilter: ["class"] });
  colocar(false);
})();

/* --- bloque 20 --- */
// Ligeras primero, después las intensas y al final las tranquilas
function intensidadMaraton(p) {
  const g = String(p.genero || "").toLowerCase();
  if (/animaci|familia|comedia|aventura/.test(g)) return 1;
  if (/terror|suspenso|crimen|accion|acción|thriller/.test(g)) return 3;
  return 2;
}

function horaTexto(d) {
  return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
}

// Arma la noche (sin pintar nada): la usan la ventana del maratón y el chat
function planearNoche(minutosPedidos, tema, dir) {
  let base = pendientesNoVistas();
  let aviso = "";
  if (!base.length) {
    base = peliculas.filter(p => !estadoDe(p).vista && !(marcas[p.titulo] || {}).descartada);
    aviso = "No tienes pendientes, así que armo con películas que no has visto.";
  }
  base = base.filter(p => {
    const g = String(p.genero || "");
    if (tema === "terror") return /terror|suspenso/i.test(g);
    if (tema === "animacion") return /animaci/i.test(g);
    if (tema === "comedia") return /comedia/i.test(g);
    if (tema === "director") return !!dir && String(p.director || "").toLowerCase().includes(dir.toLowerCase());
    return true;
  });
  if (!base.length) return { error: tema === "libre" ? "No tienes películas sin ver en tu catálogo. Agrega algunas o marca pendientes." : "Ya no te quedan películas sin ver de ese tema. ¿Probamos con otro género?" };
  const pool = base.map(p => ({ p, m: minutos(p) })).filter(x => x.m > 0);
  if (!pool.length) return { error: "Ninguna de estas películas tiene duración escrita. Revisa la columna «duracion» de la hoja, por ejemplo «1 h 45 min»." };

  const GAP = 10, MAX = 5;
  const orden = pool.slice().sort(() => Math.random() - 0.5);
  const elegidas = [];
  let usados = 0;
  for (const x of orden) {
    if (elegidas.length >= MAX) break;
    const extra = elegidas.length ? GAP : 0;
    if (usados + extra + x.m <= minutosPedidos) { elegidas.push(x); usados += extra + x.m; }
  }
  if (!elegidas.length) return { error: "Ninguna película cabe en " + minutosPedidos + " minutos. ¿Le subimos un poco al tiempo?" };
  const grupo = n => elegidas.filter(x => intensidadMaraton(x.p) === n);
  const secuencia = [...grupo(1), ...grupo(3), ...grupo(2)];
  return { aviso, elegidas, secuencia, usados, sobra: minutosPedidos - usados, GAP };
}

/* --- bloque 21 --- */
/* Coloca la pastilla sobre la opción activa de cada selector y de la barra inferior */
(function () {
  function asegurar(cont) {
    if (!cont.querySelector(":scope > .indicador")) {
      const ind = document.createElement("span");
      ind.className = "indicador";
      cont.insertBefore(ind, cont.firstChild);
    }
    return cont.querySelector(":scope > .indicador");
  }
  function mover(cont) {
    const ind = asegurar(cont);
    const act = cont.querySelector(".activa");
    if (!act || !act.offsetWidth) { ind.style.opacity = 0; return; }
    ind.style.opacity = 1;
    ind.style.width = act.offsetWidth + "px";
    ind.style.height = act.offsetHeight + "px";
    ind.style.transform = "translate(" + act.offsetLeft + "px," + act.offsetTop + "px)";
  }
  function todos() {
    document.querySelectorAll(".segmentado, #tabbar").forEach(mover);
  }
  todos();
  window.addEventListener("resize", todos);
  // Solo se recalcula cuando cambia algo: clases (cambio de pestaña) o tamaño
  new MutationObserver(todos).observe(document.body, { subtree: true, attributes: true, attributeFilter: ["class"] });
  if (window.ResizeObserver) new ResizeObserver(todos).observe(document.body);
})();

/* --- bloque 22 --- */
/* ---------- Saludo personal: bienvenida cálida al entrar ---------- */
const SALUDO_NOMBRE = "nombre_usuario";
const SALUDO_VISITA = "ultima_visita";
const SALUDO_OMITIDO = "nombre_omitido";
const SALUDO_MODO = "saludo_modo";
let saludoSnap = null;
let saludoCerrado = false;

function leerLS(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function escribirLS(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
function quitarLS(k) { try { localStorage.removeItem(k); } catch (e) {} }

function nombreGuardado() {
  const v = (leerLS(SALUDO_NOMBRE) || "").trim();
  return v || null;
}

function plural(n, uno, varios) { return n + " " + (n === 1 ? uno : varios); }

function calcularSaludo() {
  const ultima = Number(leerLS(SALUDO_VISITA) || 0);
  const dias = ultima ? Math.floor((Date.now() - ultima) / 86400000) : null;
  const pend = pendientesNoVistas().length;
  const planes = recordatoriosActivos().length;
  return { dias: dias, pend: pend, planes: planes, viejos: pendientesViejos(), reto: retoActual() };
}

function consejoSaludo(d) {
  const ahora = new Date();
  const h = ahora.getHours();
  const dia = ahora.getDay();
  const cand = [];
  if (dia === 0 || dia === 6) cand.push("Es fin de semana: buen momento para una maratón.");
  if (dia === 5) cand.push("Viernes: ¿qué te vas a ver esta noche?");
  if (dia === 1) cand.push("Empieza la semana con algo ligero.");
  if (h < 12) cand.push("Una película corta para empezar bien el día.");
  if (h >= 21) cand.push("Ya es tarde: algo tranquilo estaría bien.");
  if (d.pend > 0) cand.push("¿Te saco una al azar de tus pendientes?");
  if (window.seriesApi) {
    const S = window.seriesApi;
    const enCurso = S.lista().filter(s => { const pr = S.progreso(s); return pr.vistos > 0 && pr.siguiente; });
    if (enCurso.length) cand.push("Tienes " + plural(enCurso.length, "serie", "series") + " a medias. ¿Por dónde vamos?");
  }
  if (!cand.length) return "";
  const ultimo = leerLS("saludo_consejo_ultimo");
  const opciones = cand.filter(c => c !== ultimo);
  const elegido = (opciones.length ? opciones : cand)[Math.floor(Math.random() * (opciones.length || cand.length))];
  escribirLS("saludo_consejo_ultimo", elegido);
  return elegido;
}

function textoSaludo(d) {
  const n = nombreGuardado();
  const nom = n ? ", " + esc(n) : "";
  const h = new Date().getHours();
  const icono = h < 12 ? "☀️" : h < 19 ? "🌤️" : "🌙";
  const franja = h < 12 ? "Buenos días" : h < 19 ? "Buenas tardes" : "Buenas noches";
  let titulo, linea;
  if (d.dias === null) {
    titulo = icono + " " + (n ? "Qué bueno que llegaste, " + esc(n) + "." : "Qué bueno que llegaste.");
    linea = "Aquí guardas lo que viste, lo que quieres ver y lo que te gustó. Empieza marcando una película, o pregúntame qué ver.";
  } else if (d.dias === 0) {
    titulo = icono + " " + franja + nom + ". Qué bueno verte otra vez.";
    linea = d.pend ? "Te esperan " + plural(d.pend, "pendiente", "pendientes") + " cuando quieras." : "Aún no tienes pendientes. ¿Qué te apetece agregar?";
  } else if (d.dias <= 2) {
    titulo = icono + " Qué gusto tenerte de vuelta" + nom + ".";
    linea = d.pend ? "Tienes " + plural(d.pend, "pendiente", "pendientes") + " por ver." : "Cuando quieras, te ayudo a elegir algo.";
  } else {
    titulo = icono + " Te extrañé" + nom + ". Hace " + d.dias + " días que no entrabas.";
    linea = d.pend ? "Tienes " + plural(d.pend, "pendiente", "pendientes") + " esperándote." : "Hay películas nuevas por descubrir. ¿Buscamos algo?";
  }
  const extras = [];
  if (d.consejo) extras.push("💬 " + esc(d.consejo));
  if (d.planes) extras.push("📅 Tienes " + plural(d.planes, "plan", "planes") + " con alguien en los próximos días.");
  if (d.viejos && d.viejos.length) extras.push("📌 " + plural(d.viejos.length, "pendiente lleva", "pendientes llevan") + " más de 2 meses esperando, como «" + esc(d.viejos[0]) + "».");
  extras.push("🏆 " + esc(d.reto.texto));
  return { titulo: titulo, linea: linea, extras: extras, tieneNombre: !!n };
}

function renderSaludoPersonal() {
  const sec = $("saludoPersonal");
  if (!sec || !document.body.classList.contains("con-sesion")) return;
  if (!saludoSnap) {
    saludoSnap = calcularSaludo();
    escribirLS(SALUDO_VISITA, String(Date.now()));
    if (!nombreGuardado() && !leerLS(SALUDO_OMITIDO)) abrirNombre(false);
  }
  const modo = leerLS(SALUDO_MODO) || "si";
  if (modo === "no" || saludoCerrado) { sec.style.display = "none"; return; }
  const frescos = calcularSaludo();
  saludoSnap.pend = frescos.pend;
  saludoSnap.planes = frescos.planes;
  saludoSnap.viejos = frescos.viejos;
  saludoSnap.reto = frescos.reto;
  saludoSnap.consejo = consejoSaludo(saludoSnap);
  const t = textoSaludo(saludoSnap);
  sec.innerHTML =
    '<button type="button" class="saludo-cerrar" data-accion="cerrar" aria-label="Cerrar saludo">×</button>' +
    '<h2 class="saludo-titulo">' + t.titulo + '</h2>' +
    '<p class="saludo-linea">' + t.linea + '</p>' +
    t.extras.map(x => '<p class="saludo-meta">' + x + '</p>').join("") +
    '<div class="saludo-acciones"><button type="button" class="pildora" data-accion="escuchar">🔊 Escuchar</button>' +
    '<button type="button" class="pildora" data-accion="sorpresa">🎲 Sorpréndeme</button>' +
    '<button type="button" class="pildora" data-accion="platicar">💬 Platicar</button>' +
    (window.seriesApi ? '<button type="button" class="pildora" data-accion="series">📺 Series</button>' : '') +
    '</div>';
  sec.style.display = "block";
  if (speechSynthesis && speechSynthesis.speaking) marcarHablando(true);
  if (!saludoHablo) { saludoHablo = true; setTimeout(hablarSaludo, 500); }
}

function abrirNombre(editar) {
  detenerSaludo();
  const input = $("nombreInput");
  input.value = nombreGuardado() || "";
  $("nombreError").textContent = "";
  $("nombreTitulo").textContent = editar ? "¿Cómo te llamo?" : "Qué bueno tenerte aquí";
  $("nombreFondo").classList.add("visible");
  $("nombreModal").classList.add("visible");
  setTimeout(() => input.focus(), 60);
}

function cerrarNombre() {
  $("nombreFondo").classList.remove("visible");
  $("nombreModal").classList.remove("visible");
}

function guardarNombre() {
  let val = $("nombreInput").value.trim().replace(/\s+/g, " ");
  if (!val) { $("nombreError").textContent = "Escribe cómo te gustaría que te llamara."; return; }
  if (!/^[\p{L}][\p{L} .'-]{0,23}$/u.test(val)) {
    $("nombreError").textContent = "Usa solo letras, por ejemplo tu nombre o un apodo corto.";
    return;
  }
  val = val.charAt(0).toUpperCase() + val.slice(1);
  escribirLS(SALUDO_NOMBRE, val);
  quitarLS(SALUDO_OMITIDO);
  cerrarNombre();
  renderSaludoPersonal();
}

function omitirNombre() {
  escribirLS(SALUDO_OMITIDO, "1");
  cerrarNombre();
  renderSaludoPersonal();
}

$("nombreGuardar").addEventListener("click", guardarNombre);
$("nombreOmitir").addEventListener("click", omitirNombre);
$("nombreFondo").addEventListener("click", omitirNombre);
$("nombreInput").addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); guardarNombre(); } });
document.addEventListener("keydown", e => {
  if (e.key === "Escape" && $("nombreModal").classList.contains("visible")) omitirNombre();
});

$("saludoPersonal").addEventListener("click", e => {
  const b = e.target.closest("[data-accion]");
  if (!b) return;
  if (b.dataset.accion === "cerrar") { saludoCerrado = true; renderSaludoPersonal(); }
  if (b.dataset.accion === "escuchar") {
    if ($("saludoPersonal").classList.contains("hablando")) detenerSaludo(); else hablarSaludo();
  }
  if (b.dataset.accion === "sorpresa") {
    const pend = peliculas.filter(p => (marcas[p.titulo] || {}).pendiente && !(marcas[p.titulo] || {}).vista);
    if (pend.length) abrirDetalle(pend[Math.floor(Math.random() * pend.length)]);
  }
  if (b.dataset.accion === "platicar") { const c = document.getElementById("chatAbrir"); if (c) c.click(); }
  if (b.dataset.accion === "series") { const s = document.getElementById("verSeries"); if (s) s.click(); }
});

const selSaludo = $("saludo-modo");
selSaludo.value = leerLS(SALUDO_MODO) || "si";
selSaludo.addEventListener("change", () => {
  escribirLS(SALUDO_MODO, selSaludo.value);
  saludoCerrado = false;
  renderSaludoPersonal();
});

/* ---------- Saludo en voz alta (voz del navegador, sin conexión a datos del catálogo) ---------- */
let saludoHablo = false;
let saludoVozTimer = null;

function vozSaludoActiva() {
  if (!("speechSynthesis" in window) || typeof SpeechSynthesisUtterance === "undefined") return false;
  if ((leerLS("saludo_voz") || "si") === "no") return false;
  if (leerLS("chat_voz") === "0") return false;
  return true;
}

// ── Voz: una sola selección para el chat y el saludo, con y sin internet ──
// Sin internet (o si la voz de red falla) usa solo voces del propio dispositivo.
function elegirVozEsp(localSolo = false) {
  const todas = speechSynthesis.getVoices();
  const vs = todas.filter(v => /^es/i.test(v.lang));
  if (!vs.length) return null;
  const sinRed = localSolo || navigator.onLine === false;
  let cand = sinRed ? vs.filter(v => v.localService) : vs;
  if (!cand.length && sinRed) cand = todas.filter(v => v.localService);
  if (!cand.length) cand = vs;
  const calidad = /natural|neural|online|premium|enhanced|google|mejorad|plus/i;
  const puntos = v => (/^es[-_]MX/i.test(v.lang) ? 4 : 0) + (calidad.test(v.name) ? 3 : 0) + (!sinRed && !v.localService ? 2 : 0);
  return cand.slice().sort((a, b) => puntos(b) - puntos(a))[0];
}

function hablarTrozos(trozos, opc = {}) {
  const { desde = 0, localSolo = false, velocidad = 1, alInicio = null, alFinal = null, alError = null } = opc;
  const voz = elegirVozEsp(localSolo);
  let reiniciado = false;
  trozos.slice(desde).forEach((trozo, i) => {
    const k = desde + i;
    const u = new SpeechSynthesisUtterance(trozo);
    u.lang = voz ? voz.lang : "es-MX";
    if (voz) u.voice = voz;
    u.rate = velocidad;
    u.pitch = 1.0;
    if (k === 0 && alInicio) u.onstart = alInicio;
    if (k === trozos.length - 1 && alFinal) u.onend = alFinal;
    u.onerror = e => {
      const red = /network|synthesis|unavailable|unsupported/i.test((e && e.error) || "");
      if (!red) return;
      if (!localSolo && !reiniciado) {
        // La voz de red falló (p. ej. sin internet): repite desde este trozo con voz local
        reiniciado = true;
        speechSynthesis.cancel();
        hablarTrozos(trozos, { ...opc, desde: k, localSolo: true });
      } else if (alError) alError();
    };
    speechSynthesis.speak(u);
  });
}

function vozEspanola() {
  return elegirVozEsp();
}

function textoParaVoz() {
  const sec = $("saludoPersonal");
  return [...sec.querySelectorAll(".saludo-titulo, .saludo-linea, .saludo-meta")]
    .map(el => el.textContent.trim()).filter(Boolean).join(". ")
    .replace(/\p{Extended_Pictographic}\uFE0F?/gu, "")
    .replace(/·/g, ",").replace(/\s+/g, " ").replace(/\.\s*\./g, ".").trim();
}

function marcarHablando(on) {
  const sec = $("saludoPersonal");
  if (!sec) return;
  sec.classList.toggle("hablando", on);
  const b = sec.querySelector('[data-accion="escuchar"]');
  if (b) b.textContent = on ? "⏹ Detener" : "🔊 Escuchar";
}

function detenerSaludo() {
  if (saludoVozTimer) { clearTimeout(saludoVozTimer); saludoVozTimer = null; }
  if ("speechSynthesis" in window) speechSynthesis.cancel();
  marcarHablando(false);
}

function hablarSaludo(intento = 0) {
  if (!vozSaludoActiva() || !$("saludoPersonal")) return;
  const texto = textoParaVoz();
  if (!texto) return;
  if (!speechSynthesis.getVoices().length && intento === 0) {
    esperarVoces().then(() => hablarSaludo(1));
    return;
  }
  detenerSaludo();
  hablarTrozos(trocearParaVoz(texto), {
    velocidad: 1.0,
    alInicio: () => { if (saludoVozTimer) { clearTimeout(saludoVozTimer); saludoVozTimer = null; } marcarHablando(true); mantenerVoz(); },
    alFinal: () => marcarHablando(false),
    alError: () => marcarHablando(false)
  });
  // Si el navegador bloquea la voz sin un toque previo, se intenta una sola vez en el primer toque
  saludoVozTimer = setTimeout(() => {
    saludoVozTimer = null;
    if (!speechSynthesis.speaking) {
      marcarHablando(false);
      document.addEventListener("pointerdown", () => { if (!speechSynthesis.speaking) hablarSaludo(1); }, { once: true });
    }
  }, 1500);
}

$("cambiarNombreBtn").addEventListener("click", () => abrirNombre(true));

const selVoz = $("saludo-voz");
selVoz.value = leerLS("saludo_voz") || "si";
selVoz.addEventListener("change", () => {
  escribirLS("saludo_voz", selVoz.value);
  if (selVoz.value === "no") detenerSaludo();
});

/* --- bloque 23 --- */
/* ---------- Automático y autónomo ---------- */

/* 1) Filtros: se guardan al cambiarlos y se restauran al entrar (sin botón) */
const FILTROS_AUTO = "filtros_ultimos";
function guardarFiltrosAuto() {
  try {
    const v = { orden: $("orden").value };
    Object.entries(sel).forEach(([k, el]) => { v[k] = el.value; });
    localStorage.setItem(FILTROS_AUTO, JSON.stringify(v));
  } catch (e) {}
}
function restaurarFiltrosAuto() {
  let v = null;
  try { v = JSON.parse(localStorage.getItem(FILTROS_AUTO) || "null"); } catch (e) {}
  if (!v) return;
  const aplicar = (el, valor) => {
    if (el && valor !== undefined && el.value !== valor && [...el.options].some(o => o.value === valor)) {
      el.value = valor;
      el.dispatchEvent(new Event("change"));
    }
  };
  Object.entries(sel).forEach(([k, el]) => aplicar(el, v[k]));
  aplicar($("orden"), v.orden);
}
document.addEventListener("change", e => {
  if (e.target === $("orden") || Object.values(sel).includes(e.target)) guardarFiltrosAuto();
});

/* 2) Estado de la copia: visible en Ajustes, sin buscarlo */
function tiempoHace(ms) {
  const m = Math.round(ms / 60000);
  if (m < 1) return "hace un momento";
  if (m < 60) return "hace " + m + " min";
  const h = Math.round(m / 60);
  if (h < 24) return "hace " + h + " h";
  const d = Math.round(h / 24);
  return "hace " + d + " día" + (d === 1 ? "" : "s");
}
function actualizarCopiaEstado() {
  const el = $("copiaEstado");
  if (!el) return;
  let t = Number(leerLS("copia_marcas_fecha") || 0);
  try {
    const c = JSON.parse(localStorage.getItem("catalogo_hoja_cache") || "null");
    if (c && c.fecha) t = Math.max(t, Date.parse(c.fecha) || 0);
  } catch (e) {}
  el.textContent = t ? "Última copia: " + tiempoHace(Date.now() - t) : "Aún no hay copias en este navegador.";
}
if (typeof syncTodo === "function") {
  const syncOriginal = syncTodo;
  syncTodo = async function () {
    const r = await syncOriginal.apply(this, arguments);
    try {
      if (accessToken && syncContarPendientes() === 0) escribirLS("copia_marcas_fecha", String(Date.now()));
    } catch (e) {}
    actualizarCopiaEstado();
    return r;
  };
}
actualizarCopiaEstado();
setInterval(actualizarCopiaEstado, 60000);

/* 3) Pendientes viejos: más de 60 días en la lista */
function pendientesViejos() {
  const limite = Date.now() - 60 * 86400000;
  return peliculas.filter(p => {
    const m = marcas[p.titulo] || {};
    if (!m.pendiente || m.vista || !m.pendienteDesde) return false;
    return Date.parse(m.pendienteDesde) < limite;
  }).map(p => p.titulo);
}

/* 4) Hoy se actualiza solo cuando cambia la hora */
setInterval(() => { if (typeof renderHoy === "function") renderHoy(); }, 600000);

/* 5) Paletas: se guardan solas después de que la cuenta dueña lo confirme con el botón */
let ultimoEstadoTexto = "";
if (typeof setEstado === "function") {
  const setEstadoOriginal = setEstado;
  setEstado = function (m) { ultimoEstadoTexto = String(m || ""); return setEstadoOriginal.apply(this, arguments); };
}
$("guardarPaletas").addEventListener("click", () => {
  const inicio = Date.now();
  const t = setInterval(() => {
    if (Date.now() - inicio > 90000) { clearInterval(t); return; }
    if (/Calculando/i.test(ultimoEstadoTexto)) return;
    clearInterval(t);
    if (ultimoEstadoTexto && !/dueña|No pude/i.test(ultimoEstadoTexto)) escribirLS("paletas_duena", "1");
  }, 700);
});
function paletasAutomaticas() {
  if (leerLS("paletas_duena") !== "1" || typeof guardarPaletasEnHoja !== "function") return;
  if (peliculas.some(p => p.portada && !paletaDeTexto(p[NOMBRE_PALETA]).length)) guardarPaletasEnHoja();
}

/* Memoria de gustos: ajuste visible */
const selGustos = $("gustos-memoria");
selGustos.value = leerLS("gustos_memoria") === "no" ? "no" : "si";
selGustos.addEventListener("change", () => escribirLS("gustos_memoria", selGustos.value));

/* Arranque: cuando el catálogo ya cargó */
const esperaAuto = setInterval(() => {
  if (typeof peliculas === "undefined" || !peliculas.length) return;
  clearInterval(esperaAuto);
  setTimeout(() => { restaurarFiltrosAuto(); paletasAutomaticas(); }, 800);
}, 500);

/* --- bloque 24 --- */
/* ---------- Modelo local opcional: entiende frases libres sin internet (se descarga una sola vez) ---------- */
const MODELO_LOCAL_ID = "Qwen2.5-0.5B-Instruct-q4f16_1-MLC";
const MODELO_LOCAL_LIB = "https://esm.sh/@mlc-ai/web-llm@0.2.79";
let motorLocal = null;
let motorLocalCargando = null;

function resumenCatalogoParaModelo() {
  const mk = p => marcas[p.titulo] || {};
  const linea = p => "- " + p.titulo + " (" + (p["año"] || "s/a") + ", " + (generosDe(p).join("/") || "s/g") + ", " + (minutos(p) || "?") + " min)";
  const pend = peliculas.filter(p => mk(p).pendiente && !mk(p).vista).slice(0, 25);
  const vist = peliculas.filter(p => mk(p).vista).slice(-12);
  return "Pendientes:\n" + pend.map(linea).join("\n") + "\nYa vistas:\n" + vist.map(linea).join("\n");
}

async function cargarModeloLocal(onProgreso) {
  if (motorLocal) return motorLocal;
  if (!navigator.gpu) throw new Error("sin-webgpu");
  if (!motorLocalCargando) {
    motorLocalCargando = (async () => {
      const webllm = await import(MODELO_LOCAL_LIB);
      motorLocal = await webllm.CreateMLCEngine(MODELO_LOCAL_ID, {
        initProgressCallback: r => { if (onProgreso) onProgreso(r); }
      });
      return motorLocal;
    })().finally(() => { motorLocalCargando = null; });
  }
  return motorLocalCargando;
}

async function respuestaConModelo(t, hist = []) {
  if (leerLS("modelo_local_modo") !== "si" || !motorLocal) return null;
  const PROMPT = "Eres Estela, una amiga cinéfila que platica en español de México. Eres cálida, cercana y natural, como en una charla, no como un robot. Tutea a la persona. Responde con frases cortas y fluidas, sin listas, asteriscos ni encabezados. Si la persona cuenta cómo se siente, responde primero con empatía. Recomienda solo películas de la lista que te doy y no inventes títulos. Si la pregunta no es de cine ni de su lista, responde con amabilidad y vuelve al cine. Máximo cuatro frases.";
  try {
    const previos = (hist || []).slice(-6).map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content || "").slice(0, 400) }));
    const r = await motorLocal.chat.completions.create({
      messages: [{ role: "system", content: PROMPT + "\n\n" + resumenCatalogoParaModelo() }, ...previos, { role: "user", content: String(t).slice(0, 500) }],
      max_tokens: 200,
      temperature: 0.75,
      top_p: 0.9
    });
    const txt = r && r.choices && r.choices[0] && r.choices[0].message && r.choices[0].message.content;
    return txt ? txt.trim() : null;
  } catch (e) { return null; }
}

const btnModelo = $("modeloDescargar");
const estadoModelo = $("modeloEstado");
const selModelo = $("modelo-local-modo");
selModelo.value = leerLS("modelo_local_modo") || "no";

function pintarEstadoModelo(texto) {
  if (texto) { estadoModelo.textContent = texto; return; }
  if (motorLocal) estadoModelo.textContent = "Listo: Estela entiende frases libres sin internet.";
  else if (!navigator.gpu) estadoModelo.textContent = "Este navegador no puede ejecutar el modelo local. Sigue funcionando el modo sin IA.";
  else estadoModelo.textContent = "Sin descargar. Conviene hacerlo con Wi-Fi.";
}

let descargaEnCurso = false;

async function descargarModelo() {
  if (descargaEnCurso || motorLocal) { pintarEstadoModelo(); return; }
  if (!navigator.gpu) { pintarEstadoModelo(); return; }
  descargaEnCurso = true;
  btnModelo.disabled = true;
  pintarEstadoModelo("Preparando la descarga…");
  // Si tarda demasiado, lo dice en vez de quedarse en silencio. Lo ya descargado se conserva.
  const vigilante = setTimeout(() => {
    if (!motorLocal) pintarEstadoModelo("Tarda más de lo normal. Revisa tu conexión y que tu navegador tenga WebGPU. Puedes dejarlo y volver después.");
  }, 45000);
  try {
    await cargarModeloLocal(r => pintarEstadoModelo("Descargando… " + Math.round((r.progress || 0) * 100) + "%"));
    escribirLS("modelo_local_modo", "si");
    selModelo.value = "si";
    pintarEstadoModelo("Listo: Estela entiende frases libres sin internet.");
  } catch (e) {
    const detalle = e && e.message ? " (" + String(e.message).slice(0, 80) + ")" : "";
    pintarEstadoModelo("No se pudo descargar el modelo" + detalle + ". Revisa tu conexión y vuelve a intentarlo.");
  } finally {
    clearTimeout(vigilante);
    descargaEnCurso = false;
    btnModelo.disabled = false;
  }
}

btnModelo.addEventListener("click", () => descargarModelo());
selModelo.addEventListener("change", () => escribirLS("modelo_local_modo", selModelo.value));
pintarEstadoModelo();

// Si ya se descargó antes, lo carga solo en segundo plano (la caché del navegador lo hace rápido)
if (leerLS("modelo_local_modo") === "si" && navigator.gpu) {
  setTimeout(() => { cargarModeloLocal().then(() => pintarEstadoModelo()).catch(() => pintarEstadoModelo()); }, 4000);
}

/* --- bloque 25 --- */
/* ---------- App instalable y actualización progresiva ---------- */
const esIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
const esInstalada = window.matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
let promptInstalar = null;
let pedidoActualizar = false;

function mostrarAvisoPwa(texto, acciones, id = "pwaAviso") {
  cerrarAvisoPwa(id);
  const div = document.createElement("div");
  div.id = id;
  div.className = "pwa-aviso";
  div.setAttribute("role", "status");
  const p = document.createElement("p");
  p.textContent = texto;
  const grupo = document.createElement("div");
  grupo.className = "pwa-acciones";
  acciones.forEach(a => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = a.principal ? "pildora destacado" : "pildora";
    b.textContent = a.texto;
    b.addEventListener("click", () => { a.accion(); });
    grupo.appendChild(b);
  });
  div.appendChild(p);
  div.appendChild(grupo);
  document.body.appendChild(div);
}

function cerrarAvisoPwa(id) {
  // Sin id, cierra cualquiera de los dos avisos
  const ids = id ? [id] : ["pwaAviso", "pwaAvisoInstalar"];
  ids.forEach(x => { const a = document.getElementById(x); if (a) a.remove(); });
}

function pintarInstalar() {
  const campo = document.getElementById("campoInstalar");
  const btn = document.getElementById("instalarApp");
  const estado = document.getElementById("instalarEstado");
  if (!campo || !btn) return;
  if (esInstalada) { campo.style.display = "none"; return; }
  if (promptInstalar) {
    btn.disabled = false;
    estado.textContent = "Ábrela como una app, con su icono y sin barra de direcciones.";
  } else if (esIOS) {
    btn.disabled = false;
    estado.textContent = "En iPhone: toca Compartir y luego «Añadir a pantalla de inicio».";
  } else {
    btn.disabled = true;
    estado.textContent = "Tu navegador lo instala desde su menú (⋮ → Instalar app).";
  }
}

window.addEventListener("beforeinstallprompt", e => {
  e.preventDefault();
  promptInstalar = e;
  pintarInstalar();
});
window.addEventListener("appinstalled", () => {
  promptInstalar = null;
  pintarInstalar();
  cerrarAvisoPwa();
});

async function instalarAhora() {
  if (promptInstalar) {
    promptInstalar.prompt();
    try { await promptInstalar.userChoice; } catch (e) {}
    promptInstalar = null;
    pintarInstalar();
    return;
  }
  if (esIOS) {
    mostrarAvisoPwa("Toca el botón Compartir de Safari y luego «Añadir a pantalla de inicio».", [
      { texto: "Entendido", principal: true, accion: () => { escribirLS("instalar_visto", "1"); cerrarAvisoPwa(); } }
    ], "pwaAvisoInstalar");
  }
}

function avisarActualizacion(reg) {
  if (!reg.waiting) return;
  cerrarAvisoPwa("pwaAvisoInstalar");
  mostrarAvisoPwa("Hay una versión nueva de la app.", [
    { texto: "Actualizar", principal: true, accion: () => {
      pedidoActualizar = true;
      reg.waiting.postMessage({ type: "SKIP_WAITING" });
    } },
    { texto: "Después", accion: cerrarAvisoPwa }
  ]);
}

function ofrecerInstalarUnaVez() {
  if (esInstalada || leerLS("instalar_visto") === "1") return;
  if (document.getElementById("pwaAviso")) return; // la actualización tiene prioridad
  if (promptInstalar) {
    mostrarAvisoPwa("Instala Mi catálogo en tu pantalla de inicio para abrirlo como app.", [
      { texto: "Instalar", principal: true, accion: () => { instalarAhora(); cerrarAvisoPwa(); escribirLS("instalar_visto", "1"); } },
      { texto: "Ahora no", accion: () => { escribirLS("instalar_visto", "1"); cerrarAvisoPwa(); } }
    ], "pwaAvisoInstalar");
  } else if (esIOS) {
    mostrarAvisoPwa("Para tenerla como app: toca Compartir y «Añadir a pantalla de inicio».", [
      { texto: "Entendido", principal: true, accion: () => { escribirLS("instalar_visto", "1"); cerrarAvisoPwa(); } }
    ], "pwaAvisoInstalar");
  }
}

document.getElementById("instalarApp").addEventListener("click", instalarAhora);
pintarInstalar();

if ("serviceWorker" in navigator) {
  window.addEventListener("load", async () => {
    try {
      const reg = await navigator.serviceWorker.register("sw.js");
      if (reg.waiting && navigator.serviceWorker.controller) avisarActualizacion(reg);
      reg.addEventListener("updatefound", () => {
        const nuevo = reg.installing;
        if (!nuevo) return;
        nuevo.addEventListener("statechange", () => {
          if (nuevo.state === "installed" && navigator.serviceWorker.controller) avisarActualizacion(reg);
        });
      });
    } catch (e) { /* sin service worker: la app sigue funcionando normal */ }
  });
  // Solo recarga si la persona pidió «Actualizar»; la primera instalación no recarga
  navigator.serviceWorker.addEventListener("controllerchange", () => {
    if (pedidoActualizar) location.reload();
  });
}

// Oferta de instalación: una sola vez, después de que la app ya cargó
setTimeout(() => {
  if (document.body.classList.contains("con-sesion")) ofrecerInstalarUnaVez();
}, 9000);

/* --- bloque 26 --- */
/* ---------- Descarga automática del modelo (con permiso, solo con Wi-Fi y batería) ---------- */
function wifiDisponible() {
  const c = navigator.connection;
  return !!(c && c.type === "wifi");
}

async function bateriaSuficiente() {
  try {
    if (!navigator.getBattery) return true;
    const b = await navigator.getBattery();
    return b.charging || b.level >= 0.5;
  } catch (e) { return true; }
}

async function intentarDescargaAutomatica() {
  if (leerLS("modelo_auto") !== "si" || leerLS("modelo_local_modo") === "no") return;
  if (motorLocal || descargaEnCurso || !navigator.gpu) return;
  if (!wifiDisponible()) { pintarEstadoModelo("Se descargará sola cuando estés en Wi-Fi."); return; }
  if (!(await bateriaSuficiente())) { pintarEstadoModelo("Se descargará sola cuando tengas más batería o conectes el cargador."); return; }
  descargarModelo();
}

function pedirPermisoModelo() {
  mostrarAvisoPwa("¿Quieres que Estela se descargue sola para funcionar sin internet? Pesa unos 400 MB y solo se descarga con Wi-Fi y batería suficiente.", [
    { texto: "Sí, con Wi-Fi", principal: true, accion: () => {
        escribirLS("modelo_auto", "si");
        cerrarAvisoPwa("pwaAvisoModelo");
        intentarDescargaAutomatica();
    } },
    { texto: "No por ahora", accion: () => {
        escribirLS("modelo_auto", "no");
        cerrarAvisoPwa("pwaAvisoModelo");
    } }
  ], "pwaAvisoModelo");
}

// Una sola vez, cuando ya cargó la app y no hay otros avisos encima
setTimeout(() => {
  if (!document.body.classList.contains("con-sesion")) return;
  if (!navigator.gpu || motorLocal || leerLS("modelo_local_modo") === "no") return;
  if (leerLS("modelo_auto") !== null) { intentarDescargaAutomatica(); return; }
  if (document.getElementById("pwaAviso") || document.getElementById("pwaAvisoInstalar")) return;
  pedirPermisoModelo();
}, 20000);

// Reintenta cuando cambia la conexión o cada 10 minutos
if (navigator.connection && navigator.connection.addEventListener) {
  navigator.connection.addEventListener("change", intentarDescargaAutomatica);
}
setInterval(intentarDescargaAutomatica, 10 * 60 * 1000);

/* --- bloque 27 --- */
/* ---------- Automatización de la experiencia (etapa 4) ---------- */
let tarjetaMostradaSesion = false;

// Fecha actual; para probar, guarda una fecha en el navegador: localStorage.setItem("fecha_prueba", "2026-11-09")
function fechaAuto() {
  const p = leerLS("fecha_prueba");
  if (p && /^\d{4}-\d{2}-\d{2}$/.test(p)) { const [y, m, d] = p.split("-").map(Number); return new Date(y, m - 1, d, 12); }
  return new Date();
}
function isoAuto(d) {
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}
function semanaAuto(d) {
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dia = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - dia);
  const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  const n = Math.ceil(((t - y0) / 86400000 + 1) / 7);
  return t.getUTCFullYear() + "-S" + String(n).padStart(2, "0");
}
function lunesAuto(d) {
  const x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  x.setDate(x.getDate() - ((x.getDay() || 7) - 1));
  return x;
}
function interruptorAuto(clave) { return leerLS(clave) !== "no"; }
function sugeridasRecientes() {
  try { return JSON.parse(leerLS("auto_sugeridas") || "[]"); } catch (e) { return []; }
}

function candidataSaga(hoy) {
  const mk = t => marcas[t] || {};
  const empezadas = new Set(peliculas
    .filter(p => mk(p.titulo).vista && String(p.saga || "").trim() && String(p.saga).trim() !== "-")
    .map(p => String(p.saga).trim()));
  const ahora = hoy.getTime();
  const p = peliculas.find(x => {
    const s = String(x.saga || "").trim();
    if (!s || s === "-" || !empezadas.has(s)) return false;
    const m = mk(x.titulo);
    if (m.vista || m.descartada || leerLS("auto_saga_" + x.titulo) === "1") return false;
    const f = Date.parse(String(x.estreno || "").slice(0, 10));
    if (!f) return false;
    const dias = (f - ahora) / 86400000;
    return dias >= -14 && dias <= 30;
  });
  if (!p) return null;
  const f = String(p.estreno).slice(0, 10);
  return {
    clave: "auto_saga_" + p.titulo, tipo: "Saga",
    titulo: "Se estrena algo de «" + p.saga + "»",
    texto: "«" + p.titulo + "» " + (f > isoAuto(hoy) ? "llega el " + f : "se estrenó el " + f) + ". Ya empezaste esta saga."
  };
}

function candidataFinde(hoy) {
  const dia = hoy.getDay();
  if (dia !== 5 && dia !== 6 && dia !== 0) return null;
  const clave = "auto_finde_" + semanaAuto(hoy);
  if (leerLS(clave) === "1") return null;
  const mk = t => marcas[t] || {};
  const recientes = new Set(sugeridasRecientes().filter(x => Date.now() - x.f < 7 * 86400000).map(x => x.t));
  const pool = peliculas.filter(p => {
    const m = mk(p.titulo);
    const min = minutos(p);
    return m.pendiente && !m.vista && !m.descartada && min > 0 && min <= 120 && !recientes.has(p.titulo);
  });
  if (!pool.length) return null;
  const elegida = pool[Math.floor(Math.random() * pool.length)];
  let texto = "Para esta noche: «" + elegida.titulo + "» (" + minutos(elegida) + " min).";
  const resto = pool.filter(p => p !== elegida).sort(() => Math.random() - 0.5);
  let total = minutos(elegida);
  const maraton = [elegida];
  for (const p of resto) {
    if (maraton.length >= 3) break;
    if (total + minutos(p) <= 240) { maraton.push(p); total += minutos(p); }
  }
  if (maraton.length >= 2) texto += " Si quieres maratón: " + maraton.map(p => "«" + p.titulo + "»").join(" + ") + " (" + total + " min en total).";
  const guardar = JSON.parse(leerLS("auto_sugeridas") || "[]").concat(maraton.map(p => ({ t: p.titulo, f: Date.now() })));
  escribirLS("auto_sugeridas", JSON.stringify(guardar.slice(-30)));
  return { clave: clave, tipo: "Fin de semana", titulo: "Para este fin de semana", texto: texto };
}

function candidataLunes(hoy) {
  const clave = "auto_lunes_" + semanaAuto(hoy);
  if (leerLS(clave) === "1") return null;
  const mk = t => marcas[t] || {};
  const inicioSem = lunesAuto(hoy);
  const inicioAnt = new Date(inicioSem); inicioAnt.setDate(inicioAnt.getDate() - 7);
  const finAnt = new Date(inicioSem); finAnt.setDate(finAnt.getDate() - 1);
  const a = isoAuto(inicioAnt), b = isoAuto(finAnt);
  const vistas = peliculas.filter(p => { const d = String(mk(p.titulo).vistaDesde || ""); return mk(p.titulo).vista && d >= a && d <= b; }).length;
  const pend = peliculas.filter(p => mk(p.titulo).pendiente && !mk(p.titulo).vista && !mk(p.titulo).descartada).length;
  const reto = retoActual();
  const planes = recordatoriosActivos().length;
  let texto = vistas
    ? "La semana pasada viste " + vistas + " película" + (vistas === 1 ? "" : "s") + ". Te quedan " + pend + " pendiente" + (pend === 1 ? "" : "s") + "."
    : "Semana tranquila. ¿Retomamos algún pendiente?";
  texto += " 🏆 " + reto.texto + ".";
  if (planes) texto += " Tienes " + planes + " plan" + (planes === 1 ? "" : "es") + " con alguien en los próximos días.";
  return { clave: clave, tipo: "Resumen", titulo: "Tu semana", texto: texto };
}

function renderTarjetaAuto() {
  const sec = $("tarjetaAuto");
  if (!sec || tarjetaMostradaSesion || !document.body.classList.contains("con-sesion") || !peliculas.length) return;
  const hoy = fechaAuto();
  const opciones = [
    { on: "auto-lunes", fn: () => candidataLunes(hoy) },
    { on: "auto-viernes", fn: () => candidataFinde(hoy) },
    { on: "auto-sagas", fn: () => candidataSaga(hoy) }
  ];
  // Prioridad: saga, fin de semana, resumen. Una tarjeta por entrada.
  const orden = [opciones[2], opciones[1], opciones[0]];
  for (const o of orden) {
    const clave = o.on === "auto-sagas" ? "auto_sagas" : o.on === "auto-viernes" ? "auto_viernes" : "auto_lunes";
    if (leerLS(clave) === "no") continue;
    const c = o.fn();
    if (!c) continue;
    if (c.clave.indexOf("auto_lunes_") === 0 || c.clave.indexOf("auto_finde_") === 0) escribirLS(c.clave, "1");
    if (c.clave.indexOf("auto_saga_") === 0) escribirLS(c.clave, "1");
    sec.innerHTML =
      '<button type="button" class="saludo-cerrar" data-accion="cerrar-auto" aria-label="Cerrar">×</button>' +
      '<h2>' + esc(c.titulo) + '</h2><p>' + esc(c.texto) + '</p>';
    sec.style.display = "block";
    tarjetaMostradaSesion = true;
    return;
  }
}

$("tarjetaAuto").addEventListener("click", e => {
  if (e.target.closest("[data-accion='cerrar-auto']")) {
    $("tarjetaAuto").style.display = "none";
  }
});
setTimeout(renderTarjetaAuto, 15000);


/* ===== FASE 4: ficha como hoja (comportamiento) ===== */
(function fichaHoja() {
  const modal = document.getElementById("modal");
  if (!modal) return;

  function prepararFicha() {
    const caja = modal.querySelector(".ventana");
    if (!caja) return;
    if (!caja.querySelector(".ficha-compacta")) {
      const barra = document.createElement("div");
      barra.className = "ficha-compacta";
      barra.id = "fichaCompacta";
      caja.insertBefore(barra, caja.firstChild);
    }
    if (!caja.querySelector(".ficha-cerrar-abajo")) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "ficha-cerrar-abajo";
      b.id = "fichaCerrarAbajo";
      b.textContent = "Cerrar";
      b.addEventListener("click", () => { const x = document.getElementById("cerrarModal"); if (x) x.click(); });
      caja.appendChild(b);
    }
    if (!caja.dataset.fichaListo) {
      caja.dataset.fichaListo = "1";
      caja.addEventListener("scroll", actualizarCompacta, { passive: true });
      // El color del póster debe ganar a las reglas del tema: se fija como !important
      new MutationObserver(() => {
        const bg = caja.style.getPropertyValue("background");
        if (bg && caja.style.getPropertyPriority("background") !== "important") {
          caja.style.setProperty("background", bg, "important");
        }
      }).observe(caja, { attributes: true, attributeFilter: ["style"] });
    }
  }

  function actualizarCompacta() {
    const caja = modal.querySelector(".ventana");
    const h2 = document.querySelector("#detalle h2");
    const barra = document.getElementById("fichaCompacta");
    if (!caja || !h2 || !barra) return;
    const compacta = h2.getBoundingClientRect().bottom < caja.getBoundingClientRect().top + 56;
    // Solo escribir si cambia: escribir la misma clase dispara el observador otra vez (bucle infinito)
    if (modal.classList.contains("ficha-es-compacta") !== compacta) modal.classList.toggle("ficha-es-compacta", compacta);
    barra.textContent = h2.textContent;
  }

  function colorDelPoster() {
    const caja = modal.querySelector(".ventana");
    if (!caja || typeof detalleActual === "undefined" || !detalleActual) return;
    const c = paletaDeTexto(detalleActual[NOMBRE_PALETA])[0];
    caja.style.setProperty("--acento", c ? "rgb(" + c.join(",") + ")" : "var(--azul)");
  }

  // Al abrir la ficha: prepara la hoja, el color y el encabezado.
  // Reacciona solo al CAMBIO de estado abierto/cerrado, y nunca escribe una clase que ya está como debe.
  let abiertoAntes = null;
  new MutationObserver(() => {
    const abierto = modal.classList.contains("abierto");
    if (abierto === abiertoAntes) return;
    abiertoAntes = abierto;
    if (abierto) {
      prepararFicha();
      colorDelPoster();
      if (modal.classList.contains("ficha-es-compacta")) modal.classList.remove("ficha-es-compacta");
      const caja = modal.querySelector(".ventana");
      if (caja) caja.scrollTop = 0;
      setTimeout(actualizarCompacta, 50);
    } else if (modal.classList.contains("ficha-es-compacta")) {
      modal.classList.remove("ficha-es-compacta");
    }
  }).observe(modal, { attributes: true, attributeFilter: ["class"] });
})();


/* ===== FASE 7: foco de teclado en la ficha ===== */
(function focoFicha() {
  const modal = document.getElementById("modal");
  if (!modal) return;
  let quienAbrio = null;

  // Semántica: la ficha se anuncia como diálogo
  const caja0 = modal.querySelector(".ventana");
  if (caja0) {
    caja0.setAttribute("role", "dialog");
    caja0.setAttribute("aria-modal", "true");
    caja0.setAttribute("aria-label", "Ficha de película");
  }

  function enfocables() {
    const caja = modal.querySelector(".ventana");
    if (!caja) return [];
    return [...caja.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )].filter(el => el.offsetParent !== null || el.getClientRects().length);
  }

  // Al abrir: recordar quién abrió y llevar el foco dentro de la hoja
  let abiertoFoco = null;
  new MutationObserver(() => {
    const abierto = modal.classList.contains("abierto");
    if (abierto === abiertoFoco) return;
    abiertoFoco = abierto;
    if (abierto) {
      quienAbrio = document.activeElement;
      setTimeout(() => {
        const primero = document.getElementById("cerrarModal") || enfocables()[0];
        if (primero) primero.focus({ preventScroll: true });
      }, 60);
    } else if (quienAbrio) {
      // Al cerrar: devolver el foco a quien abrió la ficha, si todavía existe
      const destino = quienAbrio;
      quienAbrio = null;
      if (document.body.contains(destino) && typeof destino.focus === "function") {
        destino.focus({ preventScroll: true });
      }
    }
  }).observe(modal, { attributes: true, attributeFilter: ["class"] });

  // Tab no sale de la ficha mientras está abierta
  document.addEventListener("keydown", e => {
    if (e.key !== "Tab" || !modal.classList.contains("abierto")) return;
    const lista = enfocables();
    if (!lista.length) return;
    const primero = lista[0], ultimo = lista[lista.length - 1];
    const dentro = modal.contains(document.activeElement);
    if (!dentro) {
      e.preventDefault();
      (e.shiftKey ? ultimo : primero).focus();
    } else if (e.shiftKey && document.activeElement === primero) {
      e.preventDefault();
      ultimo.focus();
    } else if (!e.shiftKey && document.activeElement === ultimo) {
      e.preventDefault();
      primero.focus();
    }
  });
})();


/* ===== FASE 8 · PARTE 3: Series en la app ===== */
(function seriesApp() {
  let seriesCat = [];
  let episodiosCat = {};
  let serieActual = null;

  const claveCap = e => e.temporada + "x" + e.episodio;
  const capsDe = titulo => ((marcas[titulo] || {}).capitulos) || {};

  function aplicarSeries(copia) {
    const filas = f => { const enc = f[0] || []; return f.slice(1).map(r => Object.fromEntries(enc.map((h, i) => [h, r[i] || ""]))); };
    seriesCat = filas(copia.series || []).filter(s => s.titulo);
    episodiosCat = {};
    filas(copia.episodios || []).forEach(e => {
      if (!e.serie) return;
      (episodiosCat[e.serie] = episodiosCat[e.serie] || []).push(e);
    });
    Object.values(episodiosCat).forEach(l => l.sort((a, b) =>
      (Number(a.temporada) - Number(b.temporada)) || (Number(a.episodio) - Number(b.episodio))));
  }

  function usarCache() {
    try { const c = JSON.parse(localStorage.getItem("series_cache") || "null"); if (c) aplicarSeries(c); } catch (e) {}
  }

  async function cargarSeriesApp() {
    if (!accessToken || !navigator.onLine || !HOJA_ID) { usarCache(); return; }
    try {
      const cab = { headers: { Authorization: "Bearer " + accessToken } };
      const [rs, re] = await Promise.all([
        fetch(`https://sheets.googleapis.com/v4/spreadsheets/${HOJA_ID}/values/series!A:Z`, cab),
        fetch(`https://sheets.googleapis.com/v4/spreadsheets/${HOJA_ID}/values/episodios!A:I`, cab)
      ]);
      if (!rs.ok || !re.ok) { usarCache(); return; }
      const copia = { series: (await rs.json()).values || [], episodios: (await re.json()).values || [] };
      localStorage.setItem("series_cache", JSON.stringify(copia));
      aplicarSeries(copia);
    } catch (e) { usarCache(); }
  }

  function progresoSerie(s) {
    const lista = episodiosCat[s.titulo] || [];
    const caps = capsDe(s.titulo);
    const vistos = lista.filter(e => caps[claveCap(e)]).length;
    const siguiente = lista.find(e => !caps[claveCap(e)]);
    return { total: lista.length, vistos: vistos, siguiente: siguiente };
  }

  function renderSeriesLista() {
    const cont = document.getElementById("seriesLista");
    if (!cont) return;
    if (!seriesCat.length) {
      cont.innerHTML = '<p class="meta">Aún no hay series cargadas. Revisa que se hayan ejecutado cargarSeries y cargarEpisodios en Apps Script.</p>';
      return;
    }
    const grupos = {};
    seriesCat.forEach(s => { const g = s.genero_principal || "Otros"; (grupos[g] = grupos[g] || []).push(s); });
    cont.innerHTML = Object.keys(grupos).map(g =>
      '<div class="serie-grupo"><h3>' + esc(g) + '</h3>' + grupos[g].map(s => {
        const pr = progresoSerie(s);
        const pct = pr.total ? Math.round(pr.vistos / pr.total * 100) : 0;
        const sig = pr.siguiente ? "Sigue: T" + pr.siguiente.temporada + " · E" + pr.siguiente.episodio
          : (pr.total ? "¡Al día!" : "Sin capítulos cargados");
        return '<button type="button" class="serie-card" data-serie="' + esc(s.titulo) + '">' +
          (s.portada ? '<img src="' + esc(s.portada) + '" alt="" loading="lazy" decoding="async">' : '') +
          '<span class="serie-info"><strong>' + esc(s.titulo) + '</strong>' +
          '<span class="meta">' + esc(s.año || "") + ' · ' + esc(s.temporadas || "?") + ' temp. · ' + pr.vistos + '/' + pr.total + ' capítulos</span>' +
          '<span class="serie-barra"><span style="width:' + pct + '%"></span></span>' +
          '<span class="meta">' + esc(sig) + '</span></span></button>';
      }).join("") + '</div>').join("");
  }

  function abrirSerieDetalle(titulo) {
    const s = seriesCat.find(x => x.titulo === titulo);
    const cont = document.getElementById("seriesLista");
    if (!s || !cont) return;
    serieActual = titulo;
    const caps = capsDe(titulo);
    const porTemp = {};
    (episodiosCat[titulo] || []).forEach(e => { (porTemp[e.temporada] = porTemp[e.temporada] || []).push(e); });
    cont.innerHTML =
      '<button type="button" class="pildora" id="serieVolver">← Series</button>' +
      '<h2 class="serie-titulo">' + esc(s.titulo) + '</h2>' +
      '<p class="meta">' + esc(s.año || "") + ' · ' + esc(s.genero || "") + '</p>' +
      '<p class="serie-sinopsis">' + esc(s.sinopsis || "") + '</p>' +
      Object.keys(porTemp).map(t => {
        const eps = porTemp[t];
        const v = eps.filter(e => caps[claveCap(e)]).length;
        return '<section class="temp"><div class="temp-h"><strong>Temporada ' + esc(t) + '</strong>' +
          '<span class="meta">' + v + '/' + eps.length + '</span>' +
          '<button type="button" class="pildora" data-marcar-temp="' + esc(t) + '">' + (v === eps.length ? "Desmarcar" : "Marcar todo") + '</button></div>' +
          eps.map(e => '<button type="button" class="cap' + (caps[claveCap(e)] ? ' visto' : '') + '" data-cap="' + claveCap(e) + '">' +
            '<span class="cap-check">' + (caps[claveCap(e)] ? "✓" : "") + '</span>' +
            '<span>' + esc(e.episodio) + '. ' + esc(e.titulo) + '</span>' +
            '<span class="meta">' + esc(e.estreno || "") + '</span></button>').join("") +
          '</section>';
      }).join("") || '<p class="meta">Esta serie todavía no tiene capítulos cargados.</p>';
  }

  function guardarCaps(titulo, caps) {
    cambiarEstado(titulo, { capitulos: caps });
  }

  function alternarCapitulo(clave) {
    const titulo = serieActual;
    const caps = Object.assign({}, capsDe(titulo));
    if (caps[clave]) delete caps[clave]; else caps[clave] = true;
    guardarCaps(titulo, caps);
    recargarDetalle();
  }

  function alternarTemporada(t) {
    const titulo = serieActual;
    const eps = (episodiosCat[titulo] || []).filter(e => String(e.temporada) === String(t));
    const caps = Object.assign({}, capsDe(titulo));
    const todoVisto = eps.every(e => caps[claveCap(e)]);
    eps.forEach(e => { if (todoVisto) delete caps[claveCap(e)]; else caps[claveCap(e)] = true; });
    guardarCaps(titulo, caps);
    recargarDetalle();
  }

  function recargarDetalle() {
    const cont = document.getElementById("seriesLista");
    const y = cont ? cont.parentElement.scrollTop : 0;
    abrirSerieDetalle(serieActual);
    if (cont) cont.parentElement.scrollTop = y;
  }

  const ventana = document.getElementById("seriesModal");
  const boton = document.getElementById("verSeries");
  if (!ventana || !boton) return;

  boton.addEventListener("click", () => {
    serieActual = null;
    renderSeriesLista();
    ventana.classList.add("abierto");
    cargarSeriesApp();
    setTimeout(() => { const c = document.getElementById("cerrarSeries"); if (c) c.focus(); }, 60);
  });
  document.getElementById("cerrarSeries").addEventListener("click", () => ventana.classList.remove("abierto"));
  ventana.addEventListener("click", e => { if (e.target === ventana) ventana.classList.remove("abierto"); });
  document.addEventListener("keydown", e => {
    if (e.key === "Escape" && ventana.classList.contains("abierto")) ventana.classList.remove("abierto");
  });

  document.getElementById("seriesLista").addEventListener("click", e => {
    const tarjeta = e.target.closest("[data-serie]");
    if (tarjeta) { abrirSerieDetalle(tarjeta.dataset.serie); return; }
    if (e.target.closest("#serieVolver")) { serieActual = null; renderSeriesLista(); return; }
    const cap = e.target.closest("[data-cap]");
    if (cap) { alternarCapitulo(cap.dataset.cap); return; }
    const temp = e.target.closest("[data-marcar-temp]");
    if (temp) alternarTemporada(temp.dataset.marcarTemp);
  });

  // Carga inicial y actualización cada 10 minutos, con sesión iniciada
  setTimeout(usarCache, 6000);
    window.seriesApi = {
    lista: () => seriesCat,
    progreso: progresoSerie,
    abrir: titulo => {
      ventana.classList.add("abierto");
      renderSeriesLista();
      abrirSerieDetalle(titulo);
    }
  };
})();

/* ---------- Curiosidad con botón: datos reales de tu colección, distinta cada vez ---------- */
const CURIO_VISTAS_KEY = "curio_vistas";
let curioActual = null;

function claveCurio(c) {
  return (c.peli ? c.peli.titulo : "") + "|" + (c.tema || "") + "|" + String(c.texto || "").slice(0, 40);
}

function curioVistas() {
  try { return JSON.parse(leerLS(CURIO_VISTAS_KEY) || "[]"); } catch (e) { return []; }
}

function marcarCurioVista(c) {
  const v = curioVistas().filter(x => x !== claveCurio(c));
  v.push(claveCurio(c));
  escribirLS(CURIO_VISTAS_KEY, JSON.stringify(v.slice(-60)));
}

// Prefiere lo que todavía no has visto; cuando ya viste todo, vuelve a empezar
function elegirCuriosidad() {
  const lista = todasLasCuriosidades();
  if (!lista.length) return null;
  const vistas = new Set(curioVistas());
  const nuevas = lista.filter(c => !vistas.has(claveCurio(c)));
  const pool = nuevas.length ? nuevas : lista;
  return pool[Math.floor(Math.random() * pool.length)];
}

// Historia breve armada solo con datos reales de la ficha (año, director, género, duración, sinopsis, reparto)
function historiaDe(p) {
  const partes = [];
  const anio = p["año"] ? String(p["año"]) : "";
  const dir = String(p.director || "").split(",")[0].trim();
  const gen = String(p.genero || "").split(",")[0].trim();
  const dur = String(p.duracion || "").trim();
  const frase = String(p.sinopsis || "").split(/(?<=[.!?])\s+/)[0] || "";
  const rep = String(p.reparto || "").split(",").map(x => x.trim()).filter(Boolean).slice(0, 2);
  const variantes = [
    () => [anio && dir ? "En " + anio + ", " + dir + " llevó a la pantalla «" + p.titulo + "»." : null, frase],
    () => ["«" + p.titulo + "»" + (anio ? " (" + anio + ")" : "") + (gen ? " es un " + gen.toLowerCase() : "") + (dur ? " de " + dur : "") + ".", frase, rep.length ? "En el reparto están " + rep.join(" y ") + "." : null],
    () => [dir ? "Detrás de la película está " + dir + "." : null, frase, rep.length ? "Protagonizan " + rep.join(" y ") + "." : null]
  ];
  const elegida = variantes[Math.floor(Math.random() * variantes.length)]();
  return elegida.filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
}

const MESES_CURIO = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];

// Datos reales de la película: saga, país, estreno, duración, director, género, década
function hechosDePelicula(p) {
  const out = [];
  const saga = String(p.saga || "").trim();
  if (saga && saga !== "-") {
    const n = peliculas.filter(x => String(x.saga || "").trim() === saga).length;
    out.push("Es parte de la saga «" + saga + "». En tu colección hay " + n + " película" + (n === 1 ? "" : "s") + " de ella.");
  }
  const pais = String(p.pais || "").trim();
  if (pais) out.push("Se produjo en " + pais + ".");
  const est = String(p.estreno || "").trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(est)) {
    const [y, m, d] = est.split("-").map(Number);
    out.push("Llegó a los cines el " + d + " de " + MESES_CURIO[m - 1] + " de " + y + ".");
  }
  const min = minutos(p);
  if (min) out.push("Dura " + min + " minutos.");
  const dir = String(p.director || "").split(",")[0].trim();
  if (dir) {
    const n = peliculas.filter(x => String(x.director || "").split(",")[0].trim() === dir).length;
    if (n > 1) out.push(dir + " tiene " + n + " películas en tu colección.");
  }
  const anio = Number(p["año"]);
  if (anio) out.push("Es de los años " + (Math.floor(anio / 10) * 10) + ".");
  return out;
}

// Datos reales de los actores de la película (fuente: TMDB, guardados en tu hoja)
function hechosDeActores(p) {
  const out = [];
  const info = infoActores();
  nombresReparto(p).forEach(nombre => {
    const i = info[nombre] || {};
    if (i.lugar) out.push(nombre + " nació en " + i.lugar + ".");
    else if (/^\d{4}/.test(i.nacimiento || "")) out.push(nombre + " nació en " + String(i.nacimiento).slice(0, 4) + ".");
    const bio = String(i.bio || "").split(/(?<=[.!?])\s+/)[0] || "";
    if (bio.length > 20 && bio.length < 260) out.push(nombre + ": " + bio);
    const n = peliculas.filter(x => nombresReparto(x).indexOf(nombre) !== -1).length;
    if (n > 1) out.push(nombre + " aparece en " + n + " películas de tu colección.");
  });
  return out;
}

// Conexiones: "te suena porque…" (actor en otra película que ya viste) y "puente" (actor en otra pendiente)
function conexionesDe(p) {
  const out = [];
  const m = a => marcas[a.titulo] || {};
  const reparto = nombresReparto(p);
  reparto.forEach(nombre => {
    const otras = peliculas.filter(x => x.titulo !== p.titulo && nombresReparto(x).indexOf(nombre) !== -1);
    const vistas = otras.filter(x => m(x).vista);
    if (vistas.length) out.push("Te suena porque " + nombre + " también salió en «" + vistas[0].titulo + "», que ya marcaste como vista.");
    const pend = otras.filter(x => !m(x).vista && !m(x).descartada);
    if (pend.length) out.push("Si te gusta " + nombre + ", «" + pend[0].titulo + "» también está en tu lista por ver.");
  });
  const saga = String(p.saga || "").trim();
  if (saga && saga !== "-") {
    const vistasSaga = peliculas.filter(x => x.titulo !== p.titulo && String(x.saga || "").trim() === saga && m(x).vista).length;
    if (vistasSaga) out.push("De la saga «" + saga + "» ya viste " + vistasSaga + " más.");
  }
  return out;
}

// Spoilers: el texto que pueda revelar el final se oculta hasta que la persona lo pide
const PALABRAS_SPOILER = /(final|desenlace|muere|murió|muerte|termina|resulta que|el asesino|revela|traición|se descubre|al terminar)/i;
function esSpoiler(texto) { return PALABRAS_SPOILER.test(String(texto || "")); }
const CURIO_REVELADOS = new Set();

function unDato(lista) {
  return lista.length ? lista[Math.floor(Math.random() * lista.length)] : "";
}

// ---------- Pestaña de Curiosidades (fase 1) ----------
const CURIO_REAC_KEY = "curio_reacciones";
const CURIO_HIST_KEY = "curio_historial";
let curioFiltro = "todas";
let curioIdx = 0;
let curioLista = [];

function curioTipo(c) {
  const t = String(c.tema || "").toLowerCase();
  if (/internet/.test(t)) return "internet";
  if (/actor|reparto/.test(t)) return "actores";
  if (/saga/.test(t)) return "saga";
  return "pelicula";
}

// ---------- Fase 3: orden adaptativo ----------
// Relevancia (tus gustos) · novedad (no vista) · calidad (con fuente) · aprendizaje (tus reacciones)
// Diversidad: no pone dos del mismo tipo seguidas.
function perfilCurio() {
  const m = a => marcas[a.titulo] || {};
  const favoritas = peliculas.filter(p => m(p).vista && (m(p).estrellas || 0) >= 4);
  const perfil = { genero: {}, director: {}, actor: {} };
  const sumar = (obj, clave) => { if (clave) obj[clave] = (obj[clave] || 0) + 1; };
  favoritas.forEach(p => {
    generosDe(p).forEach(g => sumar(perfil.genero, g.toLowerCase()));
    sumar(perfil.director, String(p.director || "").split(",")[0].trim().toLowerCase());
    nombresReparto(p).slice(0, 4).forEach(a => sumar(perfil.actor, a.toLowerCase()));
  });
  return perfil;
}

function pesosCurio() {
  // Cuánto te gusta cada tipo de curiosidad, según tus reacciones
  const pesos = { pelicula: 0, actores: 0, saga: 0 };
  const reac = curioReacciones();
  Object.keys(reac).forEach(k => {
    const tipo = curioTipo({ tema: String(k.split("|")[1] || "") });
    const v = reac[k];
    if (v === "gusta") pesos[tipo] += 1;
    else if (v === "sabia") pesos[tipo] -= 0.5;
    else if (v === "no") pesos[tipo] -= 1;
  });
  return pesos;
}

function puntuarCurio(c, perfil, pesos, vistas, reac) {
  const p = c.peli || {};
  const genero = generosDe(p).some(g => perfil.genero[g.toLowerCase()]) ? 1 : 0;
  const dir = perfil.director[String(p.director || "").split(",")[0].trim().toLowerCase()] ? 1 : 0;
  const act = nombresReparto(p).some(a => perfil.actor[a.toLowerCase()]) ? 1 : 0;
  const relevancia = Math.min(1, (genero * 0.4) + (dir * 0.3) + (act * 0.3));
  const novedad = vistas.has(claveCurio(c)) ? 0.3 : 1;
  const calidad = c.fuente ? 1 : 0.6;
  const aprendizaje = Math.max(-1, Math.min(1, (pesos[curioTipo(c)] || 0) / 5));
  let score = relevancia * 0.4 + novedad * 0.3 + calidad * 0.2 + aprendizaje * 0.1;
  if (reac[claveCurio(c)] === "no") score -= 1;
  return score;
}

function curioFiltrada() {
  const base = todasLasCuriosidades().concat(curiosidadesInternet);
  const filtrada = (curioFiltro === "todas" ? base : base.filter(c => curioTipo(c) === curioFiltro)).filter(curioEstaSana);
  const perfil = perfilCurio(), pesos = pesosCurio(), vistas = new Set(curioVistas()), reac = curioReacciones();
  const ordenada = filtrada
    .map(c => ({ c: c, s: puntuarCurio(c, perfil, pesos, vistas, reac) }))
    .sort((a, b) => b.s - a.s)
    .map(x => x.c);
  // Diversidad: si la siguiente es del mismo tipo que la anterior, busca otra de distinto tipo cerca
  const salida = [];
  const quedan = ordenada.slice();
  while (quedan.length) {
    const ultimo = salida.length ? curioTipo(salida[salida.length - 1]) : null;
    let i = quedan.findIndex((c, k) => k < 4 && curioTipo(c) !== ultimo);
    if (i < 0) i = 0;
    salida.push(quedan.splice(i, 1)[0]);
  }
  return salida;
}

function curioReacciones() {
  try { return JSON.parse(leerLS(CURIO_REAC_KEY) || "{}"); } catch (e) { return {}; }
}

function curioHistorial() {
  try { return JSON.parse(leerLS(CURIO_HIST_KEY) || "[]"); } catch (e) { return []; }
}

function curioRegistrar(c, reaccion) {
  const k = claveCurio(c);
  const r = curioReacciones();
  if (reaccion) r[k] = reaccion;
  escribirLS(CURIO_REAC_KEY, JSON.stringify(r));
  const hist = curioHistorial().filter(x => x.k !== k);
  hist.unshift({ k: k, titulo: c.peli ? c.peli.titulo : "", texto: c.texto, ts: Date.now() });
  escribirLS(CURIO_HIST_KEY, JSON.stringify(hist.slice(0, 100)));
}

function curioProgreso() {
  const vistas = new Set(curioVistas());
  return curioLista.filter(c => vistas.has(claveCurio(c))).length;
}

function renderCuriosidadModal() {
  const body = $("curioBody");
  if (!body) return;
  curioLista = curioFiltrada();
  if (curioIdx >= curioLista.length) curioIdx = 0;
  const c = curioLista[curioIdx];
  const filtros = [["todas","Todas"],["pelicula","Película"],["actores","Actores"],["saga","Saga"],["internet","Internet"]];
  const barra = '<div class="cur-filtros" role="tablist">' + filtros.map(f =>
    '<button type="button" role="tab" aria-selected="' + (curioFiltro === f[0]) + '" class="cur-filtro' + (curioFiltro === f[0] ? ' activo' : '') + '" data-cur="filtro" data-valor="' + f[0] + '">' + f[1] + '</button>').join('') + '</div>';
  const diag = curioDiagnostico();
  const cabecera = '<p class="meta cur-diag">' + esc(diag) + '</p>' + '<div class="cur-cab"><h2 class="series-h2">Curiosidades</h2>' +
    '<button type="button" class="cur-icono" data-cur="historial" aria-label="Historial">🕘</button></div>' + barra;

  if (!curioLista.length) {
    body.innerHTML = cabecera + '<div class="cur-vacio"><p>Todavía no hay curiosidades para este filtro.</p><p class="meta">Agrega datos a la pestaña curiosidades o llena más películas, y aparecerán aquí.</p></div>';
    return;
  }

  const reac = curioReacciones()[claveCurio(c)] || "";
  const fondo = c.peli && c.peli.portada ? ' style="background-image:url(\'' + esc(c.peli.portada) + '\')"' : '';
  const deLaPeli = unDato(hechosDePelicula(c.peli));
  const deActores = unDato(hechosDeActores(c.peli));
  const conexion = unDato(conexionesDe(c.peli));
  const clave = claveCurio(c);
  const oculto = esSpoiler(c.texto) && !CURIO_REVELADOS.has(clave);
  const textoHtml = oculto
    ? '<p class="cur-texto cur-oculto" aria-hidden="true">' + esc(c.texto) + '</p><button type="button" class="pildora cur-revelar" data-cur="revelar">Revelar (contiene spoiler)</button>'
    : '<p class="cur-texto">' + esc(c.texto) + '</p>';
  const pos = (curioIdx + 1) + " de " + curioLista.length + " · " + curioProgreso() + " vistas";
  const reacBtn = (v, t) => '<button type="button" class="cur-reac' + (reac === v ? ' activo' : '') + '" data-cur="reac" data-valor="' + v + '" aria-pressed="' + (reac === v) + '">' + t + '</button>';

  body.innerHTML = cabecera +
    '<article class="cur-tarjeta" id="curioTarjeta">' +
      '<div class="cur-fondo"' + fondo + ' aria-hidden="true"></div>' +
      '<div class="cur-cuerpo">' +
        '<p class="cur-tema">' + esc(c.tema || "Dato") + ' · ' + esc(c.peli.titulo) + '</p>' +
        textoHtml +
        (c.fuente ? '<small class="cur-fuente">Fuente: ' + esc(c.fuente) + '</small>' : '') +
        (deLaPeli ? '<h3 class="cur-h3">Sobre la película</h3><p class="cur-historia">' + esc(deLaPeli) + '</p>' : '') +
        (deActores ? '<h3 class="cur-h3">Sobre sus actores</h3><p class="cur-historia">' + esc(deActores) + '</p>' : '') +
        (conexion ? '<h3 class="cur-h3">En tu colección</h3><p class="cur-historia">' + esc(conexion) + '</p>' : '') +
      '</div>' +
    '</article>' +
    '<div class="cur-nav">' +
      '<button type="button" class="cur-flecha" data-cur="ant" aria-label="Anterior">‹</button>' +
      '<span class="cur-pos" aria-live="polite">' + esc(pos) + '</span>' +
      '<button type="button" class="cur-flecha" data-cur="sig" aria-label="Siguiente">›</button>' +
    '</div>' +
    '<div class="cur-reacciones">' + reacBtn("gusta","👍 Me gusta") + reacBtn("sabia","✓ Ya lo sabía") + reacBtn("no","✕ No me interesa") + '</div>' +
    '<div class="cur-pie">' +
      '<button type="button" class="pildora" data-cur="compartir">Compartir</button>' +
      '<button type="button" class="pildora" data-cur="reportar">Reportar</button>' +
      '<button type="button" class="pildora" data-cur="ver">Ver ficha</button>' +
    '</div>';
  marcarCurioVista(c);
  curioRegistrar(c, null);
}

function renderCurioHistorial() {
  const body = $("curioBody");
  const hist = curioHistorial();
  body.innerHTML = '<div class="cur-cab"><button type="button" class="pildora" data-cur="volver">← Volver</button><h2 class="series-h2">Historial</h2></div>' +
    (hist.length ? '<ul class="cur-hist">' + hist.map(x =>
      '<li><strong>' + esc(x.titulo) + '</strong><span>' + esc(x.texto) + '</span></li>').join('') + '</ul>'
      : '<p class="meta">Aquí aparecen las curiosidades que ya viste.</p>');
}



function abrirCuriosidad() {
  curioActual = elegirCuriosidad();
  if (curioActual) marcarCurioVista(curioActual);
  renderCuriosidadModal(curioActual);
  const v = $("curioModal");
  if (v) v.classList.add("abierto");
}

function cerrarCuriosidad() {
  const v = $("curioModal");
  if (v) v.classList.remove("abierto");
}

(function curiosidadBoton() {
  const boton = $("btnCuriosidad"), ventana = $("curioModal");
  if (!boton || !ventana) return;
  boton.addEventListener("click", abrirCuriosidad);
  $("cerrarCurio").addEventListener("click", cerrarCuriosidad);
  ventana.addEventListener("click", e => { if (e.target === ventana) cerrarCuriosidad(); });
  document.addEventListener("keydown", e => {
    if (!ventana.classList.contains("abierto")) return;
    if (e.key === "Escape") cerrarCuriosidad();
    if (e.key === "ArrowRight") { curioIdx = (curioIdx + 1) % Math.max(curioLista.length, 1); renderCuriosidadModal(); }
    if (e.key === "ArrowLeft") { curioIdx = (curioIdx - 1 + Math.max(curioLista.length, 1)) % Math.max(curioLista.length, 1); renderCuriosidadModal(); }
  });
  let x0 = null;
  const body = $("curioBody");
  body.addEventListener("touchstart", e => { x0 = e.touches[0].clientX; }, { passive: true });
  body.addEventListener("touchend", e => {
    if (x0 === null) return;
    const dx = e.changedTouches[0].clientX - x0;
    x0 = null;
    if (Math.abs(dx) < 50 || !curioLista.length) return;
    curioIdx = dx < 0 ? (curioIdx + 1) % curioLista.length : (curioIdx - 1 + curioLista.length) % curioLista.length;
    renderCuriosidadModal();
  });
  body.addEventListener("click", async e => {
    const b = e.target.closest("[data-cur]");
    if (!b) return;
    const acc = b.dataset.cur;
    const c = curioLista[curioIdx];
    if (acc === "filtro") { curioFiltro = b.dataset.valor; curioIdx = 0; renderCuriosidadModal(); }
    else if (acc === "ant" && curioLista.length) { curioIdx = (curioIdx - 1 + curioLista.length) % curioLista.length; renderCuriosidadModal(); }
    else if (acc === "sig" && curioLista.length) { curioIdx = (curioIdx + 1) % curioLista.length; renderCuriosidadModal(); }
    else if (acc === "reac" && c) { curioRegistrar(c, b.dataset.valor); if (c) marcarCurioVista(c); renderCuriosidadModal(); }
    else if (acc === "reportar" && c) { curioReportar(c); b.textContent = "Gracias, lo revisamos"; b.disabled = true; }
    else if (acc === "revelar" && c) { CURIO_REVELADOS.add(claveCurio(c)); renderCuriosidadModal(); }
    else if (acc === "historial") renderCurioHistorial();
    else if (acc === "volver") renderCuriosidadModal();
    else if (acc === "ver" && c) { cerrarCuriosidad(); abrirDetalle(c.peli); }
    else if (acc === "compartir" && c) {
      const texto = c.peli.titulo + ": " + c.texto + (c.fuente ? " (Fuente: " + c.fuente + ")" : "");
      if (navigator.share) { try { await navigator.share({ text: texto }); } catch (err) {} }
      else if (navigator.clipboard) { try { await navigator.clipboard.writeText(texto); } catch (err) {} }
    }
  });
})();

/* ===== Fase 4: práctica ===== */

// 1) Dato para decidir: se muestra dentro de la ficha, con datos reales de la película
function datoParaDecidir(p) {
  const out = [];
  const min = minutos(p);
  if (min) {
    if (min >= 150) out.push("Dura " + min + " minutos: buena para una noche larga.");
    else if (min <= 100) out.push("Dura " + min + " minutos: cabe en una noche entre semana.");
    else out.push("Dura " + min + " minutos: cabe en una noche normal.");
  }
  const tono = intensidadDe_(p);
  if (tono === 1) out.push("Tono ligero, para relajarte.");
  if (tono === 3) out.push("Tono intenso: mejor con tiempo para asimilarla.");
  const m = marcas[p.titulo] || {};
  if (m.vista && m.estrellas) out.push("Ya la calificaste con " + m.estrellas + " estrella" + (m.estrellas === 1 ? "" : "s") + ".");
  return out;
}

(function datoEnFicha() {
  const detalle = document.getElementById("detalle");
  if (!detalle) return;
  new MutationObserver(() => {
    const h2 = detalle.querySelector("h2");
    if (!h2 || detalle.querySelector(".dato-decidir")) return;
    const titulo = h2.textContent.trim();
    const p = peliculas.find(x => x.titulo === titulo);
    if (!p) return;
    const lineas = datoParaDecidir(p);
    if (!lineas.length) return;
    const div = document.createElement("div");
    div.className = "dato-decidir";
    div.innerHTML = '<strong>Para decidir</strong>' + lineas.map(l => '<span>' + esc(l) + '</span>').join('');
    h2.insertAdjacentElement("afterend", div);
  }).observe(detalle, { childList: true });
})();

// 2) Tarjeta del día en Inicio: una curiosidad distinta cada día, elegida por el orden adaptativo
function renderTarjetaDia() {
  const sec = document.getElementById("tarjetaDia");
  if (!sec || !document.body.classList.contains("con-sesion") || !peliculas.length) return;
  const lista = curioFiltrada();
  if (!lista.length) { sec.style.display = "none"; return; }
  const dia = Math.floor(Date.now() / 86400000);
  const c = lista[dia % lista.length];
  sec.innerHTML =
    '<p class="tarjeta-dia-etiqueta">Curiosidad de hoy</p>' +
    '<p class="tarjeta-dia-texto">' + esc(c.texto) + '</p>' +
    '<p class="meta">' + esc(c.peli ? c.peli.titulo : "") + (c.fuente ? ' · Fuente: ' + esc(c.fuente) : '') + '</p>' +
    '<div class="saludo-acciones"><button type="button" class="pildora" data-accion="ver-curio">Ver curiosidades</button></div>';
  sec.style.display = "block";
}

(function tarjetaDiaEventos() {
  const sec = document.getElementById("tarjetaDia");
  if (!sec) return;
  sec.addEventListener("click", e => {
    if (e.target.closest("[data-accion='ver-curio']")) abrirCuriosidad();
  });
  setTimeout(renderTarjetaDia, 2500);
  setInterval(renderTarjetaDia, 10 * 60 * 1000);
})();

/* ===== Fase 5: datos de internet (solo los verificados) ===== */
let curiosidadesInternet = [];
const DATOS_CACHE_KEY = "datos_internet_cache";

function construirCuriosidadesInternet(copia) {
  const filas = (copia.values || []);
  if (filas.length < 2) return [];
  const enc = filas[0];
  const c = n => enc.indexOf(n);
  return filas.slice(1)
    .map(r => ({ tmdb: r[c("tmdb_id")], titulo: r[c("titulo")], dato: r[c("dato")], fuente: r[c("fuente")], url: r[c("url")], fecha: r[c("fecha_consulta")], estado: r[c("estado")], tipo: r[c("tipo")] }))
    .filter(x => x.estado === "verificado" && x.dato)
    .map(x => {
      const peli = peliculas.find(p => String(p.tmdb_id || "").trim() === String(x.tmdb).trim());
      return peli ? {
        peli: peli,
        tema: "Internet · " + (x.tipo || "Dato"),
        texto: x.dato,
        fuente: x.fuente + " · consultado " + x.fecha + " · " + x.url
      } : null;
    })
    .filter(Boolean);
}

async function cargarDatosInternet() {
  if (!accessToken || !navigator.onLine || !HOJA_ID) { usarCacheInternet(); return; }
  try {
    const r = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${HOJA_ID}/values/datos_internet!A:H`,
      { headers: { Authorization: "Bearer " + accessToken } });
    if (!r.ok) { usarCacheInternet(); return; }
    const copia = await r.json();
    localStorage.setItem(DATOS_CACHE_KEY, JSON.stringify(copia));
    curiosidadesInternet = construirCuriosidadesInternet(copia);
  } catch (e) { usarCacheInternet(); }
}

function usarCacheInternet() {
  try {
    const c = JSON.parse(localStorage.getItem(DATOS_CACHE_KEY) || "null");
    if (c) curiosidadesInternet = construirCuriosidadesInternet(c);
  } catch (e) {}
}

setTimeout(() => { if (document.body.classList.contains("con-sesion")) cargarDatosInternet(); else usarCacheInternet(); }, 9000);

/* ===== Fase 6: madurez y autonomía ===== */
const CURIO_REPORTES_KEY = "curio_reportes";
const CURIO_CUARENTENA = 2;   // con 2 reportes, la curiosidad sale de la lista hasta que cambie su dato

function curioReportes() {
  try { return JSON.parse(leerLS(CURIO_REPORTES_KEY) || "{}"); } catch (e) { return {}; }
}

function curioReportar(c) {
  const r = curioReportes();
  const k = claveCurio(c);
  r[k] = (r[k] || 0) + 1;
  escribirLS(CURIO_REPORTES_KEY, JSON.stringify(r));
}

// Autocorrección: una curiosidad solo se muestra si está completa, tiene fuente cuando la necesita y no está en cuarentena
function curioEstaSana(c) {
  if (!c || !c.peli || !c.peli.titulo || !String(c.texto || "").trim()) return false;
  if (/internet/i.test(String(c.tema || "")) && !/^https?:\/\//.test(String(c.fuente || "").split(" · ").pop() || "")) return false;
  return (curioReportes()[claveCurio(c)] || 0) < CURIO_CUARENTENA;
}

// Autodiagnóstico: una línea con el estado real de la función
function curioDiagnostico() {
  const todas = todasLasCuriosidades().concat(curiosidadesInternet);
  const sanas = todas.filter(curioEstaSana).length;
  const enRevision = todas.filter(c => (curioReportes()[claveCurio(c)] || 0) >= CURIO_CUARENTENA).length;
  const internet = curiosidadesInternet.filter(curioEstaSana).length;
  return sanas + " curiosidades listas · " + internet + " de internet verificadas" +
    (enRevision ? " · " + enRevision + " en revisión" : "");
}

// Pruebas automáticas al cargar: si algo falla, se registra y no se muestra la parte afectada
(function pruebasCuriosidad() {
  setTimeout(() => {
    if (!document.body.classList.contains("con-sesion")) return;
    const todas = todasLasCuriosidades().concat(curiosidadesInternet);
    const fallos = todas.filter(c => !c || !c.peli || !String(c.texto || "").trim());
    if (fallos.length) console.warn("Curiosidades: " + fallos.length + " entradas incompletas omitidas.");
    const sinSpoiler = todas.filter(c => esSpoiler(c.texto)).length;
    if (sinSpoiler) console.info("Curiosidades: " + sinSpoiler + " con posible spoiler, ocultas hasta «Revelar».");
  }, 12000);
})();

/* ---------- Inicio adaptativo: el orden de los bloques depende de tu uso real ---------- */
(function () {
  const bloque = document.getElementById("inicioBloques");
  if (!bloque) return;
  const base = {
    avisoFecha: 0, avisoEstancados: 0,
    saludoPersonal: 1,
    hoy: 2, queVer: 3,
    recomendaciones: 4, estaSemana: 5, pregunta: 6, bienvenida: 7,
    tarjetaAuto: 8, tarjetaDia: 9
  };
  function ordenarInicio() {
    const c = contarEstados();
    const pref = Object.assign({}, base);
    if (c.pendientes > 0) { pref.hoy = 1; pref.queVer = 2; }          // con pendientes: primero qué ver
    if (c.vistas >= 5) pref.recomendaciones = 3;                       // con historial: recomendaciones arriba
    if (c.vistas === 0 && c.pendientes === 0) {                        // cuenta nueva: bienvenida primero
      pref.saludoPersonal = 0; pref.bienvenida = 1;
    }
    Array.from(bloque.children).forEach(el => {
      const v = String(pref[el.id] !== undefined ? pref[el.id] : 20);
      if (el.style.order !== v) el.style.order = v;                   // solo escribe si cambia: sin bucles
    });
  }
  let turno = 0;
  const programar = () => { cancelAnimationFrame(turno); turno = requestAnimationFrame(ordenarInicio); };
  new MutationObserver(programar).observe(bloque, {
    childList: true, subtree: true, attributes: true, attributeFilter: ["style", "class"]
  });
  ordenarInicio();
})();

/* ---------- Diagnóstico de datos: revisa tu cuenta y su estado, con respaldo de un toque ---------- */
function abrirDiagnostico() {
  cerrarPaneles();
  const claves = new Set(peliculas.map(p => claveDe(p)));
  const enMarcas = Object.keys(marcas).filter(k => !k.startsWith("__"));
  const huerfanas = enMarcas.filter(k => !claves.has(k));
  const conMarcas = enMarcas.filter(k => claves.has(k)).length;
  const porTitulo = {};
  peliculas.forEach(p => { porTitulo[p.titulo] = (porTitulo[p.titulo] || 0) + 1; });
  const repetidos = Object.keys(porTitulo).filter(t => porTitulo[t] > 1);
  const sinId = peliculas.filter(p => !/^\d+$/.test(String(p.tmdb_id || "").trim())).length;
  const kb = (new Blob([JSON.stringify(marcas)]).size / 1024).toFixed(1) + " KB";
  const fmt = iso => { if (!iso) return "todavía no"; const d = new Date(iso); return isNaN(d) ? "desconocida" : d.toLocaleString("es-MX", { dateStyle: "short", timeStyle: "short" }); };
  let copiaSemanal = null;
  try { copiaSemanal = localStorage.getItem("respaldo_drive_fecha"); } catch (e) {}
  const enLinea = navigator.onLine !== false;

  const filas = [
    { t: "Películas en tu hoja", v: String(peliculas.length), ok: true },
    { t: "Películas con marcas", v: String(conMarcas), ok: true },
    { t: "Tamaño de tus marcas", v: kb, ok: true },
    { t: "Último guardado en Drive", v: fmt(ultimaSyncOk), ok: !!ultimaSyncOk && !syncPendiente },
    { t: "Cambios sin subir", v: syncPendiente ? "sí" : "no", ok: !syncPendiente },
    { t: "Último respaldo semanal", v: copiaSemanal ? fmt(copiaSemanal) : "todavía no", ok: !!copiaSemanal },
    { t: "Conexión", v: enLinea ? "en línea" : "sin señal", ok: enLinea },
    { t: "Marcas sin película en la hoja", v: String(huerfanas.length), ok: huerfanas.length === 0,
      nota: "Son marcas de películas que ya no están en tu hoja. No afectan lo que ves." },
    { t: "Títulos repetidos en la hoja", v: String(repetidos.length), ok: repetidos.length === 0,
      nota: "Dos películas con el mismo título comparten marcas. Dales un tmdb_id distinto en la hoja." },
    { t: "Películas sin tmdb_id", v: String(sinId), ok: sinId === 0,
      nota: "Se identifican por el título. Si lo cambias en la hoja, sus marcas no lo siguen." }
  ];
  const lista = filas.map(f =>
    '<li><span>' + (f.ok ? '<b class="dg-ok">✓</b> ' : '<b class="dg-warn">⚠</b> ') + esc(f.t) +
    (f.nota ? '<small class="dg-nota">' + esc(f.nota) + '</small>' : '') + '</span><b>' + esc(f.v) + '</b></li>'
  ).join("");
  const cuerpo = '<ul class="dg-lista">' + lista + '</ul>' +
    '<button type="button" class="pildora destacado" data-respaldo>⬇ Respaldar ahora</button>';
  abrirVentanaSimple("diagnostico", "Diagnóstico de datos", cuerpo);
  const btn = document.querySelector("#diagnostico [data-respaldo]");
  if (btn) btn.addEventListener("click", () => respaldarMarcas());
}
document.getElementById("diagnosticoDatos").addEventListener("click", abrirDiagnostico);
